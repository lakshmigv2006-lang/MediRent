# MediRent — MySQL Database Setup & Import Guide

This directory contains the complete MySQL relational database schema and realistic seed data for the **MediRent Healthcare Equipment Rental & Hospital-to-Hospital (HEEN) Exchange Platform**.

---

## 🗄️ Database Tables Overview

| # | Table Name | Purpose & Coverage |
| :--- | :--- | :--- |
| 1 | **`users`** | Admin (`Admin@123`), Hospital (`Hospital@1`), and Supplier (`Supplier@1`) credentials, roles, and account statuses. |
| 2 | **`hospitals`** | Form C registration, Directorate of Medical Services (DMS) authority, Chief Doctor TNMC registration, GPS lat/lon, and triple verification. |
| 3 | **`suppliers`** | CDSCO Form 20-B/21-B Wholesale Drug & Medical Device License, GSTIN (`33AABCM9876Q1Z2`), PAN, and Anna Nagar East Depot GPS pin. |
| 4 | **`supplier_documents`** | Statutory documents repository (CDSCO licenses, Form GST REG-06, NABL ISO 17025 accreditation, GCC Trade License & Fire NOC). |
| 5 | **`equipment`** | Fleet inventory, condition ratings, operating hours, **Annual Maintenance Certificate records (last audit & next yearly renewal date)**, NABL report numbers, images, and daily rates. |
| 6 | **`heen_exchange_pool`** | **HEEN (Healthcare Equipment Exchange Network)**: Hospital-to-Hospital equipment sharing, standby units, biomedical condition logs, NABL metrology validity, demand-based allocation, and sub-45 min emergency transit ETAs. |
| 7 | **`my_hospital_shared_assets`** | Standby hospital equipment listed into HEEN with idle unit counts and inter-hospital earnings tracking. |
| 8 | **`rentals`** | Rental orders, **multi-method payments (UPI QR Code, Cards, NetBanking)**, **dynamic 5% commission / 95% supplier split**, settlement locking, driver logistics assignments, and **rental extension/renewal logs**. |
| 9 | **`commission_rules`** | Dynamic platform commission rule configurations (Standard 5.0%, Critical Care 4.0%, Long Term 3.5%). |

---

## 🚀 How to Import into MySQL

### Option A: Via MySQL Command Line (CLI)
```bash
# 1. Login to MySQL
mysql -u root -p

# 2. Run the SQL script directly
mysql -u root -p < database/schema.sql
```

### Option B: Via MySQL Workbench / phpMyAdmin / DBeaver
1. Open **MySQL Workbench** (or your favorite SQL GUI).
2. Connect to your MySQL server.
3. Open the file: `database/schema.sql`.
4. Click **Execute / Run** (⚡).
5. The `medirent_db` database, all 9 tables, indexes, foreign keys, and matching seed records will be created instantly.
