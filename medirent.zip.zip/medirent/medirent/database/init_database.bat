@echo off
title MediRent Database Initializer
echo ======================================================
echo   MEDIRENT HEALTHCARE PLATFORM — DATABASE INITIALIZER 
echo ======================================================
powershell -ExecutionPolicy Bypass -File "%~dp0init_database.ps1"
pause
