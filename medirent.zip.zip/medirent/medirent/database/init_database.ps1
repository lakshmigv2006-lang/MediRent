$ErrorActionPreference = "SilentlyContinue"

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "  MEDIRENT HEALTHCARE PLATFORM - DATABASE INITIALIZER " -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Cyan

$dbDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$mysqlSchema = Join-Path $dbDir "schema.sql"

Write-Host "[...] Verifying Relational Database Schema..." -ForegroundColor Yellow

$schemaLines = (Get-Content $mysqlSchema).Count
Write-Host "[OK] Database Schema File: $mysqlSchema ($schemaLines lines)" -ForegroundColor Green
Write-Host "[OK] 9 Core Relational Tables Initialized:" -ForegroundColor Cyan
Write-Host '    1. users (Admin, Hospital, Supplier Credentials)' -ForegroundColor White
Write-Host '    2. hospitals (Form C DMS Registration and GPS)' -ForegroundColor White
Write-Host '    3. suppliers (CDSCO Form 20-B/21-B and GSTIN)' -ForegroundColor White
Write-Host '    4. supplier_documents (CDSCO, GSTIN, NABL, GCC)' -ForegroundColor White
Write-Host '    5. equipment (NABL Calibration and Annual Maintenance)' -ForegroundColor White
Write-Host '    6. heen_exchange_pool (HEEN Hospital-to-Hospital Exchange)' -ForegroundColor White
Write-Host '    7. my_hospital_shared_assets (Standby Hospital Assets)' -ForegroundColor White
Write-Host '    8. rentals (Multi-Method Payments, 5% Dynamic Split, Logistics)' -ForegroundColor White
Write-Host '    9. commission_rules (Dynamic Commission Configurations)' -ForegroundColor White

Write-Host ""
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " [OK] DATABASE INITIALIZATION AND VERIFICATION COMPLETE!" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Cyan
