-- ==============================================================================
-- MEDIRENT — COMPLETE RELATIONAL MYSQL DATABASE SCHEMA & SEED DATA
-- Verified Healthcare Equipment Rental & Hospital-to-Hospital Exchange Platform
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS medirent_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE medirent_db;

-- Drop existing tables in reverse dependency order if resetting
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS rentals;
DROP TABLE IF EXISTS my_hospital_shared_assets;
DROP TABLE IF EXISTS heen_exchange_pool;
DROP TABLE IF EXISTS equipment;
DROP TABLE IF EXISTS supplier_documents;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS hospitals;
DROP TABLE IF EXISTS commission_rules;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ==============================================================================
-- 1. USERS TABLE
-- Authentication, roles, and status governance
-- ==============================================================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'hospital', 'supplier') NOT NULL,
    organization VARCHAR(255) NOT NULL,
    status ENUM('active', 'pending', 'suspended') DEFAULT 'active',
    is_verified BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (email),
    INDEX idx_user_role (role),
    INDEX idx_user_status (status)
) ENGINE=InnoDB;

-- ==============================================================================
-- 2. HOSPITALS PROFILE TABLE
-- Form C Clinical Establishment Registration, DMS Authority & GPS Coordinates
-- ==============================================================================
CREATE TABLE hospitals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    organization_name VARCHAR(255) NOT NULL,
    registration_number VARCHAR(100) NOT NULL UNIQUE,
    form_type VARCHAR(150) NOT NULL DEFAULT 'FORM C — CERTIFICATE OF REGISTRATION',
    act_name VARCHAR(255) NOT NULL DEFAULT 'The Tamil Nadu Clinical Establishments (Regulation) Act, 1997',
    gov_header VARCHAR(255) NOT NULL DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header VARCHAR(255) NOT NULL DEFAULT 'DIRECTORATE OF MEDICAL AND RURAL HEALTH SERVICES (DMS)',
    issuing_authority VARCHAR(255) NOT NULL DEFAULT 'District Registering Authority, Chennai District',
    signatory_name VARCHAR(255) NOT NULL DEFAULT 'Dr. K. S. Narayanan, MD, DPH',
    signatory_title VARCHAR(255) NOT NULL DEFAULT 'Joint Director of Health Services & Member Secretary, DRA Chennai',
    chief_doctor VARCHAR(255) NOT NULL,
    cmo_reg_no VARCHAR(100) NOT NULL,
    facility_type VARCHAR(150) NOT NULL DEFAULT 'Multi-Specialty Inpatient Hospital (300 Bedded)',
    address TEXT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL DEFAULT 13.0420,
    longitude DECIMAL(11, 8) NOT NULL DEFAULT 80.2520,
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    docs_verified BOOLEAN DEFAULT TRUE,
    license_verified BOOLEAN DEFAULT TRUE,
    location_verified BOOLEAN DEFAULT TRUE,
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    rejection_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_hosp_status (verification_status)
) ENGINE=InnoDB;

-- ==============================================================================
-- 3. SUPPLIERS PROFILE TABLE
-- CDSCO Form 20-B/21-B Wholesale Drug & Medical Device License & GSTIN
-- ==============================================================================
CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    organization_name VARCHAR(255) NOT NULL,
    registration_number VARCHAR(100) NOT NULL UNIQUE,
    form_type VARCHAR(200) NOT NULL DEFAULT 'FORM 20-B & FORM 21-B (WHOLESALE DRUG & MEDICAL DEVICE LICENSE)',
    act_name VARCHAR(255) NOT NULL DEFAULT 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017',
    gov_header VARCHAR(255) NOT NULL DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header VARCHAR(255) NOT NULL DEFAULT 'DRUGS CONTROL ADMINISTRATION & CDSCO (SOUTH ZONE)',
    issuing_authority VARCHAR(255) NOT NULL DEFAULT 'Office of the Assistant Director of Drugs Control, Zone-I, Chennai',
    signatory_name VARCHAR(255) NOT NULL DEFAULT 'Thiru. P. Vijayabaskar, M.Pharm',
    signatory_title VARCHAR(255) NOT NULL DEFAULT 'Licensing Authority & Assistant Director of Drugs Control, Chennai',
    gstin VARCHAR(50) NOT NULL UNIQUE,
    pan_number VARCHAR(50) NOT NULL,
    contact_person VARCHAR(255) NOT NULL,
    facility_type VARCHAR(200) NOT NULL DEFAULT 'Authorized Medical Device Importer, Stockist & Service Hub',
    address TEXT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL DEFAULT 13.0850,
    longitude DECIMAL(11, 8) NOT NULL DEFAULT 80.2101,
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    docs_verified BOOLEAN DEFAULT TRUE,
    license_verified BOOLEAN DEFAULT TRUE,
    location_verified BOOLEAN DEFAULT TRUE,
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'verified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_supp_status (verification_status)
) ENGINE=InnoDB;

-- ==============================================================================
-- 4. SUPPLIER STATUTORY DOCUMENTS REPOSITORY
-- CDSCO Licenses, GSTIN Form GST REG-06, NABL ISO 17025, GCC Trade Licenses
-- ==============================================================================
CREATE TABLE supplier_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    license_no VARCHAR(100) NOT NULL,
    authority VARCHAR(255) NOT NULL,
    gov_header VARCHAR(255) DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header VARCHAR(255) DEFAULT 'DRUGS CONTROL ADMINISTRATION & HEALTH SERVICES',
    act_name VARCHAR(255) DEFAULT 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017',
    valid_from DATE NULL,
    valid_until VARCHAR(100) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size VARCHAR(50) DEFAULT '2.0 MB',
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'verified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
    INDEX idx_doc_supplier (supplier_id)
) ENGINE=InnoDB;

-- ==============================================================================
-- 5. EQUIPMENT FLEET TABLE
-- Medical equipment inventory, NABL Calibration & Annual Maintenance Cycles
-- ==============================================================================
CREATE TABLE equipment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    manufacturer VARCHAR(150) NOT NULL,
    model VARCHAR(150) NOT NULL,
    price_per_day DECIMAL(10, 2) NOT NULL,
    condition_rating ENUM('new', 'excellent', 'good', 'needs_calibration') DEFAULT 'excellent',
    inventory_status ENUM('available', 'on_rent', 'maintenance') DEFAULT 'available',
    total_units INT NOT NULL DEFAULT 1,
    available_units INT NOT NULL DEFAULT 1,
    operating_hours VARCHAR(100) DEFAULT '0 Hrs',
    ai_score INT DEFAULT 95,
    distance_km DECIMAL(5, 2) DEFAULT 2.4,
    registration_number VARCHAR(100) NOT NULL,
    form_type VARCHAR(255) DEFAULT 'BIOMEDICAL CALIBRATION & ELECTRICAL SAFETY COMPLIANCE REPORT',
    act_name VARCHAR(255) DEFAULT 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards',
    gov_header VARCHAR(255) DEFAULT 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)',
    dept_header VARCHAR(255) DEFAULT 'CENTRAL BIOMEDICAL ENGINEERING QUALITY AUDIT COUNCIL',
    issuing_authority VARCHAR(255) DEFAULT 'Accredited Calibration Lab CC-2981, Guindy Industrial Estate, Chennai',
    signatory_name VARCHAR(255) DEFAULT 'Er. R. Senthil Kumar, M.E. (Biomedical)',
    signatory_title VARCHAR(255) DEFAULT 'Chief Quality Inspector & Lead Biomedical Metrologist',
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    last_maintenance_date VARCHAR(100) DEFAULT '10 Sept 2026',
    next_maintenance_due VARCHAR(100) DEFAULT '09 Sept 2027',
    maintenance_cycle VARCHAR(100) DEFAULT 'Annual (1-Year Renewal)',
    service_engineer VARCHAR(255) DEFAULT 'Er. R. Senthil Kumar',
    service_agency VARCHAR(255) DEFAULT 'Authorized Service Center, Chennai',
    depot_location VARCHAR(255) DEFAULT 'Anna Nagar East Hub (13.0850° N, 80.2101° E)',
    latitude DECIMAL(10, 8) DEFAULT 13.0850,
    longitude DECIMAL(11, 8) DEFAULT 80.2101,
    test_result TEXT NULL,
    description TEXT NULL,
    image_url TEXT NULL,
    docs_verified BOOLEAN DEFAULT TRUE,
    license_verified BOOLEAN DEFAULT TRUE,
    location_verified BOOLEAN DEFAULT TRUE,
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'verified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
    INDEX idx_eq_category (category),
    INDEX idx_eq_status (inventory_status)
) ENGINE=InnoDB;

-- ==============================================================================
-- 6. HEEN (HEALTHCARE EQUIPMENT EXCHANGE NETWORK) POOL TABLE
-- Hospital-to-Hospital equipment sharing, real-time telemetry & surge allocation
-- ==============================================================================
CREATE TABLE heen_exchange_pool (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_name VARCHAR(255) NOT NULL,
    hospital_type VARCHAR(150) NOT NULL,
    device VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    standby_quantity INT NOT NULL DEFAULT 1,
    price_per_day DECIMAL(10, 2) NOT NULL,
    availability VARCHAR(150) NOT NULL DEFAULT 'Available Immediately (Surge Ready)',
    status_badge ENUM('available', 'surge_active', 'reserved') DEFAULT 'available',
    distance_km DECIMAL(5, 2) NOT NULL,
    eta_mins INT NOT NULL,
    condition_grade VARCHAR(100) NOT NULL DEFAULT 'A+ (98% Pristine)',
    operating_hours VARCHAR(100) NOT NULL DEFAULT '300 Operating Hrs',
    last_maintenance VARCHAR(100) NOT NULL,
    next_calibration_due VARCHAR(100) NOT NULL,
    sterilization_verified BOOLEAN DEFAULT TRUE,
    demand_index VARCHAR(150) NOT NULL DEFAULT 'High Emergency Demand (Surge Allocation)',
    ai_match_score INT NOT NULL DEFAULT 98,
    contact_doctor VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    image_url TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_heen_category (category)
) ENGINE=InnoDB;

-- ==============================================================================
-- 7. MY HOSPITAL SHARED IDLE ASSETS TABLE
-- Hospital's standby equipment shared into the HEEN network to monetize idle time
-- ==============================================================================
CREATE TABLE my_hospital_shared_assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT NOT NULL,
    device VARCHAR(255) NOT NULL,
    model VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    idle_quantity INT NOT NULL DEFAULT 1,
    price_per_day DECIMAL(10, 2) NOT NULL,
    condition_grade VARCHAR(100) NOT NULL DEFAULT 'A+ (Fully Calibrated)',
    operating_hours VARCHAR(100) NOT NULL DEFAULT '180 Hrs',
    sharing_status ENUM('active_sharing', 'paused', 'withdrawn') DEFAULT 'active_sharing',
    inter_hospital_earnings DECIMAL(12, 2) DEFAULT 0.00,
    last_sterilization_date VARCHAR(100) DEFAULT 'Yesterday',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ==============================================================================
-- 8. RENTALS & FINANCIAL TRANSACTIONS LEDGER TABLE
-- Multi-Option Payments (UPI QR, Cards, NetBanking), 5% Dynamic Split & Settlements
-- ==============================================================================
CREATE TABLE rentals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rental_code VARCHAR(50) NOT NULL UNIQUE,
    hospital_name VARCHAR(255) NOT NULL,
    supplier_name VARCHAR(255) NOT NULL,
    equipment_name VARCHAR(255) NOT NULL,
    start_date VARCHAR(100) NOT NULL,
    end_date VARCHAR(100) NOT NULL,
    days INT NOT NULL,
    price_per_day DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL,
    commission_rate_used DECIMAL(5, 2) NOT NULL DEFAULT 5.00,
    commission_amount DECIMAL(12, 2) NOT NULL,
    supplier_amount DECIMAL(12, 2) NOT NULL,
    status ENUM('pending_approval', 'approved', 'declined', 'paid', 'active', 'completed') DEFAULT 'pending_approval',
    payment_status ENUM('pending', 'captured', 'refunded', 'failed') DEFAULT 'pending',
    payment_method_used VARCHAR(50) DEFAULT 'CARD',
    razorpay_payment_id VARCHAR(100) NULL,
    settlement_status ENUM('pending', 'settled') DEFAULT 'pending',
    settled_at TIMESTAMP NULL,
    pickup_status VARCHAR(100) DEFAULT 'waiting_for_payment',
    driver_name VARCHAR(255) NULL,
    driver_phone VARCHAR(50) NULL,
    vehicle_plate VARCHAR(50) NULL,
    vehicle_type VARCHAR(100) DEFAULT 'Medical Logistics Van',
    is_extended BOOLEAN DEFAULT FALSE,
    extension_log VARCHAR(255) NULL,
    decline_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rental_code (rental_code),
    INDEX idx_rental_status (status),
    INDEX idx_rental_payment (payment_status),
    INDEX idx_rental_settlement (settlement_status)
) ENGINE=InnoDB;

-- ==============================================================================
-- 9. COMMISSION RULES TABLE
-- Dynamic Platform Commission Rate Rules
-- ==============================================================================
CREATE TABLE commission_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    standard_rate DECIMAL(5, 2) NOT NULL DEFAULT 5.00,
    critical_care_rate DECIMAL(5, 2) NOT NULL DEFAULT 4.00,
    long_term_rate DECIMAL(5, 2) NOT NULL DEFAULT 3.50,
    gateway_interchange_fee DECIMAL(5, 2) NOT NULL DEFAULT 1.80,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==============================================================================
-- SEED DATA INSERTIONS (MATCHING 100% OF CURRENT APPLICATION STATE)
-- ==============================================================================

-- 1. USERS SEED
INSERT INTO users (id, name, email, password_hash, role, organization, status, is_verified) VALUES
(1, 'Dr. Anand Ramanathan', 'hospital@medirent.io', 'Hospital@1', 'hospital', 'City Care Multi-Speciality Hospital', 'active', TRUE),
(2, 'Dr. Priya Sundaram', 'kaveri@medirent.io', 'Hospital@1', 'hospital', 'Kaveri Community Health Center', 'pending', FALSE),
(3, 'Rajesh Sharma', 'supplier@medirent.io', 'Supplier@1', 'supplier', 'MedEquip Solutions Pvt Ltd', 'active', TRUE),
(4, 'Platform Executive Admin', 'admin@medirent.io', 'Admin@123', 'admin', 'MediRent Operations HQ', 'active', TRUE);

-- 2. HOSPITALS SEED
INSERT INTO hospitals (id, user_id, organization_name, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, chief_doctor, cmo_reg_no, facility_type, address, latitude, longitude, valid_from, valid_until, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 1, 'City Care Multi-Speciality Hospital', 'TN/CHE/HOSP/2024/008891', 'FORM C — CERTIFICATE OF REGISTRATION', 'The Tamil Nadu Clinical Establishments (Regulation) Act, 1997', 'GOVERNMENT OF TAMIL NADU', 'DIRECTORATE OF MEDICAL AND RURAL HEALTH SERVICES (DMS)', 'District Registering Authority, Chennai District', 'Dr. K. S. Narayanan, MD, DPH', 'Joint Director of Health Services & Member Secretary, DRA Chennai', 'Dr. Anand Ramanathan, MS, MCh (Cardio)', 'TNMC Registration No. 64821', 'Multi-Specialty Inpatient Hospital (300 Bedded)', 'Old No. 45, New No. 112, Anna Salai, Teynampet, Chennai, Tamil Nadu - 600018', 13.0420, 80.2520, '2024-04-01', '2029-03-31', TRUE, TRUE, TRUE, 'verified'),
(2, 2, 'Kaveri Community Health Center', 'TN/CBE/CLINIC/2025/001042', 'FORM B — PROVISIONAL CERTIFICATE OF REGISTRATION', 'The Clinical Establishments (Registration and Regulation) Act, 2010', 'GOVERNMENT OF TAMIL NADU', 'DIRECTORATE OF PUBLIC HEALTH AND PREVENTIVE MEDICINE', 'District Registering Authority, Coimbatore District', 'Dr. M. Soundararajan, MBBS, DLO', 'Deputy Director of Health Services, Coimbatore', 'Dr. Priya Sundaram, MD (General Medicine)', 'TNMC Registration No. 89204', 'Primary Care & Emergency Stabilization Clinic (50 Bedded)', 'SF-142, Avinashi Road, Peelamedu, Coimbatore, Tamil Nadu - 641004', 11.0250, 77.0100, '2025-08-15', '2027-08-14', TRUE, FALSE, TRUE, 'pending');

-- 3. SUPPLIERS SEED
INSERT INTO suppliers (id, user_id, organization_name, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, gstin, pan_number, contact_person, facility_type, address, latitude, longitude, valid_from, valid_until, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 3, 'MedEquip Solutions Pvt Ltd', 'TN/DDC/MD-WL/2024/004519', 'FORM 20-B & FORM 21-B (WHOLESALE DRUG & MEDICAL DEVICE LICENSE)', 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017', 'GOVERNMENT OF TAMIL NADU', 'DRUGS CONTROL ADMINISTRATION & CDSCO (SOUTH ZONE)', 'Office of the Assistant Director of Drugs Control, Zone-I, Chennai', 'Thiru. P. Vijayabaskar, M.Pharm', 'Licensing Authority & Assistant Director of Drugs Control, Chennai', '33AABCM9876Q1Z2', 'AABCM9876Q', 'Rajesh Sharma (Managing Director)', 'Authorized Medical Device Importer, Stockist & Service Hub', 'Plot No. 18, 2nd Avenue, Anna Nagar East, Chennai, Tamil Nadu - 600102', 13.0850, 80.2101, '2024-07-01', '2029-06-30', TRUE, TRUE, TRUE, 'verified');

-- 4. SUPPLIER STATUTORY DOCUMENTS SEED
INSERT INTO supplier_documents (id, supplier_id, title, license_no, authority, gov_header, dept_header, act_name, valid_from, valid_until, file_name, file_size, verification_status) VALUES
(1, 1, 'CDSCO Form 20-B & 21-B Wholesale Drug & Medical Device License', 'TN/DDC/MD-WL/2024/004519', 'Drugs Control Administration, Government of Tamil Nadu', 'GOVERNMENT OF TAMIL NADU — DRUGS CONTROL ADMINISTRATION & CDSCO', 'CENTRAL DRUGS STANDARD CONTROL ORGANIZATION (SOUTH ZONE)', 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017', '2024-07-01', '30 June 2029', 'CDSCO_Form20B_21B_MedEquip_2024.pdf', '2.4 MB', 'verified'),
(2, 1, 'GSTIN Registration Certificate (Form GST REG-06)', '33AABCM9876Q1Z2', 'Central Board of Indirect Taxes and Customs (CBIC)', 'GOVERNMENT OF INDIA — GOODS AND SERVICES TAX IDENTIFICATION', 'COMMISSIONERATE OF CENTRAL TAX & TAMIL NADU STATE GST', 'Central Goods and Services Tax Act, 2017', '2017-07-01', 'Active (Regular)', 'GSTIN_Registration_33AABCM9876Q1Z2.pdf', '1.1 MB', 'verified'),
(3, 1, 'NABL Metrology Calibration Hub ISO/IEC 17025 Certificate', 'NABL/LAB/TN-CC2981', 'National Accreditation Board for Testing & Calibration Laboratories', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'DEPARTMENT OF SCIENCE & TECHNOLOGY, GOVERNMENT OF INDIA', 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards', '2024-09-16', '15 September 2028', 'NABL_Calibration_Accreditation_CC2981.pdf', '3.8 MB', 'verified'),
(4, 1, 'Greater Chennai Corporation Trade License & Fire NOC', 'GCC/ZN-08/TL/2024/99120', 'Revenue & Health Department, Zone 8 Chennai', 'GREATER CHENNAI CORPORATION — PUBLIC HEALTH & REVENUE DEPARTMENT', 'ZONE 8 (ANNA NAGAR) SANITARY & DANGEROUS/OFFENSIVE TRADE LICENSING', 'Chennai City Municipal Corporation Act, 1919 & Fire Prevention Act', '2024-04-01', '31 March 2028', 'GCC_Trade_License_AnnaNagar_Depot.pdf', '1.5 MB', 'verified');

-- 5. EQUIPMENT SEED
INSERT INTO equipment (id, supplier_id, name, category, manufacturer, model, price_per_day, condition_rating, inventory_status, total_units, available_units, operating_hours, ai_score, distance_km, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, valid_from, valid_until, last_maintenance_date, next_maintenance_due, maintenance_cycle, service_engineer, service_agency, depot_location, latitude, longitude, test_result, description, image_url, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 1, 'Philips EverFlo Oxygen Concentrator 10L', 'Respiratory Support', 'Philips Healthcare', 'EverFlo 10L Ultra-Quiet', 500.00, 'excellent', 'available', 4, 3, '520 Hrs', 96, 2.40, 'NABL/CAL/2026/TN-7741', 'BIOMEDICAL CALIBRATION & ELECTRICAL SAFETY COMPLIANCE REPORT', 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'CENTRAL BIOMEDICAL ENGINEERING QUALITY AUDIT COUNCIL', 'Accredited Calibration Lab CC-2981, Guindy Industrial Estate, Chennai', 'Er. R. Senthil Kumar, M.E. (Biomedical)', 'Chief Quality Inspector & Lead Biomedical Metrologist', '2026-09-10', '2027-09-09', '10 Sept 2026', '09 Sept 2027', 'Annual (1-Year Renewal)', 'Er. R. Senthil Kumar', 'Philips Healthcare Authorized Service Center, Chennai', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'Oxygen Purity: 95.4% @ 10 LPM (PASSED), Leakage Current: < 100uA (SAFE)', 'High-purity medical grade 10L continuous flow oxygen concentrator with integrated OPI.', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80', TRUE, TRUE, TRUE, 'verified'),
(2, 1, 'Dräger Evita V300 Critical Care Ventilator', 'Respiratory Support', 'Dräger Medical', 'Evita V300', 1800.00, 'new', 'on_rent', 2, 1, '280 Hrs', 94, 4.10, 'NABL/CAL/2026/TN-8902', 'INTENSIVE CARE VENTILATOR PERFORMANCE CALIBRATION CERTIFICATE', 'ISO 80601-2-12 & IEC 60601-1-2 EMC Compliance Guidelines', 'CENTRAL DRUGS STANDARD CONTROL ORGANIZATION (CDSCO)', 'MEDICAL DEVICE TESTING & VERIFICATION LABORATORY, TAMIL NADU', 'Dräger Authorized Biomedical Metrology Laboratory, Chennai', 'Dr. S. Meenakshi, Ph.D (Clinical Engg)', 'Senior Biomedical Consultant & Testing Officer', '2026-08-20', '2027-08-19', '20 Aug 2026', '19 Aug 2027', 'Annual (1-Year Renewal)', 'Dr. S. Meenakshi', 'Dräger Biomedical Metrology Laboratory, Chennai', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'Tidal Volume Delivery Accuracy: 99.2% (PASSED), PEEP Calibration: 100% (SAFE)', 'Advanced intensive care ventilator for adult and pediatric patients.', 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80', TRUE, TRUE, TRUE, 'verified'),
(3, 1, 'GE Healthcare B40 Multiparameter Monitor', 'Patient Monitoring', 'GE Healthcare', 'B40 Patient Monitor', 450.00, 'excellent', 'available', 5, 5, '190 Hrs', 92, 2.40, 'NABL/CAL/2026/TN-9921', 'MULTIPARAMETER ICU PATIENT MONITOR CALIBRATION CERTIFICATE', 'IEC 60601-2-49 & NABL Quality Accreditations', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'BIOMEDICAL INSTRUMENTATION DIVISION', 'GE Certified Calibration Center, Chennai', 'Er. Anand Varma', 'Senior Biomedical Engineer', '2026-07-15', '2027-07-14', '15 July 2026', '14 July 2027', 'Annual (1-Year Renewal)', 'Er. Anand Varma', 'GE Healthcare Metrology Hub, Guindy', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'ECG, SpO2 & NIBP Precision: 99.8% (PASSED)', '12.1-inch color display monitor for ECG, SpO2, NIBP, Dual Temp, and Respiration monitoring.', 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600&auto=format&fit=crop&q=80', TRUE, TRUE, TRUE, 'verified');

-- 6. HEEN EXCHANGE POOL SEED
INSERT INTO heen_exchange_pool (id, hospital_name, hospital_type, device, category, standby_quantity, price_per_day, availability, status_badge, distance_km, eta_mins, condition_grade, operating_hours, last_maintenance, next_calibration_due, sterilization_verified, demand_index, ai_match_score, contact_doctor, location, image_url) VALUES
(1, 'Apollo Hospitals Greams Road', 'Quaternary Care Medical Center (550 Beds)', 'Maquet SERVO-u Advanced ICU Mechanical Ventilator', 'Critical Care Ventilation', 2, 1600.00, 'Available Immediately (Surge Ready)', 'available', 1.80, 25, 'A+ (98% Pristine)', '420 Operating Hrs', '12 August 2026', '11 August 2027', TRUE, 'High Emergency Demand (Surge Allocation)', 98, 'Dr. V. Rajesh, Head of Critical Care Medicine', 'Greams Lane, Thousand Lights, Chennai (1.8 km)', 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80'),
(2, 'Kauvery Hospital Alwarpet', 'Super-Specialty Tertiary Hospital (200 Beds)', 'Medtronic Puritan Bennett 980 ICU Ventilator', 'Critical Care Ventilation', 1, 1950.00, 'Available for H2H Rent (Idle Asset)', 'available', 3.20, 35, 'A (100% Calibrated)', '310 Operating Hrs', '28 July 2026', '27 July 2027', TRUE, 'Demand-Based Rapid Transfer', 96, 'Dr. C. Suresh, Biomedical Director', 'TTK Road, Alwarpet, Chennai (3.2 km)', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80');

-- 7. MY HOSPITAL SHARED ASSETS SEED
INSERT INTO my_hospital_shared_assets (id, hospital_id, device, model, category, idle_quantity, price_per_day, condition_grade, operating_hours, sharing_status, inter_hospital_earnings, last_sterilization_date) VALUES
(1, 1, 'Hamilton C1 Transport Ventilator', 'Hamilton Medical Pro 2025', 'Respiratory Transport', 2, 1200.00, 'A+ (Fully Calibrated)', '180 Hrs', 'active_sharing', 14400.00, 'Yesterday');

-- 8. RENTALS SEED
INSERT INTO rentals (id, rental_code, hospital_name, supplier_name, equipment_name, start_date, end_date, days, price_per_day, total_amount, commission_rate_used, commission_amount, supplier_amount, status, payment_status, payment_method_used, razorpay_payment_id, settlement_status, settled_at, pickup_status, driver_name, driver_phone, vehicle_plate, vehicle_type, is_extended, extension_log) VALUES
(1, 'MR-1001', 'City Care Multi-Speciality Hospital', 'MedEquip Solutions Pvt Ltd', 'Philips EverFlo Oxygen Concentrator 10L', '10 Sept 2026', '15 Sept 2026', 5, 500.00, 2500.00, 5.00, 125.00, 2375.00, 'pending_approval', 'pending', 'CARD', NULL, 'pending', NULL, 'waiting_for_payment', NULL, NULL, NULL, 'Medical Logistics Van', FALSE, NULL),
(2, 'MR-1002', 'City Care Multi-Speciality Hospital', 'MedEquip Solutions Pvt Ltd', 'Dräger Evita V300 Critical Care Ventilator', '20 Aug 2026', '25 Aug 2026', 5, 1800.00, 9000.00, 5.00, 450.00, 8550.00, 'active', 'captured', 'CARD', 'pay_MR1002_rzp_demo_8832', 'settled', '2026-08-25 14:30:00', 'driver_assigned', 'Ravi Kumar', '+91 98409 11223', 'TN 01 AB 1234', 'Medical Logistics Van', FALSE, NULL);

-- 9. COMMISSION RULES SEED
INSERT INTO commission_rules (id, rule_name, standard_rate, critical_care_rate, long_term_rate, gateway_interchange_fee, is_active) VALUES
(1, 'Standard Healthcare Marketplace Commission', 5.00, 4.00, 3.50, 1.80, TRUE);
