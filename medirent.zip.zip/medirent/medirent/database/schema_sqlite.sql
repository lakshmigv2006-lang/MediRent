-- ==============================================================================
-- MEDIRENT — SQLITE PORTABLE RELATIONAL DATABASE SCHEMA & SEED DATA
-- ==============================================================================

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT CHECK(role IN ('admin', 'hospital', 'supplier')) NOT NULL,
    organization TEXT NOT NULL,
    status TEXT CHECK(status IN ('active', 'pending', 'suspended')) DEFAULT 'active',
    is_verified INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. HOSPITALS TABLE
CREATE TABLE IF NOT EXISTS hospitals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    organization_name TEXT NOT NULL,
    registration_number TEXT NOT NULL UNIQUE,
    form_type TEXT DEFAULT 'FORM C — CERTIFICATE OF REGISTRATION',
    act_name TEXT DEFAULT 'The Tamil Nadu Clinical Establishments (Regulation) Act, 1997',
    gov_header TEXT DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header TEXT DEFAULT 'DIRECTORATE OF MEDICAL AND RURAL HEALTH SERVICES (DMS)',
    issuing_authority TEXT DEFAULT 'District Registering Authority, Chennai District',
    signatory_name TEXT DEFAULT 'Dr. K. S. Narayanan, MD, DPH',
    signatory_title TEXT DEFAULT 'Joint Director of Health Services & Member Secretary, DRA Chennai',
    chief_doctor TEXT NOT NULL,
    cmo_reg_no TEXT NOT NULL,
    facility_type TEXT DEFAULT 'Multi-Specialty Inpatient Hospital (300 Bedded)',
    address TEXT NOT NULL,
    latitude REAL DEFAULT 13.0420,
    longitude REAL DEFAULT 80.2520,
    valid_from TEXT NOT NULL,
    valid_until TEXT NOT NULL,
    docs_verified INTEGER DEFAULT 1,
    license_verified INTEGER DEFAULT 1,
    location_verified INTEGER DEFAULT 1,
    verification_status TEXT CHECK(verification_status IN ('pending', 'verified', 'rejected')) DEFAULT 'pending',
    rejection_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3. SUPPLIERS TABLE
CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    organization_name TEXT NOT NULL,
    registration_number TEXT NOT NULL UNIQUE,
    form_type TEXT DEFAULT 'FORM 20-B & FORM 21-B (WHOLESALE DRUG & MEDICAL DEVICE LICENSE)',
    act_name TEXT DEFAULT 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017',
    gov_header TEXT DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header TEXT DEFAULT 'DRUGS CONTROL ADMINISTRATION & CDSCO (SOUTH ZONE)',
    issuing_authority TEXT DEFAULT 'Office of the Assistant Director of Drugs Control, Zone-I, Chennai',
    signatory_name TEXT DEFAULT 'Thiru. P. Vijayabaskar, M.Pharm',
    signatory_title TEXT DEFAULT 'Licensing Authority & Assistant Director of Drugs Control, Chennai',
    gstin TEXT NOT NULL UNIQUE,
    pan_number TEXT NOT NULL,
    contact_person TEXT NOT NULL,
    facility_type TEXT DEFAULT 'Authorized Medical Device Importer, Stockist & Service Hub',
    address TEXT NOT NULL,
    latitude REAL DEFAULT 13.0850,
    longitude REAL DEFAULT 80.2101,
    valid_from TEXT NOT NULL,
    valid_until TEXT NOT NULL,
    docs_verified INTEGER DEFAULT 1,
    license_verified INTEGER DEFAULT 1,
    location_verified INTEGER DEFAULT 1,
    verification_status TEXT CHECK(verification_status IN ('pending', 'verified', 'rejected')) DEFAULT 'verified',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. SUPPLIER DOCUMENTS REPOSITORY
CREATE TABLE IF NOT EXISTS supplier_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    license_no TEXT NOT NULL,
    authority TEXT NOT NULL,
    gov_header TEXT DEFAULT 'GOVERNMENT OF TAMIL NADU',
    dept_header TEXT DEFAULT 'DRUGS CONTROL ADMINISTRATION & HEALTH SERVICES',
    act_name TEXT DEFAULT 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017',
    valid_from TEXT,
    valid_until TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_size TEXT DEFAULT '2.0 MB',
    verification_status TEXT CHECK(verification_status IN ('pending', 'verified', 'rejected')) DEFAULT 'verified',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
);

-- 5. EQUIPMENT TABLE
CREATE TABLE IF NOT EXISTS equipment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    manufacturer TEXT NOT NULL,
    model TEXT NOT NULL,
    price_per_day REAL NOT NULL,
    condition_rating TEXT DEFAULT 'excellent',
    inventory_status TEXT DEFAULT 'available',
    total_units INTEGER DEFAULT 1,
    available_units INTEGER DEFAULT 1,
    operating_hours TEXT DEFAULT '0 Hrs',
    ai_score INTEGER DEFAULT 95,
    distance_km REAL DEFAULT 2.4,
    registration_number TEXT NOT NULL,
    form_type TEXT DEFAULT 'BIOMEDICAL CALIBRATION & ELECTRICAL SAFETY COMPLIANCE REPORT',
    act_name TEXT DEFAULT 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards',
    gov_header TEXT DEFAULT 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)',
    dept_header TEXT DEFAULT 'CENTRAL BIOMEDICAL ENGINEERING QUALITY AUDIT COUNCIL',
    issuing_authority TEXT DEFAULT 'Accredited Calibration Lab CC-2981, Guindy Industrial Estate, Chennai',
    signatory_name TEXT DEFAULT 'Er. R. Senthil Kumar, M.E. (Biomedical)',
    signatory_title TEXT DEFAULT 'Chief Quality Inspector & Lead Biomedical Metrologist',
    valid_from TEXT NOT NULL,
    valid_until TEXT NOT NULL,
    last_maintenance_date TEXT DEFAULT '10 Sept 2026',
    next_maintenance_due TEXT DEFAULT '09 Sept 2027',
    maintenance_cycle TEXT DEFAULT 'Annual (1-Year Renewal)',
    service_engineer TEXT DEFAULT 'Er. R. Senthil Kumar',
    service_agency TEXT DEFAULT 'Authorized Service Center, Chennai',
    depot_location TEXT DEFAULT 'Anna Nagar East Hub (13.0850° N, 80.2101° E)',
    latitude REAL DEFAULT 13.0850,
    longitude REAL DEFAULT 80.2101,
    test_result TEXT,
    description TEXT,
    image_url TEXT,
    docs_verified INTEGER DEFAULT 1,
    license_verified INTEGER DEFAULT 1,
    location_verified INTEGER DEFAULT 1,
    verification_status TEXT DEFAULT 'verified',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
);

-- 6. HEEN EXCHANGE POOL TABLE
CREATE TABLE IF NOT EXISTS heen_exchange_pool (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_name TEXT NOT NULL,
    hospital_type TEXT NOT NULL,
    device TEXT NOT NULL,
    category TEXT NOT NULL,
    standby_quantity INTEGER DEFAULT 1,
    price_per_day REAL NOT NULL,
    availability TEXT DEFAULT 'Available Immediately (Surge Ready)',
    status_badge TEXT DEFAULT 'available',
    distance_km REAL NOT NULL,
    eta_mins INTEGER NOT NULL,
    condition_grade TEXT DEFAULT 'A+ (98% Pristine)',
    operating_hours TEXT DEFAULT '300 Operating Hrs',
    last_maintenance TEXT NOT NULL,
    next_calibration_due TEXT NOT NULL,
    sterilization_verified INTEGER DEFAULT 1,
    demand_index TEXT DEFAULT 'High Emergency Demand (Surge Allocation)',
    ai_match_score INTEGER DEFAULT 98,
    contact_doctor TEXT NOT NULL,
    location TEXT NOT NULL,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 7. MY HOSPITAL SHARED ASSETS TABLE
CREATE TABLE IF NOT EXISTS my_hospital_shared_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_id INTEGER NOT NULL,
    device TEXT NOT NULL,
    model TEXT NOT NULL,
    category TEXT NOT NULL,
    idle_quantity INTEGER DEFAULT 1,
    price_per_day REAL NOT NULL,
    condition_grade TEXT DEFAULT 'A+ (Fully Calibrated)',
    operating_hours TEXT DEFAULT '180 Hrs',
    sharing_status TEXT DEFAULT 'active_sharing',
    inter_hospital_earnings REAL DEFAULT 0.0,
    last_sterilization_date TEXT DEFAULT 'Yesterday',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE
);

-- 8. RENTALS TABLE
CREATE TABLE IF NOT EXISTS rentals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rental_code TEXT NOT NULL UNIQUE,
    hospital_name TEXT NOT NULL,
    supplier_name TEXT NOT NULL,
    equipment_name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    days INTEGER NOT NULL,
    price_per_day REAL NOT NULL,
    total_amount REAL NOT NULL,
    commission_rate_used REAL DEFAULT 5.0,
    commission_amount REAL NOT NULL,
    supplier_amount REAL NOT NULL,
    status TEXT DEFAULT 'pending_approval',
    payment_status TEXT DEFAULT 'pending',
    payment_method_used TEXT DEFAULT 'CARD',
    razorpay_payment_id TEXT,
    settlement_status TEXT DEFAULT 'pending',
    settled_at TEXT,
    pickup_status TEXT DEFAULT 'waiting_for_payment',
    driver_name TEXT,
    driver_phone TEXT,
    vehicle_plate TEXT,
    vehicle_type TEXT DEFAULT 'Medical Logistics Van',
    is_extended INTEGER DEFAULT 0,
    extension_log TEXT,
    decline_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 9. COMMISSION RULES TABLE
CREATE TABLE IF NOT EXISTS commission_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name TEXT NOT NULL,
    standard_rate REAL DEFAULT 5.0,
    critical_care_rate REAL DEFAULT 4.0,
    long_term_rate REAL DEFAULT 3.5,
    gateway_interchange_fee REAL DEFAULT 1.8,
    is_active INTEGER DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- SEED DATA
-- ==============================================================================
INSERT OR IGNORE INTO users (id, name, email, password_hash, role, organization, status, is_verified) VALUES
(1, 'Dr. Anand Ramanathan', 'hospital@medirent.io', 'Hospital@1', 'hospital', 'City Care Multi-Speciality Hospital', 'active', 1),
(2, 'Dr. Priya Sundaram', 'kaveri@medirent.io', 'Hospital@1', 'hospital', 'Kaveri Community Health Center', 'pending', 0),
(3, 'Rajesh Sharma', 'supplier@medirent.io', 'Supplier@1', 'supplier', 'MedEquip Solutions Pvt Ltd', 'active', 1),
(4, 'Platform Executive Admin', 'admin@medirent.io', 'Admin@123', 'admin', 'MediRent Operations HQ', 'active', 1);

INSERT OR IGNORE INTO hospitals (id, user_id, organization_name, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, chief_doctor, cmo_reg_no, facility_type, address, latitude, longitude, valid_from, valid_until, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 1, 'City Care Multi-Speciality Hospital', 'TN/CHE/HOSP/2024/008891', 'FORM C — CERTIFICATE OF REGISTRATION', 'The Tamil Nadu Clinical Establishments (Regulation) Act, 1997', 'GOVERNMENT OF TAMIL NADU', 'DIRECTORATE OF MEDICAL AND RURAL HEALTH SERVICES (DMS)', 'District Registering Authority, Chennai District', 'Dr. K. S. Narayanan, MD, DPH', 'Joint Director of Health Services & Member Secretary, DRA Chennai', 'Dr. Anand Ramanathan, MS, MCh (Cardio)', 'TNMC Registration No. 64821', 'Multi-Specialty Inpatient Hospital (300 Bedded)', 'Old No. 45, New No. 112, Anna Salai, Teynampet, Chennai, Tamil Nadu - 600018', 13.0420, 80.2520, '2024-04-01', '2029-03-31', 1, 1, 1, 'verified'),
(2, 2, 'Kaveri Community Health Center', 'TN/CBE/CLINIC/2025/001042', 'FORM B — PROVISIONAL CERTIFICATE OF REGISTRATION', 'The Clinical Establishments (Registration and Regulation) Act, 2010', 'GOVERNMENT OF TAMIL NADU', 'DIRECTORATE OF PUBLIC HEALTH AND PREVENTIVE MEDICINE', 'District Registering Authority, Coimbatore District', 'Dr. M. Soundararajan, MBBS, DLO', 'Deputy Director of Health Services, Coimbatore', 'Dr. Priya Sundaram, MD (General Medicine)', 'TNMC Registration No. 89204', 'Primary Care & Emergency Stabilization Clinic (50 Bedded)', 'SF-142, Avinashi Road, Peelamedu, Coimbatore, Tamil Nadu - 641004', 11.0250, 77.0100, '2025-08-15', '2027-08-14', 1, 0, 1, 'pending');

INSERT OR IGNORE INTO suppliers (id, user_id, organization_name, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, gstin, pan_number, contact_person, facility_type, address, latitude, longitude, valid_from, valid_until, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 3, 'MedEquip Solutions Pvt Ltd', 'TN/DDC/MD-WL/2024/004519', 'FORM 20-B & FORM 21-B (WHOLESALE DRUG & MEDICAL DEVICE LICENSE)', 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017', 'GOVERNMENT OF TAMIL NADU', 'DRUGS CONTROL ADMINISTRATION & CDSCO (SOUTH ZONE)', 'Office of the Assistant Director of Drugs Control, Zone-I, Chennai', 'Thiru. P. Vijayabaskar, M.Pharm', 'Licensing Authority & Assistant Director of Drugs Control, Chennai', '33AABCM9876Q1Z2', 'AABCM9876Q', 'Rajesh Sharma (Managing Director)', 'Authorized Medical Device Importer, Stockist & Service Hub', 'Plot No. 18, 2nd Avenue, Anna Nagar East, Chennai, Tamil Nadu - 600102', 13.0850, 80.2101, '2024-07-01', '2029-06-30', 1, 1, 1, 'verified');

INSERT OR IGNORE INTO supplier_documents (id, supplier_id, title, license_no, authority, gov_header, dept_header, act_name, valid_from, valid_until, file_name, file_size, verification_status) VALUES
(1, 1, 'CDSCO Form 20-B & 21-B Wholesale Drug & Medical Device License', 'TN/DDC/MD-WL/2024/004519', 'Drugs Control Administration, Government of Tamil Nadu', 'GOVERNMENT OF TAMIL NADU — DRUGS CONTROL ADMINISTRATION & CDSCO', 'CENTRAL DRUGS STANDARD CONTROL ORGANIZATION (SOUTH ZONE)', 'The Drugs and Cosmetics Act, 1940 & Medical Device Rules, 2017', '2024-07-01', '30 June 2029', 'CDSCO_Form20B_21B_MedEquip_2024.pdf', '2.4 MB', 'verified'),
(2, 1, 'GSTIN Registration Certificate (Form GST REG-06)', '33AABCM9876Q1Z2', 'Central Board of Indirect Taxes and Customs (CBIC)', 'GOVERNMENT OF INDIA — GOODS AND SERVICES TAX IDENTIFICATION', 'COMMISSIONERATE OF CENTRAL TAX & TAMIL NADU STATE GST', 'Central Goods and Services Tax Act, 2017', '2017-07-01', 'Active (Regular)', 'GSTIN_Registration_33AABCM9876Q1Z2.pdf', '1.1 MB', 'verified'),
(3, 1, 'NABL Metrology Calibration Hub ISO/IEC 17025 Certificate', 'NABL/LAB/TN-CC2981', 'National Accreditation Board for Testing & Calibration Laboratories', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'DEPARTMENT OF SCIENCE & TECHNOLOGY, GOVERNMENT OF INDIA', 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards', '2024-09-16', '15 September 2028', 'NABL_Calibration_Accreditation_CC2981.pdf', '3.8 MB', 'verified'),
(4, 1, 'Greater Chennai Corporation Trade License & Fire NOC', 'GCC/ZN-08/TL/2024/99120', 'Revenue & Health Department, Zone 8 Chennai', 'GREATER CHENNAI CORPORATION — PUBLIC HEALTH & REVENUE DEPARTMENT', 'ZONE 8 (ANNA NAGAR) SANITARY & DANGEROUS/OFFENSIVE TRADE LICENSING', 'Chennai City Municipal Corporation Act, 1919 & Fire Prevention Act', '2024-04-01', '31 March 2028', 'GCC_Trade_License_AnnaNagar_Depot.pdf', '1.5 MB', 'verified');

INSERT OR IGNORE INTO equipment (id, supplier_id, name, category, manufacturer, model, price_per_day, condition_rating, inventory_status, total_units, available_units, operating_hours, ai_score, distance_km, registration_number, form_type, act_name, gov_header, dept_header, issuing_authority, signatory_name, signatory_title, valid_from, valid_until, last_maintenance_date, next_maintenance_due, maintenance_cycle, service_engineer, service_agency, depot_location, latitude, longitude, test_result, description, image_url, docs_verified, license_verified, location_verified, verification_status) VALUES
(1, 1, 'Philips EverFlo Oxygen Concentrator 10L', 'Respiratory Support', 'Philips Healthcare', 'EverFlo 10L Ultra-Quiet', 500.0, 'excellent', 'available', 4, 3, '520 Hrs', 96, 2.40, 'NABL/CAL/2026/TN-7741', 'BIOMEDICAL CALIBRATION & ELECTRICAL SAFETY COMPLIANCE REPORT', 'ISO/IEC 17025:2017 & IEC 60601-1 Medical Electrical Equipment Standards', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'CENTRAL BIOMEDICAL ENGINEERING QUALITY AUDIT COUNCIL', 'Accredited Calibration Lab CC-2981, Guindy Industrial Estate, Chennai', 'Er. R. Senthil Kumar, M.E. (Biomedical)', 'Chief Quality Inspector & Lead Biomedical Metrologist', '2026-09-10', '2027-09-09', '10 Sept 2026', '09 Sept 2027', 'Annual (1-Year Renewal)', 'Er. R. Senthil Kumar', 'Philips Healthcare Authorized Service Center, Chennai', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'Oxygen Purity: 95.4% @ 10 LPM (PASSED), Leakage Current: < 100uA (SAFE)', 'High-purity medical grade 10L continuous flow oxygen concentrator with integrated OPI.', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80', 1, 1, 1, 'verified'),
(2, 1, 'Dräger Evita V300 Critical Care Ventilator', 'Respiratory Support', 'Dräger Medical', 'Evita V300', 1800.0, 'new', 'on_rent', 2, 1, '280 Hrs', 94, 4.10, 'NABL/CAL/2026/TN-8902', 'INTENSIVE CARE VENTILATOR PERFORMANCE CALIBRATION CERTIFICATE', 'ISO 80601-2-12 & IEC 60601-1-2 EMC Compliance Guidelines', 'CENTRAL DRUGS STANDARD CONTROL ORGANIZATION (CDSCO)', 'MEDICAL DEVICE TESTING & VERIFICATION LABORATORY, TAMIL NADU', 'Dräger Authorized Biomedical Metrology Laboratory, Chennai', 'Dr. S. Meenakshi, Ph.D (Clinical Engg)', 'Senior Biomedical Consultant & Testing Officer', '2026-08-20', '2027-08-19', '20 Aug 2026', '19 Aug 2027', 'Annual (1-Year Renewal)', 'Dr. S. Meenakshi', 'Dräger Biomedical Metrology Laboratory, Chennai', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'Tidal Volume Delivery Accuracy: 99.2% (PASSED), PEEP Calibration: 100% (SAFE)', 'Advanced intensive care ventilator for adult and pediatric patients.', 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80', 1, 1, 1, 'verified'),
(3, 1, 'GE Healthcare B40 Multiparameter Monitor', 'Patient Monitoring', 'GE Healthcare', 'B40 Patient Monitor', 450.0, 'excellent', 'available', 5, 5, '190 Hrs', 92, 2.40, 'NABL/CAL/2026/TN-9921', 'MULTIPARAMETER ICU PATIENT MONITOR CALIBRATION CERTIFICATE', 'IEC 60601-2-49 & NABL Quality Accreditations', 'NATIONAL ACCREDITATION BOARD FOR TESTING AND CALIBRATION LABORATORIES (NABL)', 'BIOMEDICAL INSTRUMENTATION DIVISION', 'GE Certified Calibration Center, Chennai', 'Er. Anand Varma', 'Senior Biomedical Engineer', '2026-07-15', '2027-07-14', '15 July 2026', '14 July 2027', 'Annual (1-Year Renewal)', 'Er. Anand Varma', 'GE Healthcare Metrology Hub, Guindy', 'Anna Nagar East Hub (13.0850° N, 80.2101° E)', 13.0850, 80.2101, 'ECG, SpO2 & NIBP Precision: 99.8% (PASSED)', '12.1-inch color display monitor for ECG, SpO2, NIBP, Dual Temp, and Respiration monitoring.', 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600&auto=format&fit=crop&q=80', 1, 1, 1, 'verified');

INSERT OR IGNORE INTO heen_exchange_pool (id, hospital_name, hospital_type, device, category, standby_quantity, price_per_day, availability, status_badge, distance_km, eta_mins, condition_grade, operating_hours, last_maintenance, next_calibration_due, sterilization_verified, demand_index, ai_match_score, contact_doctor, location, image_url) VALUES
(1, 'Apollo Hospitals Greams Road', 'Quaternary Care Medical Center (550 Beds)', 'Maquet SERVO-u Advanced ICU Mechanical Ventilator', 'Critical Care Ventilation', 2, 1600.0, 'Available Immediately (Surge Ready)', 'available', 1.80, 25, 'A+ (98% Pristine)', '420 Operating Hrs', '12 August 2026', '11 August 2027', 1, 'High Emergency Demand (Surge Allocation)', 98, 'Dr. V. Rajesh, Head of Critical Care Medicine', 'Greams Lane, Thousand Lights, Chennai (1.8 km)', 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80'),
(2, 'Kauvery Hospital Alwarpet', 'Super-Specialty Tertiary Hospital (200 Beds)', 'Medtronic Puritan Bennett 980 ICU Ventilator', 'Critical Care Ventilation', 1, 1950.0, 'Available for H2H Rent (Idle Asset)', 'available', 3.20, 35, 'A (100% Calibrated)', '310 Operating Hrs', '28 July 2026', '27 July 2027', 1, 'Demand-Based Rapid Transfer', 96, 'Dr. C. Suresh, Biomedical Director', 'TTK Road, Alwarpet, Chennai (3.2 km)', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80');

INSERT OR IGNORE INTO my_hospital_shared_assets (id, hospital_id, device, model, category, idle_quantity, price_per_day, condition_grade, operating_hours, sharing_status, inter_hospital_earnings, last_sterilization_date) VALUES
(1, 1, 'Hamilton C1 Transport Ventilator', 'Hamilton Medical Pro 2025', 'Respiratory Transport', 2, 1200.0, 'A+ (Fully Calibrated)', '180 Hrs', 'active_sharing', 14400.0, 'Yesterday');

INSERT OR IGNORE INTO rentals (id, rental_code, hospital_name, supplier_name, equipment_name, start_date, end_date, days, price_per_day, total_amount, commission_rate_used, commission_amount, supplier_amount, status, payment_status, payment_method_used, razorpay_payment_id, settlement_status, settled_at, pickup_status, driver_name, driver_phone, vehicle_plate, vehicle_type, is_extended, extension_log) VALUES
(1, 'MR-1001', 'City Care Multi-Speciality Hospital', 'MedEquip Solutions Pvt Ltd', 'Philips EverFlo Oxygen Concentrator 10L', '10 Sept 2026', '15 Sept 2026', 5, 500.0, 2500.0, 5.0, 125.0, 2375.0, 'pending_approval', 'pending', 'CARD', NULL, 'pending', NULL, 'waiting_for_payment', NULL, NULL, NULL, 'Medical Logistics Van', 0, NULL),
(2, 'MR-1002', 'City Care Multi-Speciality Hospital', 'MedEquip Solutions Pvt Ltd', 'Dräger Evita V300 Critical Care Ventilator', '20 Aug 2026', '25 Aug 2026', 5, 1800.0, 9000.0, 5.0, 450.0, 8550.0, 'active', 'captured', 'CARD', 'pay_MR1002_rzp_demo_8832', 'settled', '2026-08-25 14:30:00', 'driver_assigned', 'Ravi Kumar', '+91 98409 11223', 'TN 01 AB 1234', 'Medical Logistics Van', 0, NULL);

INSERT OR IGNORE INTO commission_rules (id, rule_name, standard_rate, critical_care_rate, long_term_rate, gateway_interchange_fee, is_active) VALUES
(1, 'Standard Healthcare Marketplace Commission', 5.0, 4.0, 3.5, 1.8, 1);
