# MediRent — Verified Healthcare Equipment Rental Platform

**Tagline:** *Verified. Reliable. Accessible.*  
**Hackathon MVP — Full-Stack Healthcare SaaS**

---

## 🏗️ Architecture & Technology Stack

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Frontend** | React.js, React Router, Axios, CSS3, Inter Font | Responsive 3-role portal (Admin, Supplier, Hospital) |
| **Backend** | Python 3.10+, FastAPI, Uvicorn, Pydantic | Asynchronous REST APIs, JWT Auth & RBAC |
| **Database** | MySQL (with SQLAlchemy ORM & SQLite fallback) | Relational schema with foreign keys and indexes |
| **AI / ML** | Python, Scikit-learn, Haversine Distance | Multi-factor weighted equipment ranking engine |
| **Payments** | Razorpay Test Mode Gateway | Order creation, HMAC verification, 5% fee / 95% supplier split |
| **Maps & GPS** | Google Maps API & Location Awareness | Distance calculation & 1-click direction links |

---

## 📁 Repository Structure

```text
medirent/
│
├── frontend/ (or client/)
│   ├── src/
│   │   ├── components/       # Reusable UI cards, tables, badges, modals
│   │   ├── pages/            # Admin, Hospital, Supplier, Public pages
│   │   ├── layouts/          # Responsive Sidebar & Topbar Shells
│   │   ├── services/         # Axios API client & mock fallbacks
│   │   ├── context/          # Auth & Toast notifications context
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── main.py           # FastAPI entry point, CORS, startup seeding
│   │   ├── models/           # SQLAlchemy ORM models matching MySQL schema
│   │   ├── schemas/          # Pydantic request/response validation
│   │   ├── routes/           # Auth, Admin, Hospital, Supplier, Payments
│   │   ├── auth/             # JWT token creation, decoding & RBAC guards
│   │   ├── database/         # SQLAlchemy engine & session dependency
│   │   ├── ai/               # Scikit-learn recommendation engine
│   │   └── payments/         # Razorpay client & HMAC signature verification
│   ├── requirements.txt      # Python dependencies
│   ├── run_backend.bat       # 1-Click Windows FastAPI launcher
│   └── .env
│
├── database/
│   └── schema.sql            # MySQL schema with foreign keys, indexes & seeds
│
├── medirent-preview.html      # Standalone zero-dependency browser preview
├── run-app.bat               # 1-Click Frontend preview launcher
├── .env.example
└── README.md
```

---

## ⚡ Quick Start Instructions

### 1. Fast Browser Preview (Immediate)
* Double-click **`run-app.bat`** or open **`http://localhost:3000/`** in your browser.

### 2. Run FastAPI Backend (Python)
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
* Interactive API Documentation (Swagger): [**http://localhost:8000/docs**](http://localhost:8000/docs)
* Redoc: [**http://localhost:8000/redoc**](http://localhost:8000/redoc)

### 3. Run React Frontend
```bash
cd client
npm install
npm start
```

### 4. Setup MySQL Database (Optional)
```bash
mysql -u root -p < database/schema.sql
```

---

## 🔒 Master Verified Demo Credentials

| Role | Email | Password | Access Rights |
| :--- | :--- | :--- | :--- |
| **👑 Admin** | `admin@medirent.io` | `Admin@123` | Executive dashboard, verifications, commission & payouts |
| **🏥 Hospital** | `hospital@medirent.io` | `Hospital@1` | Browse equipment, AI recommendations, Razorpay payments, driver assignment |
| **🏭 Supplier** | `supplier@medirent.io` | `Supplier@1` | Inventory, rental approvals, handover confirmation, earnings |

---

## 💳 Marketplace Commission Split Architecture

$$\text{Gross Rental Amount: } ₹2,500$$
$$\Downarrow$$
$$\text{MediRent Platform Fee (5\%): } ₹125 \quad+\quad \text{Net Supplier Share (95\%): } ₹2,375$$
