const mongoose = require('mongoose');

const maintenanceSchema = new mongoose.Schema(
  {
    equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment', required: true },
    scheduledFor: Date,
    performedAt: Date,
    performedBy: String,
    cost: { type: Number, default: 0 },
    notes: String,
    status: { type: String, enum: ['scheduled', 'in_progress', 'completed'], default: 'scheduled' },
  },
  { timestamps: true }
);
module.exports = mongoose.model('Maintenance', maintenanceSchema);
