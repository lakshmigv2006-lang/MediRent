const mongoose = require('mongoose');

const equipmentDocumentSchema = new mongoose.Schema(
  {
    documentType: { type: String, required: true }, // 'certificate', 'service_record', 'calibration_proof', 'compliance'
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    fileType: { type: String, default: 'application/pdf' },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

const equipmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    manufacturer: String,
    model: String,
    serialNumber: String,
    description: String,
    specifications: { type: Map, of: String },
    images: [String],
    pricePerDay: { type: Number, required: true, min: 0 },
    securityDeposit: { type: Number, default: 0, min: 0 },
    quantity: { type: Number, default: 1, min: 0 },
    available: { type: Number, default: 1, min: 0 },
    condition: { type: String, enum: ['new', 'excellent', 'good', 'fair'], default: 'good' },
    location: String,
    maintenanceStatus: {
      type: String,
      enum: ['up_to_date', 'service_due', 'under_maintenance', 'not_available'],
      default: 'up_to_date',
    },
    lastServiceDate: Date,
    nextServiceDate: Date,
    warranty: String,
    maintenanceCertificate: String,
    documents: [equipmentDocumentSchema],
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    ownerType: { type: String, enum: ['supplier', 'hospital'], required: true },
    verificationStatus: {
      type: String,
      enum: ['pending', 'verified', 'rejected'],
      default: 'verified',
    },
    rejectionReason: String,
    verifiedAt: Date,
    ratingAvg: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  },
  { timestamps: true }
);

equipmentSchema.index({ name: 'text', description: 'text', location: 'text', manufacturer: 'text', model: 'text' });
module.exports = mongoose.model('Equipment', equipmentSchema);
