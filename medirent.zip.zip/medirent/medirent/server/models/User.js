const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const documentSchema = new mongoose.Schema(
  {
    documentType: { type: String, required: true }, // e.g. 'hospital_registration', 'gst_pan', 'authorization', 'business_license', 'ownership_proof'
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    fileType: { type: String, default: 'application/pdf' },
    verificationStatus: {
      type: String,
      enum: ['pending', 'verified', 'rejected', 'resubmission_required'],
      default: 'pending',
    },
    rejectionReason: String,
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ['hospital', 'supplier', 'admin'], required: true },
    phone: String,
    address: String,
    city: String,
    state: String,
    pincode: String,
    organizationName: String, // hospital name or supplier business name
    registrationNumber: String, // hospital or supplier registration/license #
    hospitalType: String, // e.g. 'Tertiary Care', 'Multi-Specialty', 'Clinic', 'General Hospital'
    businessType: String, // e.g. 'Authorized Distributor', 'Equipment Manufacturer', 'Rental Partner'
    contactPerson: String,
    authorizedPerson: String,
    latitude: { type: Number, default: 19.0760 },
    longitude: { type: Number, default: 72.8777 },
    googleMapsUrl: String,
    verificationStatus: {
      type: String,
      enum: ['pending', 'verified', 'rejected', 'resubmission_required'],
      default: 'pending',
    },
    rejectionReason: String,
    verifiedAt: Date,
    status: { type: String, enum: ['pending', 'active', 'suspended'], default: 'active' },
    documents: [documentSchema],
    avatar: String,
    resetToken: String,
    resetTokenExpires: Date,
  },
  { timestamps: true }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.comparePassword = function (plain) {
  return bcrypt.compare(plain, this.password);
};

module.exports = mongoose.model('User', userSchema);
