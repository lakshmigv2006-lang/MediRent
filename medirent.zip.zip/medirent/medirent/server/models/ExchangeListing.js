const mongoose = require('mongoose');

// Idle equipment posted by hospitals for hospital-to-hospital rental (HEEN)
const exchangeSchema = new mongoose.Schema(
  {
    hospital: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment', required: true },
    availableFrom: Date,
    availableTo: Date,
    note: String,
    status: { type: String, enum: ['available', 'reserved', 'closed'], default: 'available' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('ExchangeListing', exchangeSchema);
