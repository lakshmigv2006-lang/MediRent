const mongoose = require('mongoose');
const schema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: ['approval', 'delivery', 'return', 'payment', 'maintenance', 'system'],
      default: 'system',
    },
    title: String,
    message: String,
    link: String,
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);
module.exports = mongoose.model('Notification', schema);
