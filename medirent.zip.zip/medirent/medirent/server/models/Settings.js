const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true, default: 'platform_config' },
    commissionRate: { type: Number, default: 5.0 }, // default 5%
    platformName: { type: String, default: 'MediRent' },
    tagline: { type: String, default: 'Verified. Reliable. Accessible.' },
    supportEmail: { type: String, default: 'support@medirent.io' },
    supportPhone: { type: String, default: '+91 98765 43210' },
    razorpayKeyId: { type: String, default: 'rzp_test_medirent2026' },
    razorpayTestMode: { type: Boolean, default: true },
    autoVerifyEquipment: { type: Boolean, default: false },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Settings', settingsSchema);
