const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema(
  {
    rental: { type: mongoose.Schema.Types.ObjectId, ref: 'Rental', required: true },
    number: { type: String, unique: true, required: true },
    issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    issuedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    amount: Number,
    tax: { type: Number, default: 0 },
    total: Number,
    status: { type: String, enum: ['unpaid', 'paid', 'refunded'], default: 'unpaid' },
    dueDate: Date,
  },
  { timestamps: true }
);
module.exports = mongoose.model('Invoice', invoiceSchema);
