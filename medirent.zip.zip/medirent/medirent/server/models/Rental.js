const mongoose = require('mongoose');

const rentalSchema = new mongoose.Schema(
  {
    rentalCode: { type: String, unique: true }, // e.g. 'MR-1001'
    equipment: { type: mongoose.Schema.Types.ObjectId, ref: 'Equipment', required: true },
    renter: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // hospital/clinic
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },  // supplier OR hospital (HEEN)
    ownerType: { type: String, enum: ['supplier', 'hospital'], required: true },
    quantity: { type: Number, default: 1, min: 1 },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    days: Number,
    pricePerDay: Number,
    rentalAmount: Number,
    commissionAmount: { type: Number, default: 0 }, // e.g. 5% platform fee
    supplierAmount: { type: Number, default: 0 },   // 95% to supplier
    securityDeposit: { type: Number, default: 0 },
    totalAmount: Number,
    emergency: { type: Boolean, default: false },
    notes: String,
    status: {
      type: String,
      enum: [
        'requested',
        'pending',
        'approved',
        'rejected',
        'payment_pending',
        'paid',
        'ready_for_pickup',
        'pickup_scheduled',
        'driver_assigned',
        'handed_over',
        'picked_up',
        'out_for_delivery',
        'delivered',
        'active',
        'renewal_requested',
        'return_requested',
        'returned',
        'completed',
        'cancelled',
      ],
      default: 'pending',
    },
    paymentStatus: {
      type: String,
      enum: ['pending', 'captured', 'failed', 'refunded'],
      default: 'pending',
    },
    razorpayOrderId: String,
    razorpayPaymentId: String,
    razorpaySignature: String,
    settlementStatus: {
      type: String,
      enum: ['pending', 'settled'],
      default: 'pending',
    },
    settledAt: Date,
    pickupStatus: {
      type: String,
      enum: [
        'waiting_for_payment',
        'ready_for_pickup',
        'pickup_scheduled',
        'driver_assigned',
        'handed_over',
        'picked_up',
        'active',
      ],
      default: 'waiting_for_payment',
    },
    pickupDetails: {
      pickupDate: Date,
      pickupTime: String,
      driverName: String,
      driverPhone: String,
      vehicleNumber: String,
      vehicleType: String,
      pickupAddress: String,
      handedOverAt: Date,
    },
    renewalRequests: [
      {
        requestedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        currentEndDate: Date,
        requestedEndDate: Date,
        additionalDays: Number,
        additionalAmount: Number,
        status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
        approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        createdAt: { type: Date, default: Date.now },
      },
    ],
    returnDetails: {
      requestedDate: Date,
      returnDate: Date,
      condition: { type: String, enum: ['good', 'fair', 'damaged', 'operational'], default: 'good' },
      damageNotes: String,
      damageImageUrl: String,
      status: { type: String, enum: ['return_requested', 'returned', 'completed'], default: 'return_requested' },
    },
    isExchange: { type: Boolean, default: false }, // HEEN
    damageReport: String,
    timeline: [
      {
        status: String,
        at: { type: Date, default: Date.now },
        by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        note: String,
      },
    ],
  },
  { timestamps: true }
);

rentalSchema.pre('save', function (next) {
  if (!this.rentalCode) {
    this.rentalCode = 'MR-' + Math.floor(1000 + Math.random() * 9000);
  }
  if (!this.rentalAmount && this.totalAmount) {
    this.rentalAmount = this.totalAmount;
  }
  if (!this.commissionAmount && this.rentalAmount) {
    this.commissionAmount = Math.round(this.rentalAmount * 0.05);
    this.supplierAmount = this.rentalAmount - this.commissionAmount;
  }
  next();
});

module.exports = mongoose.model('Rental', rentalSchema);
