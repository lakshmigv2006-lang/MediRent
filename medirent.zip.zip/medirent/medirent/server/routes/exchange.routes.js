const router = require('express').Router();
const c = require('../controllers/exchange.controller');
const { requireAuth } = require('../middleware/auth');
router.get('/', c.list);
router.post('/', requireAuth, c.create);
router.patch('/:id/close', requireAuth, c.close);
module.exports = router;
