const router = require('express').Router();
const c = require('../controllers/invoice.controller');
const { requireAuth } = require('../middleware/auth');
router.use(requireAuth);
router.get('/', c.list);
router.get('/:id', c.get);
router.patch('/:id/pay', c.pay);
module.exports = router;
