const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/auth.controller');
const { requireAuth } = require('../middleware/auth');

router.post(
  '/register',
  [
    body('name').notEmpty(),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('role').isIn(['hospital', 'supplier', 'admin']),
  ],
  c.register
);
router.post('/login', c.login);
router.post('/forgot', c.forgotPassword);
router.post('/reset', c.resetPassword);
router.get('/me', requireAuth, c.me);
router.put('/me', requireAuth, c.updateMe);
router.put('/change-password', requireAuth, c.changePassword);

module.exports = router;
