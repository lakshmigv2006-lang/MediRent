const router = require('express').Router();
const c = require('../controllers/equipment.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', c.list);
router.get('/:id', c.get);
router.post('/', requireAuth, requireRole('supplier', 'hospital', 'admin'), upload.array('images', 5), c.create);
router.put('/:id', requireAuth, requireRole('supplier', 'hospital', 'admin'), upload.array('images', 5), c.update);
router.delete('/:id', requireAuth, requireRole('supplier', 'hospital', 'admin'), c.remove);

module.exports = router;
