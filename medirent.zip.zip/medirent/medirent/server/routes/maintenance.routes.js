const router = require('express').Router();
const c = require('../controllers/maintenance.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
router.use(requireAuth, requireRole('supplier', 'admin'));
router.get('/', c.list);
router.post('/', c.create);
router.patch('/:id', c.update);
module.exports = router;
