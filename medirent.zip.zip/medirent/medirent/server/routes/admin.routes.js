const router = require('express').Router();
const c = require('../controllers/admin.controller');
const { requireAuth, requireRole } = require('../middleware/auth');

// All admin routes require admin role
router.use(requireAuth, requireRole('admin'));

// Dashboard & Verification Desk
router.get('/dashboard', c.getDashboard);
router.get('/verification', c.getVerificationQueue);

// Hospitals verification & management
router.get('/hospitals', c.getHospitals);
router.put('/hospitals/:id/approve', c.approveHospital);
router.put('/hospitals/:id/reject', c.rejectHospital);

// Suppliers verification & management
router.get('/suppliers', c.getSuppliers);
router.put('/suppliers/:id/approve', c.approveSupplier);
router.put('/suppliers/:id/reject', c.rejectSupplier);

// Equipment verification & catalog
router.get('/equipment', c.getEquipment);
router.put('/equipment/:id/approve', c.approveEquipment);
router.put('/equipment/:id/reject', c.rejectEquipment);

// Rental monitoring
router.get('/rentals', c.getRentals);

// Payments & Commission
router.get('/payments', c.getPayments);
router.patch('/payments/:id/settle', c.settlePayment);
router.get('/commission', c.getCommission);

// Renewals & Returns
router.get('/renewals', c.getRenewals);
router.get('/returns', c.getReturns);

// Platform Settings
router.get('/settings', c.getSettings);
router.put('/settings', c.updateSettings);

module.exports = router;
