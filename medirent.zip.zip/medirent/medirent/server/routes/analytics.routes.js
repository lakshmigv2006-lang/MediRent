const router = require('express').Router();
const c = require('../controllers/analytics.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
router.get('/admin', requireAuth, requireRole('admin'), c.admin);
router.get('/supplier', requireAuth, requireRole('supplier'), c.supplier);
router.get('/hospital', requireAuth, requireRole('hospital'), c.hospital);
module.exports = router;
