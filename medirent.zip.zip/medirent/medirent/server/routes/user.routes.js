const router = require('express').Router();
const c = require('../controllers/user.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
router.use(requireAuth, requireRole('admin'));
router.get('/', c.list);
router.patch('/:id/status', c.setStatus);
router.delete('/:id', c.remove);
module.exports = router;
