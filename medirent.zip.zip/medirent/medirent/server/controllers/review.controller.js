const Review = require('../models/Review');
const Equipment = require('../models/Equipment');

exports.create = async (req, res, next) => {
  try {
    const { equipment, rating, comment } = req.body;
    const review = await Review.create({ equipment, rating, comment, user: req.user._id });
    const agg = await Review.aggregate([
      { $match: { equipment: review.equipment } },
      { $group: { _id: '$equipment', avg: { $avg: '$rating' }, count: { $sum: 1 } } },
    ]);
    if (agg[0]) {
      await Equipment.findByIdAndUpdate(equipment, {
        ratingAvg: agg[0].avg, ratingCount: agg[0].count,
      });
    }
    res.status(201).json({ review });
  } catch (e) { next(e); }
};

exports.forEquipment = async (req, res, next) => {
  try {
    const items = await Review.find({ equipment: req.params.id })
      .populate('user', 'name organizationName')
      .sort('-createdAt');
    res.json({ items });
  } catch (e) { next(e); }
};
