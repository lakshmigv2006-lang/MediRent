const User = require('../models/User');
const Equipment = require('../models/Equipment');
const Rental = require('../models/Rental');
const Invoice = require('../models/Invoice');

exports.admin = async (_req, res, next) => {
  try {
    const [hospitals, suppliers, equipment, rentals, revenueAgg, mostRented, pending] = await Promise.all([
      User.countDocuments({ role: 'hospital' }),
      User.countDocuments({ role: 'supplier' }),
      Equipment.countDocuments(),
      Rental.countDocuments(),
      Invoice.aggregate([{ $match: { status: 'paid' } }, { $group: { _id: null, sum: { $sum: '$total' } } }]),
      Rental.aggregate([
        { $group: { _id: '$equipment', count: { $sum: 1 } } },
        { $sort: { count: -1 } }, { $limit: 5 },
        { $lookup: { from: 'equipment', localField: '_id', foreignField: '_id', as: 'equipment' } },
        { $unwind: '$equipment' },
      ]),
      Rental.countDocuments({ status: 'pending' }),
    ]);

    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    const monthly = await Rental.aggregate([
      { $match: { createdAt: { $gte: start } } },
      { $group: {
          _id: { y: { $year: '$createdAt' }, m: { $month: '$createdAt' } },
          count: { $sum: 1 }, revenue: { $sum: '$totalAmount' },
      } },
      { $sort: { '_id.y': 1, '_id.m': 1 } },
    ]);

    res.json({
      counts: { hospitals, suppliers, equipment, rentals, pending },
      revenue: revenueAgg[0]?.sum || 0,
      mostRented, monthly,
    });
  } catch (e) { next(e); }
};

exports.supplier = async (req, res, next) => {
  try {
    const owner = req.user._id;
    const [inv, activeRentals, pending, revenueAgg] = await Promise.all([
      Equipment.countDocuments({ owner }),
      Rental.countDocuments({ owner, status: { $in: ['active', 'delivered', 'out_for_delivery'] } }),
      Rental.countDocuments({ owner, status: 'pending' }),
      Invoice.aggregate([{ $match: { issuedBy: owner, status: 'paid' } }, { $group: { _id: null, sum: { $sum: '$total' } } }]),
    ]);
    res.json({ inventory: inv, activeRentals, pending, revenue: revenueAgg[0]?.sum || 0 });
  } catch (e) { next(e); }
};

exports.hospital = async (req, res, next) => {
  try {
    const renter = req.user._id;
    const [active, pending, upcoming, spendingAgg] = await Promise.all([
      Rental.countDocuments({ renter, status: { $in: ['active', 'delivered', 'out_for_delivery'] } }),
      Rental.countDocuments({ renter, status: 'pending' }),
      Rental.find({ renter, endDate: { $gte: new Date() }, status: { $in: ['active', 'delivered'] } })
        .sort('endDate').limit(5).populate('equipment', 'name'),
      Invoice.aggregate([{ $match: { issuedTo: renter, status: 'paid' } }, { $group: { _id: null, sum: { $sum: '$total' } } }]),
    ]);
    res.json({ active, pending, upcoming, spending: spendingAgg[0]?.sum || 0 });
  } catch (e) { next(e); }
};
