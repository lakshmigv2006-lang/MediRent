const Maintenance = require('../models/Maintenance');
const Equipment = require('../models/Equipment');

exports.list = async (req, res, next) => {
  try {
    const f = {};
    if (req.query.equipment) f.equipment = req.query.equipment;
    // Suppliers see maintenance for their own equipment
    if (req.user.role === 'supplier') {
      const eqIds = await Equipment.find({ owner: req.user._id }).distinct('_id');
      f.equipment = { $in: eqIds };
    }
    const items = await Maintenance.find(f).populate('equipment', 'name').sort('-scheduledFor');
    res.json({ items });
  } catch (e) { next(e); }
};
exports.create = async (req, res, next) => {
  try { res.status(201).json({ item: await Maintenance.create(req.body) }); } catch (e) { next(e); }
};
exports.update = async (req, res, next) => {
  try {
    const item = await Maintenance.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ item });
  } catch (e) { next(e); }
};
