const Equipment = require('../models/Equipment');

exports.list = async (req, res, next) => {
  try {
    const {
      q, category, minPrice, maxPrice, condition, location, available, owner,
      ownerType, page = 1, limit = 12, sort = '-createdAt',
    } = req.query;
    const f = { status: 'active' };
    if (q) f.$text = { $search: q };
    if (category) f.category = category;
    if (condition) f.condition = condition;
    if (location) f.location = new RegExp(location, 'i');
    if (owner) f.owner = owner;
    if (ownerType) f.ownerType = ownerType;
    if (available === 'true') f.available = { $gt: 0 };
    if (minPrice || maxPrice) {
      f.pricePerDay = {};
      if (minPrice) f.pricePerDay.$gte = Number(minPrice);
      if (maxPrice) f.pricePerDay.$lte = Number(maxPrice);
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Equipment.find(f).populate('category owner', 'name organizationName city').sort(sort).skip(skip).limit(Number(limit)),
      Equipment.countDocuments(f),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) { next(e); }
};

exports.get = async (req, res, next) => {
  try {
    const item = await Equipment.findById(req.params.id)
      .populate('category')
      .populate('owner', 'name organizationName email phone city');
    if (!item) return res.status(404).json({ message: 'Not found' });
    res.json({ item });
  } catch (e) { next(e); }
};

exports.create = async (req, res, next) => {
  try {
    const files = (req.files || []).map((f) => `/uploads/${f.filename}`);
    const item = await Equipment.create({
      ...req.body,
      images: files.length ? files : (req.body.images || []),
      owner: req.user._id,
      ownerType: req.user.role === 'supplier' ? 'supplier' : 'hospital',
      available: Number(req.body.quantity || 1),
    });
    res.status(201).json({ item });
  } catch (e) { next(e); }
};

exports.update = async (req, res, next) => {
  try {
    const eq = await Equipment.findById(req.params.id);
    if (!eq) return res.status(404).json({ message: 'Not found' });
    if (String(eq.owner) !== String(req.user._id) && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    Object.assign(eq, req.body);
    if (req.files && req.files.length) eq.images = req.files.map((f) => `/uploads/${f.filename}`);
    await eq.save();
    res.json({ item: eq });
  } catch (e) { next(e); }
};

exports.remove = async (req, res, next) => {
  try {
    const eq = await Equipment.findById(req.params.id);
    if (!eq) return res.status(404).json({ message: 'Not found' });
    if (String(eq.owner) !== String(req.user._id) && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    await eq.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (e) { next(e); }
};
