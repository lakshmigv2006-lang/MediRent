const crypto = require('crypto');
const { validationResult } = require('express-validator');
const User = require('../models/User');
const { sign } = require('../utils/jwt');

const sanitize = (u) => {
  const o = u.toObject ? u.toObject() : u;
  delete o.password;
  delete o.resetToken;
  delete o.resetTokenExpires;
  return o;
};

exports.register = async (req, res, next) => {
  try {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
    const { email } = req.body;
    if (await User.findOne({ email })) return res.status(409).json({ message: 'Email already used' });
    const status = req.body.role === 'admin' ? 'pending' : 'active';
    const user = await User.create({ ...req.body, status });
    const token = sign(user);
    res.status(201).json({ token, user: sanitize(user) });
  } catch (e) { next(e); }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
    if (user.status === 'suspended') return res.status(403).json({ message: 'Account suspended' });
    const token = sign(user);
    res.json({ token, user: sanitize(user) });
  } catch (e) { next(e); }
};

exports.me = async (req, res) => res.json({ user: sanitize(req.user) });

exports.updateMe = async (req, res, next) => {
  try {
    const allowed = ['name', 'phone', 'address', 'city', 'organizationName', 'licenseNumber', 'avatar'];
    const patch = {};
    for (const k of allowed) if (req.body[k] !== undefined) patch[k] = req.body[k];
    const user = await User.findByIdAndUpdate(req.user._id, patch, { new: true });
    res.json({ user: sanitize(user) });
  } catch (e) { next(e); }
};

exports.changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ message: 'New password too short' });
    const user = await User.findById(req.user._id);
    if (!(await user.comparePassword(currentPassword)))
      return res.status(400).json({ message: 'Current password is incorrect' });
    user.password = newPassword;
    await user.save();
    res.json({ message: 'Password updated' });
  } catch (e) { next(e); }
};

exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    // Always respond 200 to avoid user enumeration
    if (!user) return res.json({ message: 'If the email exists, a reset link was generated' });
    const token = crypto.randomBytes(32).toString('hex');
    user.resetToken = crypto.createHash('sha256').update(token).digest('hex');
    user.resetTokenExpires = Date.now() + 60 * 60 * 1000;
    await user.save();
    // In production email this token. For dev we return it.
    res.json({ message: 'Reset token generated', devToken: token });
  } catch (e) { next(e); }
};

exports.resetPassword = async (req, res, next) => {
  try {
    const { token, newPassword } = req.body;
    const hashed = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({ resetToken: hashed, resetTokenExpires: { $gt: Date.now() } });
    if (!user) return res.status(400).json({ message: 'Invalid or expired token' });
    user.password = newPassword;
    user.resetToken = undefined;
    user.resetTokenExpires = undefined;
    await user.save();
    res.json({ message: 'Password reset successful' });
  } catch (e) { next(e); }
};
