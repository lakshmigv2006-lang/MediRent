const ExchangeListing = require('../models/ExchangeListing');
const Equipment = require('../models/Equipment');

// HEEN — Healthcare Equipment Exchange Network
exports.list = async (req, res, next) => {
  try {
    const { status = 'available', q } = req.query;
    const f = { status };
    const items = await ExchangeListing.find(f)
      .populate({
        path: 'equipment',
        match: q ? { name: new RegExp(q, 'i') } : {},
        populate: { path: 'category' },
      })
      .populate('hospital', 'name organizationName city')
      .sort('-createdAt');
    res.json({ items: items.filter((i) => i.equipment) });
  } catch (e) { next(e); }
};

exports.create = async (req, res, next) => {
  try {
    if (req.user.role !== 'hospital')
      return res.status(403).json({ message: 'Only hospitals can list on HEEN' });
    const { equipment, availableFrom, availableTo, note } = req.body;
    const eq = await Equipment.findById(equipment);
    if (!eq) return res.status(404).json({ message: 'Equipment not found' });
    if (String(eq.owner) !== String(req.user._id))
      return res.status(403).json({ message: 'You do not own this equipment' });
    eq.ownerType = 'hospital';
    await eq.save();
    const listing = await ExchangeListing.create({
      hospital: req.user._id, equipment: eq._id, availableFrom, availableTo, note,
    });
    res.status(201).json({ listing });
  } catch (e) { next(e); }
};

exports.close = async (req, res, next) => {
  try {
    const l = await ExchangeListing.findById(req.params.id);
    if (!l) return res.status(404).json({ message: 'Not found' });
    if (String(l.hospital) !== String(req.user._id) && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    l.status = 'closed';
    await l.save();
    res.json({ listing: l });
  } catch (e) { next(e); }
};
