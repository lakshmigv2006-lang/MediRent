const Category = require('../models/Category');

exports.list = async (_req, res, next) => {
  try { res.json({ items: await Category.find().sort('name') }); } catch (e) { next(e); }
};
exports.create = async (req, res, next) => {
  try { res.status(201).json({ item: await Category.create(req.body) }); } catch (e) { next(e); }
};
exports.update = async (req, res, next) => {
  try {
    const item = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ item });
  } catch (e) { next(e); }
};
exports.remove = async (req, res, next) => {
  try { await Category.findByIdAndDelete(req.params.id); res.json({ message: 'Deleted' }); }
  catch (e) { next(e); }
};
