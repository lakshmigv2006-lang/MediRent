const Invoice = require('../models/Invoice');

exports.list = async (req, res, next) => {
  try {
    const f = {};
    if (req.user.role === 'hospital') f.issuedTo = req.user._id;
    else if (req.user.role === 'supplier') f.issuedBy = req.user._id;
    const items = await Invoice.find(f).populate('rental').sort('-createdAt');
    res.json({ items });
  } catch (e) { next(e); }
};
exports.get = async (req, res, next) => {
  try {
    const item = await Invoice.findById(req.params.id).populate('rental issuedBy issuedTo');
    if (!item) return res.status(404).json({ message: 'Not found' });
    res.json({ item });
  } catch (e) { next(e); }
};
exports.pay = async (req, res, next) => {
  try {
    const inv = await Invoice.findByIdAndUpdate(req.params.id, { status: 'paid' }, { new: true });
    res.json({ item: inv });
  } catch (e) { next(e); }
};
