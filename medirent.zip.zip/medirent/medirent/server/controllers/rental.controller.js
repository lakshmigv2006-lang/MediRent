const Rental = require('../models/Rental');
const Equipment = require('../models/Equipment');
const Invoice = require('../models/Invoice');
const Notification = require('../models/Notification');

const notify = (user, type, title, message, link) =>
  Notification.create({ user, type, title, message, link });

const daysBetween = (a, b) =>
  Math.max(1, Math.ceil((new Date(b) - new Date(a)) / (1000 * 60 * 60 * 24)));

exports.create = async (req, res, next) => {
  try {
    const { equipment, quantity = 1, startDate, endDate, emergency, notes } = req.body;
    const eq = await Equipment.findById(equipment);
    if (!eq) return res.status(404).json({ message: 'Equipment not found' });
    if (eq.available < quantity) return res.status(400).json({ message: 'Not enough available' });
    const days = daysBetween(startDate, endDate);
    const totalAmount = days * eq.pricePerDay * quantity;
    const rental = await Rental.create({
      equipment: eq._id,
      renter: req.user._id,
      owner: eq.owner,
      ownerType: eq.ownerType,
      quantity, startDate, endDate, days,
      pricePerDay: eq.pricePerDay,
      totalAmount,
      emergency: !!emergency,
      notes,
      isExchange: eq.ownerType === 'hospital',
      timeline: [{ status: 'pending', by: req.user._id, note: 'Request submitted' }],
    });
    await notify(eq.owner, 'approval', 'New rental request',
      `${req.user.organizationName || req.user.name} requested ${eq.name}`,
      `/rentals/${rental._id}`);
    res.status(201).json({ rental });
  } catch (e) { next(e); }
};

exports.list = async (req, res, next) => {
  try {
    const { status, mine = 'true', page = 1, limit = 15 } = req.query;
    const f = {};
    if (status) f.status = status;
    if (req.user.role === 'admin' && mine !== 'true') {
      // all
    } else if (req.user.role === 'supplier') {
      f.owner = req.user._id;
    } else if (req.user.role === 'hospital') {
      // hospital can be renter OR owner (HEEN)
      f.$or = [{ renter: req.user._id }, { owner: req.user._id }];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Rental.find(f)
        .populate('equipment', 'name images pricePerDay')
        .populate('renter owner', 'name organizationName email')
        .sort('-createdAt').skip(skip).limit(Number(limit)),
      Rental.countDocuments(f),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) { next(e); }
};

exports.get = async (req, res, next) => {
  try {
    const r = await Rental.findById(req.params.id)
      .populate('equipment')
      .populate('renter owner', 'name organizationName email phone city address');
    if (!r) return res.status(404).json({ message: 'Not found' });
    res.json({ rental: r });
  } catch (e) { next(e); }
};

const ALLOWED = {
  supplier: ['approved', 'rejected', 'out_for_delivery', 'delivered', 'active', 'completed'],
  hospital: ['approved', 'rejected', 'out_for_delivery', 'delivered', 'active', 'completed', 'return_requested', 'cancelled'],
  admin: ['approved', 'rejected', 'out_for_delivery', 'delivered', 'active', 'completed', 'cancelled', 'return_requested'],
};

exports.setStatus = async (req, res, next) => {
  try {
    const { status, note } = req.body;
    const r = await Rental.findById(req.params.id);
    if (!r) return res.status(404).json({ message: 'Not found' });
    const isOwner = String(r.owner) === String(req.user._id);
    const isRenter = String(r.renter) === String(req.user._id);
    if (!isOwner && !isRenter && req.user.role !== 'admin')
      return res.status(403).json({ message: 'Forbidden' });
    if (!ALLOWED[req.user.role].includes(status))
      return res.status(400).json({ message: 'Status not allowed for this role' });

    r.status = status;
    r.timeline.push({ status, by: req.user._id, note });

    const eq = await Equipment.findById(r.equipment);
    if (status === 'approved' && eq) {
      eq.available = Math.max(0, eq.available - r.quantity);
      await eq.save();
      const invNum = 'INV-' + Date.now().toString(36).toUpperCase();
      await Invoice.create({
        rental: r._id, number: invNum,
        issuedBy: r.owner, issuedTo: r.renter,
        amount: r.totalAmount, total: r.totalAmount,
        dueDate: r.endDate,
      });
      await notify(r.renter, 'approval', 'Rental approved', `Your rental for ${eq.name} was approved.`, `/rentals/${r._id}`);
    }
    if (status === 'rejected') {
      await notify(r.renter, 'approval', 'Rental rejected', `Your rental was rejected.`, `/rentals/${r._id}`);
    }
    if (status === 'completed' && eq) {
      eq.available = Math.min(eq.quantity, eq.available + r.quantity);
      await eq.save();
    }
    await r.save();
    res.json({ rental: r });
  } catch (e) { next(e); }
};

exports.requestReturn = async (req, res, next) => {
  try {
    const r = await Rental.findById(req.params.id);
    if (!r) return res.status(404).json({ message: 'Not found' });
    if (String(r.renter) !== String(req.user._id))
      return res.status(403).json({ message: 'Forbidden' });
    r.status = 'return_requested';
    r.damageReport = req.body.damageReport || r.damageReport;
    r.timeline.push({ status: 'return_requested', by: req.user._id, note: req.body.note });
    await r.save();
    await notify(r.owner, 'return', 'Return requested', `Return requested for rental ${r._id}`, `/rentals/${r._id}`);
    res.json({ rental: r });
  } catch (e) { next(e); }
};

exports.extend = async (req, res, next) => {
  try {
    const { newEndDate } = req.body;
    const r = await Rental.findById(req.params.id);
    if (!r) return res.status(404).json({ message: 'Not found' });
    if (String(r.renter) !== String(req.user._id))
      return res.status(403).json({ message: 'Forbidden' });
    r.endDate = newEndDate;
    r.days = daysBetween(r.startDate, newEndDate);
    r.totalAmount = r.days * r.pricePerDay * r.quantity;
    r.timeline.push({ status: 'extended', by: req.user._id, note: 'Rental extended' });
    await r.save();
    res.json({ rental: r });
  } catch (e) { next(e); }
};
