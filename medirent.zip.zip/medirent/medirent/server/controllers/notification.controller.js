const Notification = require('../models/Notification');

exports.list = async (req, res, next) => {
  try {
    const items = await Notification.find({ user: req.user._id }).sort('-createdAt').limit(50);
    res.json({ items });
  } catch (e) { next(e); }
};
exports.markRead = async (req, res, next) => {
  try {
    await Notification.updateOne({ _id: req.params.id, user: req.user._id }, { read: true });
    res.json({ message: 'ok' });
  } catch (e) { next(e); }
};
exports.markAllRead = async (req, res, next) => {
  try {
    await Notification.updateMany({ user: req.user._id, read: false }, { read: true });
    res.json({ message: 'ok' });
  } catch (e) { next(e); }
};
