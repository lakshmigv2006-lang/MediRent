const User = require('../models/User');
const Equipment = require('../models/Equipment');
const Rental = require('../models/Rental');
const Invoice = require('../models/Invoice');
const Settings = require('../models/Settings');
const Notification = require('../models/Notification');

const notify = (user, type, title, message, link) =>
  Notification.create({ user, type, title, message, link }).catch(() => {});

// Helper to get or create settings
async function getPlatformSettings() {
  let s = await Settings.findOne({ key: 'platform_config' });
  if (!s) {
    s = await Settings.create({ key: 'platform_config', commissionRate: 5.0 });
  }
  return s;
}

// 1. Dashboard Overview
exports.getDashboard = async (req, res, next) => {
  try {
    const [
      totalHospitals,
      verifiedHospitals,
      pendingHospitals,
      totalSuppliers,
      verifiedSuppliers,
      pendingSuppliers,
      totalEquipment,
      verifiedEquipment,
      pendingEquipment,
      activeRentals,
      pendingRentals,
      revenueAgg,
      commissionAgg,
      pendingSettlementAgg,
      mostRented,
      recentRentals,
      pendingVerificationUsers,
      settings,
    ] = await Promise.all([
      User.countDocuments({ role: 'hospital' }),
      User.countDocuments({ role: 'hospital', verificationStatus: 'verified' }),
      User.countDocuments({ role: 'hospital', verificationStatus: 'pending' }),
      User.countDocuments({ role: 'supplier' }),
      User.countDocuments({ role: 'supplier', verificationStatus: 'verified' }),
      User.countDocuments({ role: 'supplier', verificationStatus: 'pending' }),
      Equipment.countDocuments(),
      Equipment.countDocuments({ verificationStatus: 'verified' }),
      Equipment.countDocuments({ verificationStatus: 'pending' }),
      Rental.countDocuments({ status: { $in: ['active', 'delivered', 'out_for_delivery', 'picked_up', 'handed_over'] } }),
      Rental.countDocuments({ status: { $in: ['requested', 'pending', 'payment_pending'] } }),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured' } },
        { $group: { _id: null, sum: { $sum: '$totalAmount' } } },
      ]),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured' } },
        { $group: { _id: null, sum: { $sum: '$commissionAmount' } } },
      ]),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured', settlementStatus: 'pending' } },
        { $group: { _id: null, sum: { $sum: '$supplierAmount' } } },
      ]),
      Rental.aggregate([
        { $group: { _id: '$equipment', count: { $sum: 1 }, totalRevenue: { $sum: '$totalAmount' } } },
        { $sort: { count: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'equipment', localField: '_id', foreignField: '_id', as: 'equipment' } },
        { $unwind: '$equipment' },
      ]),
      Rental.find()
        .populate('equipment', 'name images pricePerDay')
        .populate('renter owner', 'name organizationName email')
        .sort('-createdAt')
        .limit(6),
      User.find({ verificationStatus: 'pending', role: { $in: ['hospital', 'supplier'] } })
        .select('-password')
        .sort('-createdAt')
        .limit(6),
      getPlatformSettings(),
    ]);

    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    const monthly = await Rental.aggregate([
      { $match: { createdAt: { $gte: start } } },
      {
        $group: {
          _id: { y: { $year: '$createdAt' }, m: { $month: '$createdAt' } },
          count: { $sum: 1 },
          revenue: { $sum: '$totalAmount' },
          commission: { $sum: '$commissionAmount' },
        },
      },
      { $sort: { '_id.y': 1, '_id.m': 1 } },
    ]);

    const totalPendingVerification = pendingHospitals + pendingSuppliers + pendingEquipment;

    res.json({
      counts: {
        totalHospitals,
        verifiedHospitals,
        pendingHospitals,
        totalSuppliers,
        verifiedSuppliers,
        pendingSuppliers,
        totalEquipment,
        verifiedEquipment,
        pendingEquipment,
        activeRentals,
        pendingRentals,
        totalPendingVerification,
      },
      financials: {
        totalRevenue: revenueAgg[0]?.sum || 0,
        totalCommission: commissionAgg[0]?.sum || 0,
        pendingSettlement: pendingSettlementAgg[0]?.sum || 0,
        commissionRate: settings.commissionRate,
      },
      monthly,
      mostRented,
      recentRentals,
      pendingVerificationUsers,
    });
  } catch (e) {
    next(e);
  }
};

// 2. Hospitals Management & Verification
exports.getHospitals = async (req, res, next) => {
  try {
    const { status, verificationStatus, q, page = 1, limit = 20 } = req.query;
    const filter = { role: 'hospital' };
    if (status) filter.status = status;
    if (verificationStatus) filter.verificationStatus = verificationStatus;
    if (q) {
      filter.$or = [
        { name: new RegExp(q, 'i') },
        { email: new RegExp(q, 'i') },
        { organizationName: new RegExp(q, 'i') },
        { registrationNumber: new RegExp(q, 'i') },
        { city: new RegExp(q, 'i') },
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      User.find(filter).select('-password').sort('-createdAt').skip(skip).limit(Number(limit)),
      User.countDocuments(filter),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) {
    next(e);
  }
};

exports.approveHospital = async (req, res, next) => {
  try {
    const user = await User.findOneAndUpdate(
      { _id: req.params.id, role: 'hospital' },
      { verificationStatus: 'verified', status: 'active', rejectionReason: null, verifiedAt: new Date() },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ message: 'Hospital not found' });
    await notify(user._id, 'approval', 'Hospital Account Verified', 'Your hospital profile and documents have been approved by Admin.', '/hospital/profile');
    res.json({ message: 'Hospital verified successfully', user });
  } catch (e) {
    next(e);
  }
};

exports.rejectHospital = async (req, res, next) => {
  try {
    const { reason = 'Document verification failed or incomplete credentials.' } = req.body;
    const user = await User.findOneAndUpdate(
      { _id: req.params.id, role: 'hospital' },
      { verificationStatus: 'rejected', rejectionReason: reason },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ message: 'Hospital not found' });
    await notify(user._id, 'alert', 'Hospital Verification Update', `Your verification was rejected: ${reason}`, '/hospital/profile');
    res.json({ message: 'Hospital rejected', user });
  } catch (e) {
    next(e);
  }
};

// 3. Suppliers Management & Verification
exports.getSuppliers = async (req, res, next) => {
  try {
    const { status, verificationStatus, q, page = 1, limit = 20 } = req.query;
    const filter = { role: 'supplier' };
    if (status) filter.status = status;
    if (verificationStatus) filter.verificationStatus = verificationStatus;
    if (q) {
      filter.$or = [
        { name: new RegExp(q, 'i') },
        { email: new RegExp(q, 'i') },
        { organizationName: new RegExp(q, 'i') },
        { registrationNumber: new RegExp(q, 'i') },
        { city: new RegExp(q, 'i') },
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      User.find(filter).select('-password').sort('-createdAt').skip(skip).limit(Number(limit)),
      User.countDocuments(filter),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) {
    next(e);
  }
};

exports.approveSupplier = async (req, res, next) => {
  try {
    const user = await User.findOneAndUpdate(
      { _id: req.params.id, role: 'supplier' },
      { verificationStatus: 'verified', status: 'active', rejectionReason: null, verifiedAt: new Date() },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ message: 'Supplier not found' });
    await notify(user._id, 'approval', 'Supplier Business Verified', 'Your business credentials and licenses have been verified. You can now list equipment.', '/supplier/profile');
    res.json({ message: 'Supplier verified successfully', user });
  } catch (e) {
    next(e);
  }
};

exports.rejectSupplier = async (req, res, next) => {
  try {
    const { reason = 'Business license or authorization documents not valid.' } = req.body;
    const user = await User.findOneAndUpdate(
      { _id: req.params.id, role: 'supplier' },
      { verificationStatus: 'rejected', rejectionReason: reason },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ message: 'Supplier not found' });
    await notify(user._id, 'alert', 'Supplier Verification Update', `Verification rejected: ${reason}`, '/supplier/profile');
    res.json({ message: 'Supplier rejected', user });
  } catch (e) {
    next(e);
  }
};

// 4. Equipment Management & Verification
exports.getEquipment = async (req, res, next) => {
  try {
    const { verificationStatus, condition, category, q, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (verificationStatus) filter.verificationStatus = verificationStatus;
    if (condition) filter.condition = condition;
    if (category) filter.category = category;
    if (q) {
      filter.$or = [
        { name: new RegExp(q, 'i') },
        { manufacturer: new RegExp(q, 'i') },
        { model: new RegExp(q, 'i') },
        { serialNumber: new RegExp(q, 'i') },
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Equipment.find(filter)
        .populate('category', 'name')
        .populate('owner', 'name organizationName email phone city verificationStatus')
        .sort('-createdAt')
        .skip(skip)
        .limit(Number(limit)),
      Equipment.countDocuments(filter),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) {
    next(e);
  }
};

exports.approveEquipment = async (req, res, next) => {
  try {
    const item = await Equipment.findByIdAndUpdate(
      req.params.id,
      { verificationStatus: 'verified', status: 'active', rejectionReason: null, verifiedAt: new Date() },
      { new: true }
    ).populate('category owner', 'name organizationName');
    if (!item) return res.status(404).json({ message: 'Equipment not found' });
    await notify(item.owner._id, 'approval', 'Equipment Listing Approved', `${item.name} is now approved and live in the MediRent marketplace.`, `/supplier/inventory`);
    res.json({ message: 'Equipment verified and listed', item });
  } catch (e) {
    next(e);
  }
};

exports.rejectEquipment = async (req, res, next) => {
  try {
    const { reason = 'Equipment maintenance certificate or specifications rejected.' } = req.body;
    const item = await Equipment.findByIdAndUpdate(
      req.params.id,
      { verificationStatus: 'rejected', status: 'inactive', rejectionReason: reason },
      { new: true }
    );
    if (!item) return res.status(404).json({ message: 'Equipment not found' });
    await notify(item.owner, 'alert', 'Equipment Listing Rejected', `Listing rejected for ${item.name}: ${reason}`, `/supplier/inventory`);
    res.json({ message: 'Equipment listing rejected', item });
  } catch (e) {
    next(e);
  }
};

// 5. Consolidated Verification Queue
exports.getVerificationQueue = async (req, res, next) => {
  try {
    const [hospitals, suppliers, equipment] = await Promise.all([
      User.find({ role: 'hospital', verificationStatus: 'pending' }).select('-password').sort('-createdAt'),
      User.find({ role: 'supplier', verificationStatus: 'pending' }).select('-password').sort('-createdAt'),
      Equipment.find({ verificationStatus: 'pending' }).populate('category owner', 'name organizationName email city').sort('-createdAt'),
    ]);
    res.json({
      hospitals,
      suppliers,
      equipment,
      totalPending: hospitals.length + suppliers.length + equipment.length,
    });
  } catch (e) {
    next(e);
  }
};

// 6. Rentals Monitoring
exports.getRentals = async (req, res, next) => {
  try {
    const { status, paymentStatus, q, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (paymentStatus) filter.paymentStatus = paymentStatus;
    if (q) {
      filter.$or = [
        { rentalCode: new RegExp(q, 'i') },
        { notes: new RegExp(q, 'i') },
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Rental.find(filter)
        .populate('equipment')
        .populate('renter', 'name organizationName email phone city address')
        .populate('owner', 'name organizationName email phone city address')
        .sort('-createdAt')
        .skip(skip)
        .limit(Number(limit)),
      Rental.countDocuments(filter),
    ]);
    res.json({ items, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (e) {
    next(e);
  }
};

// 7. Payment Monitoring
exports.getPayments = async (req, res, next) => {
  try {
    const { paymentStatus, settlementStatus, q, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (paymentStatus) filter.paymentStatus = paymentStatus;
    if (settlementStatus) filter.settlementStatus = settlementStatus;
    if (q) {
      filter.$or = [
        { rentalCode: new RegExp(q, 'i') },
        { razorpayOrderId: new RegExp(q, 'i') },
        { razorpayPaymentId: new RegExp(q, 'i') },
      ];
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total, stats] = await Promise.all([
      Rental.find(filter)
        .populate('equipment', 'name')
        .populate('renter', 'name organizationName email')
        .populate('owner', 'name organizationName email')
        .sort('-createdAt')
        .skip(skip)
        .limit(Number(limit)),
      Rental.countDocuments(filter),
      Rental.aggregate([
        {
          $group: {
            _id: null,
            totalGross: { $sum: '$totalAmount' },
            totalCommission: { $sum: '$commissionAmount' },
            totalSupplierShare: { $sum: '$supplierAmount' },
            capturedCount: { $sum: { $cond: [{ $eq: ['$paymentStatus', 'captured'] }, 1, 0] } },
          },
        },
      ]),
    ]);

    res.json({
      items,
      total,
      page: Number(page),
      pages: Math.ceil(total / limit),
      summary: stats[0] || { totalGross: 0, totalCommission: 0, totalSupplierShare: 0, capturedCount: 0 },
    });
  } catch (e) {
    next(e);
  }
};

// Toggle settlement
exports.settlePayment = async (req, res, next) => {
  try {
    const { settlementStatus } = req.body; // 'settled' or 'pending'
    const rental = await Rental.findByIdAndUpdate(
      req.params.id,
      {
        settlementStatus: settlementStatus || 'settled',
        settledAt: settlementStatus === 'settled' ? new Date() : null,
      },
      { new: true }
    );
    if (!rental) return res.status(404).json({ message: 'Rental transaction not found' });
    res.json({ message: `Settlement marked as ${rental.settlementStatus}`, rental });
  } catch (e) {
    next(e);
  }
};

// 8. Commission & Payouts
exports.getCommission = async (req, res, next) => {
  try {
    const [totals, settledStats, pendingStats, supplierBreakdown, settings] = await Promise.all([
      Rental.aggregate([
        { $match: { paymentStatus: 'captured' } },
        {
          $group: {
            _id: null,
            totalGross: { $sum: '$totalAmount' },
            totalCommission: { $sum: '$commissionAmount' },
            totalSupplierPayable: { $sum: '$supplierAmount' },
            count: { $sum: 1 },
          },
        },
      ]),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured', settlementStatus: 'settled' } },
        { $group: { _id: null, sum: { $sum: '$supplierAmount' }, count: { $sum: 1 } } },
      ]),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured', settlementStatus: 'pending' } },
        { $group: { _id: null, sum: { $sum: '$supplierAmount' }, count: { $sum: 1 } } },
      ]),
      Rental.aggregate([
        { $match: { paymentStatus: 'captured' } },
        {
          $group: {
            _id: '$owner',
            gross: { $sum: '$totalAmount' },
            commission: { $sum: '$commissionAmount' },
            supplierShare: { $sum: '$supplierAmount' },
            pendingPayout: {
              $sum: { $cond: [{ $eq: ['$settlementStatus', 'pending'] }, '$supplierAmount', 0] },
            },
            settledPayout: {
              $sum: { $cond: [{ $eq: ['$settlementStatus', 'settled'] }, '$supplierAmount', 0] },
            },
            rentalCount: { $sum: 1 },
          },
        },
        { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'owner' } },
        { $unwind: '$owner' },
        { $sort: { pendingPayout: -1 } },
      ]),
      getPlatformSettings(),
    ]);

    res.json({
      summary: {
        totalGross: totals[0]?.totalGross || 0,
        totalCommission: totals[0]?.totalCommission || 0,
        totalSupplierPayable: totals[0]?.totalSupplierPayable || 0,
        totalSettled: settledStats[0]?.sum || 0,
        totalPendingSettlement: pendingStats[0]?.sum || 0,
        transactionCount: totals[0]?.count || 0,
        commissionRate: settings.commissionRate,
      },
      supplierBreakdown,
    });
  } catch (e) {
    next(e);
  }
};

// 9. Renewals Monitoring
exports.getRenewals = async (req, res, next) => {
  try {
    const rentals = await Rental.find({
      $or: [
        { 'renewalRequests.0': { $exists: true } },
        { status: 'renewal_requested' },
      ],
    })
      .populate('equipment', 'name images pricePerDay')
      .populate('renter owner', 'name organizationName email phone')
      .sort('-updatedAt');
    res.json({ items: rentals, total: rentals.length });
  } catch (e) {
    next(e);
  }
};

// 10. Returns Monitoring
exports.getReturns = async (req, res, next) => {
  try {
    const rentals = await Rental.find({
      $or: [
        { 'returnDetails.status': { $exists: true } },
        { status: { $in: ['return_requested', 'returned', 'completed'] } },
      ],
    })
      .populate('equipment', 'name images serialNumber condition')
      .populate('renter owner', 'name organizationName email phone')
      .sort('-updatedAt');
    res.json({ items: rentals, total: rentals.length });
  } catch (e) {
    next(e);
  }
};

// 11. Platform Settings
exports.getSettings = async (req, res, next) => {
  try {
    const s = await getPlatformSettings();
    res.json({ settings: s });
  } catch (e) {
    next(e);
  }
};

exports.updateSettings = async (req, res, next) => {
  try {
    const { commissionRate, supportEmail, supportPhone, autoVerifyEquipment, razorpayTestMode } = req.body;
    let s = await Settings.findOne({ key: 'platform_config' });
    if (!s) s = new Settings({ key: 'platform_config' });

    if (commissionRate !== undefined) s.commissionRate = Number(commissionRate);
    if (supportEmail !== undefined) s.supportEmail = supportEmail;
    if (supportPhone !== undefined) s.supportPhone = supportPhone;
    if (autoVerifyEquipment !== undefined) s.autoVerifyEquipment = !!autoVerifyEquipment;
    if (razorpayTestMode !== undefined) s.razorpayTestMode = !!razorpayTestMode;
    s.updatedBy = req.user._id;
    await s.save();

    res.json({ message: 'Settings saved', settings: s });
  } catch (e) {
    next(e);
  }
};
