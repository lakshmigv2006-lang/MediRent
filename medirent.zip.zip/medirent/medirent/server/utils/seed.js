/**
 * Seeds Admin, Verified/Pending Hospitals, Verified/Pending Suppliers,
 * Categories, Equipment with documents, Rentals with Razorpay payments & commissions,
 * Renewals, Returns, and Platform Settings.
 * Run: `npm run seed`
 */
require('dotenv').config();
const connectDB = require('../config/db');
const User = require('../models/User');
const Category = require('../models/Category');
const Equipment = require('../models/Equipment');
const Rental = require('../models/Rental');
const Invoice = require('../models/Invoice');
const Settings = require('../models/Settings');

async function main() {
  await connectDB();
  await Promise.all([
    User.deleteMany({}),
    Category.deleteMany({}),
    Equipment.deleteMany({}),
    Rental.deleteMany({}),
    Invoice.deleteMany({}),
    Settings.deleteMany({}),
  ]);

  console.log('🧹 Cleared existing database records');

  // 1. Settings
  await Settings.create({
    key: 'platform_config',
    commissionRate: 5.0,
    platformName: 'MediRent',
    tagline: 'Verified. Reliable. Accessible.',
    supportEmail: 'support@medirent.io',
    supportPhone: '+91 98765 43210',
    razorpayKeyId: 'rzp_test_medirent2026',
    razorpayTestMode: true,
    autoVerifyEquipment: false,
  });

  // 2. Users
  const admin = await User.create({
    name: 'Platform Administrator',
    email: 'admin@medirent.io',
    password: 'Admin@123',
    role: 'admin',
    status: 'active',
    verificationStatus: 'verified',
    verifiedAt: new Date(),
    phone: '+91 98765 00001',
    organizationName: 'MediRent Operations HQ',
    city: 'Chennai',
  });

  // Hospital 1: Verified
  const hospital1 = await User.create({
    name: 'Dr. Anand Ramanathan',
    email: 'hospital@medirent.io',
    password: 'Hospital@1',
    role: 'hospital',
    status: 'active',
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-15'),
    phone: '+91 98401 23456',
    organizationName: 'City Care Multi-Speciality Hospital',
    registrationNumber: 'HOSP-TN-2024-8891',
    hospitalType: 'Multi-Specialty Tertiary Care',
    contactPerson: 'Dr. Anand Ramanathan (Medical Director)',
    address: '45, Anna Salai, Teynampet',
    city: 'Chennai',
    state: 'Tamil Nadu',
    pincode: '600018',
    latitude: 13.0418,
    longitude: 80.2507,
    googleMapsUrl: 'https://maps.google.com/?q=13.0418,80.2507',
    documents: [
      {
        documentType: 'hospital_registration',
        fileName: 'City_Care_State_Health_Reg_2026.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
      {
        documentType: 'gst_pan',
        fileName: 'City_Care_GST_33AAAAA0000A1Z5.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
      {
        documentType: 'authorization',
        fileName: 'Board_Resolution_Equipment_Procurement.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
    ],
  });

  // Hospital 2: Pending
  const hospital2 = await User.create({
    name: 'Dr. Priya Sundaram',
    email: 'apollo.clinic@medirent.demo',
    password: 'Hospital@1',
    role: 'hospital',
    status: 'pending',
    verificationStatus: 'pending',
    phone: '+91 98402 77889',
    organizationName: 'Kaveri Community Health Center',
    registrationNumber: 'HOSP-TN-2025-1042',
    hospitalType: 'Secondary Care Clinic',
    contactPerson: 'Dr. Priya Sundaram (Chief Administrator)',
    address: '12, Gandhi Road, RS Puram',
    city: 'Coimbatore',
    state: 'Tamil Nadu',
    pincode: '641002',
    latitude: 11.0081,
    longitude: 76.9558,
    googleMapsUrl: 'https://maps.google.com/?q=11.0081,76.9558',
    documents: [
      {
        documentType: 'hospital_registration',
        fileName: 'Kaveri_Clinic_Establishment_Certificate.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'pending',
      },
      {
        documentType: 'gst_pan',
        fileName: 'Kaveri_PAN_Card.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'pending',
      },
    ],
  });

  // Supplier 1: Verified
  const supplier1 = await User.create({
    name: 'Rajesh Sharma',
    email: 'supplier@medirent.io',
    password: 'Supplier@1',
    role: 'supplier',
    status: 'active',
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-10'),
    phone: '+91 94440 98765',
    organizationName: 'MedEquip Solutions Pvt Ltd',
    registrationNumber: 'MED-SUP-TN-4519',
    businessType: 'Authorized Equipment Dealer & Service Center',
    authorizedPerson: 'Rajesh Sharma (Managing Director)',
    address: 'Plot 18, 2nd Avenue, Anna Nagar East',
    city: 'Chennai',
    state: 'Tamil Nadu',
    pincode: '600102',
    latitude: 13.0850,
    longitude: 80.2101,
    googleMapsUrl: 'https://maps.google.com/?q=13.0850,80.2101',
    documents: [
      {
        documentType: 'business_license',
        fileName: 'MedEquip_Trade_License_2026.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
      {
        documentType: 'gst_certificate',
        fileName: 'MedEquip_GST_Certificate_33AABCM8921B1Z9.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
      {
        documentType: 'dealer_authorization',
        fileName: 'Philips_Draeger_Authorised_Distributor_Letter.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'verified',
      },
    ],
  });

  // Supplier 2: Pending
  const supplier2 = await User.create({
    name: 'Vikram Mehta',
    email: 'apex.med@medirent.demo',
    password: 'Supplier@1',
    role: 'supplier',
    status: 'pending',
    verificationStatus: 'pending',
    phone: '+91 98801 55443',
    organizationName: 'Apex Healthcare Devices Ltd',
    registrationNumber: 'MED-SUP-KA-7721',
    businessType: 'Critical Care Devices Rental Provider',
    authorizedPerson: 'Vikram Mehta (Partner)',
    address: '88, Industrial Suburb, Yeshwanthpur',
    city: 'Bangalore',
    state: 'Karnataka',
    pincode: '560022',
    latitude: 13.0238,
    longitude: 77.5529,
    googleMapsUrl: 'https://maps.google.com/?q=13.0238,77.5529',
    documents: [
      {
        documentType: 'business_license',
        fileName: 'Apex_Incorporation_Certificate.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'pending',
      },
      {
        documentType: 'ownership_proof',
        fileName: 'Ventilator_Invoice_Batch_2026.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        fileType: 'application/pdf',
        verificationStatus: 'pending',
      },
    ],
  });

  // 3. Categories
  const cats = await Category.insertMany([
    { name: 'Respiratory Support', description: 'Oxygen concentrators, ventilators, BiPAP/CPAP' },
    { name: 'ICU & Critical Care', description: 'Electric ICU beds, infusion pumps, syringe drivers' },
    { name: 'Patient Monitoring', description: 'Multiparameter monitors, ECG machines, pulse oximeters' },
    { name: 'Mobility & Support', description: 'Motorized wheelchairs, patient transfer hoists' },
    { name: 'Dialysis & Renal', description: 'Hemodialysis machines, peritoneal dialysis equipment' },
    { name: 'Neonatal & Pediatric', description: 'Infant incubators, phototherapy units' },
  ]);

  // 4. Equipment
  const eq1 = await Equipment.create({
    name: 'Philips EverFlo Oxygen Concentrator 10L',
    category: cats[0]._id,
    manufacturer: 'Philips Healthcare',
    model: 'EverFlo 10L Ultra-Quiet',
    serialNumber: 'PH-OC-2024-9982',
    description: 'High-purity medical grade 10L continuous flow oxygen concentrator with integrated OPI (Oxygen Percentage Indicator).',
    pricePerDay: 500,
    securityDeposit: 2000,
    quantity: 8,
    available: 7,
    condition: 'excellent',
    location: 'Anna Nagar, Chennai (2.4 km away)',
    maintenanceStatus: 'up_to_date',
    lastServiceDate: new Date('2026-08-01'),
    nextServiceDate: new Date('2026-11-01'),
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-11'),
    owner: supplier1._id,
    ownerType: 'supplier',
    images: ['https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80'],
    documents: [
      {
        documentType: 'certificate',
        fileName: 'Philips_Calibration_Certificate_Q3.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      },
    ],
  });

  const eq2 = await Equipment.create({
    name: 'Dräger Evita V300 Critical Care Ventilator',
    category: cats[0]._id,
    manufacturer: 'Dräger Medical',
    model: 'Evita V300',
    serialNumber: 'DR-EV-2025-4410',
    description: 'Advanced intensive care ventilator for adult, pediatric, and neonatal patients with lung protective ventilation modes.',
    pricePerDay: 1800,
    securityDeposit: 8000,
    quantity: 4,
    available: 3,
    condition: 'new',
    location: 'Anna Nagar, Chennai',
    maintenanceStatus: 'up_to_date',
    lastServiceDate: new Date('2026-08-20'),
    nextServiceDate: new Date('2026-11-20'),
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-12'),
    owner: supplier1._id,
    ownerType: 'supplier',
    images: ['https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80'],
  });

  const eq3 = await Equipment.create({
    name: 'GE Healthcare B40 Multiparameter Monitor',
    category: cats[2]._id,
    manufacturer: 'GE Healthcare',
    model: 'B40 Patient Monitor',
    serialNumber: 'GE-B40-88124',
    description: 'Comprehensive 12.1-inch color display monitor for ECG, SpO2, NIBP, Dual Temp, and Respiration monitoring.',
    pricePerDay: 450,
    securityDeposit: 1500,
    quantity: 6,
    available: 6,
    condition: 'excellent',
    location: 'Anna Nagar, Chennai',
    maintenanceStatus: 'up_to_date',
    lastServiceDate: new Date('2026-07-15'),
    nextServiceDate: new Date('2026-10-15'),
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-12'),
    owner: supplier1._id,
    ownerType: 'supplier',
    images: ['https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600&auto=format&fit=crop&q=80'],
  });

  const eq4 = await Equipment.create({
    name: 'Stryker SV2 5-Function Electric ICU Bed',
    category: cats[1]._id,
    manufacturer: 'Stryker Medical',
    model: 'SV2 Advanced Electric',
    serialNumber: 'STR-SV2-3320',
    description: 'Fully motorized ICU bed with CPR quick release, integrated digital weighing scale, and nurse control panel.',
    pricePerDay: 650,
    securityDeposit: 3000,
    quantity: 5,
    available: 5,
    condition: 'good',
    location: 'Anna Nagar, Chennai',
    maintenanceStatus: 'up_to_date',
    lastServiceDate: new Date('2026-07-28'),
    nextServiceDate: new Date('2026-10-28'),
    verificationStatus: 'verified',
    verifiedAt: new Date('2026-08-12'),
    owner: supplier1._id,
    ownerType: 'supplier',
    images: ['https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=600&auto=format&fit=crop&q=80'],
  });

  // Pending Equipment awaiting verification
  const eqPending = await Equipment.create({
    name: 'Fresenius 4008S Hemodialysis Machine',
    category: cats[4]._id,
    manufacturer: 'Fresenius Medical Care',
    model: '4008S Classic NextGen',
    serialNumber: 'FMC-4008S-9011',
    description: 'High-precision renal replacement therapy system with OCM (Online Clearance Monitoring) and automated priming.',
    pricePerDay: 2200,
    securityDeposit: 10000,
    quantity: 2,
    available: 2,
    condition: 'excellent',
    location: 'Yeshwanthpur, Bangalore',
    maintenanceStatus: 'up_to_date',
    lastServiceDate: new Date('2026-08-10'),
    nextServiceDate: new Date('2026-11-10'),
    verificationStatus: 'pending',
    owner: supplier2._id,
    ownerType: 'supplier',
    images: ['https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=600&auto=format&fit=crop&q=80'],
    documents: [
      {
        documentType: 'certificate',
        fileName: 'Fresenius_Biomedical_Inspection_Report.pdf',
        fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      },
    ],
  });

  // 5. Seed Rentals (Active, Paid, Renewals, Returns)
  // Rental 1: Active rental with Razorpay payment & commission
  const rental1 = await Rental.create({
    rentalCode: 'MR-1001',
    equipment: eq1._id,
    renter: hospital1._id,
    owner: supplier1._id,
    ownerType: 'supplier',
    quantity: 1,
    startDate: new Date('2026-09-10'),
    endDate: new Date('2026-09-15'),
    days: 5,
    pricePerDay: 500,
    rentalAmount: 2500,
    commissionAmount: 125, // 5% MediRent commission
    supplierAmount: 2375,  // 95% Supplier payable
    totalAmount: 2500,
    status: 'active',
    paymentStatus: 'captured',
    razorpayOrderId: 'order_MR1001_rzp_demo',
    razorpayPaymentId: 'pay_MR1001_rzp_demo_9921',
    razorpaySignature: 'sig_verified_server_side_valid',
    settlementStatus: 'pending',
    pickupStatus: 'handed_over',
    pickupDetails: {
      pickupDate: new Date('2026-09-10'),
      pickupTime: '10:30 AM',
      driverName: 'Ravi Kumar',
      driverPhone: '+91 98409 11223',
      vehicleNumber: 'TN 01 AB 1234',
      vehicleType: 'Medical Logistics Van',
      pickupAddress: 'MedEquip Solutions, Plot 18, 2nd Avenue, Anna Nagar East, Chennai',
      handedOverAt: new Date('2026-09-10T11:00:00Z'),
    },
    timeline: [
      { status: 'requested', at: new Date('2026-09-08T09:00:00Z'), by: hospital1._id, note: 'Hospital requested 5-day rental' },
      { status: 'approved', at: new Date('2026-09-08T11:30:00Z'), by: supplier1._id, note: 'Supplier approved rental request' },
      { status: 'paid', at: new Date('2026-09-08T14:15:00Z'), by: hospital1._id, note: 'Payment of ₹2,500 captured via Razorpay Test Checkout' },
      { status: 'pickup_scheduled', at: new Date('2026-09-09T10:00:00Z'), by: hospital1._id, note: 'Driver Ravi Kumar (TN 01 AB 1234) assigned' },
      { status: 'handed_over', at: new Date('2026-09-10T11:00:00Z'), by: supplier1._id, note: 'Equipment inspected and handed over to driver' },
      { status: 'active', at: new Date('2026-09-10T11:30:00Z'), by: hospital1._id, note: 'Active rental in progress' },
    ],
  });

  // Rental 2: Completed with return inspection & settlement
  const rental2 = await Rental.create({
    rentalCode: 'MR-1002',
    equipment: eq2._id,
    renter: hospital1._id,
    owner: supplier1._id,
    ownerType: 'supplier',
    quantity: 1,
    startDate: new Date('2026-08-20'),
    endDate: new Date('2026-08-25'),
    days: 5,
    pricePerDay: 1800,
    rentalAmount: 9000,
    commissionAmount: 450, // 5%
    supplierAmount: 8550,  // 95%
    totalAmount: 9000,
    status: 'completed',
    paymentStatus: 'captured',
    razorpayOrderId: 'order_MR1002_rzp_demo',
    razorpayPaymentId: 'pay_MR1002_rzp_demo_8832',
    settlementStatus: 'settled',
    settledAt: new Date('2026-08-27'),
    pickupStatus: 'active',
    returnDetails: {
      requestedDate: new Date('2026-08-25'),
      returnDate: new Date('2026-08-25'),
      condition: 'good',
      damageNotes: 'Returned in full working order. Cleaned and recalibrated.',
      status: 'completed',
    },
    timeline: [
      { status: 'requested', at: new Date('2026-08-18T10:00:00Z'), by: hospital1._id, note: 'Requested' },
      { status: 'approved', at: new Date('2026-08-18T12:00:00Z'), by: supplier1._id, note: 'Approved' },
      { status: 'paid', at: new Date('2026-08-18T15:00:00Z'), by: hospital1._id, note: 'Payment captured' },
      { status: 'handed_over', at: new Date('2026-08-20T09:00:00Z'), by: supplier1._id, note: 'Handed over' },
      { status: 'returned', at: new Date('2026-08-25T16:00:00Z'), by: supplier1._id, note: 'Equipment received and inspected' },
      { status: 'completed', at: new Date('2026-08-25T17:00:00Z'), by: admin._id, note: 'Completed' },
    ],
  });

  // Rental 3: Renewal request in progress
  const rental3 = await Rental.create({
    rentalCode: 'MR-1003',
    equipment: eq3._id,
    renter: hospital1._id,
    owner: supplier1._id,
    ownerType: 'supplier',
    quantity: 1,
    startDate: new Date('2026-09-01'),
    endDate: new Date('2026-09-08'),
    days: 7,
    pricePerDay: 450,
    rentalAmount: 3150,
    commissionAmount: 157.5,
    supplierAmount: 2992.5,
    totalAmount: 3150,
    status: 'renewal_requested',
    paymentStatus: 'captured',
    razorpayOrderId: 'order_MR1003_rzp_demo',
    razorpayPaymentId: 'pay_MR1003_rzp_demo_1190',
    settlementStatus: 'pending',
    renewalRequests: [
      {
        requestedBy: hospital1._id,
        currentEndDate: new Date('2026-09-08'),
        requestedEndDate: new Date('2026-09-15'),
        additionalDays: 7,
        additionalAmount: 3150,
        status: 'pending',
        createdAt: new Date('2026-09-01T12:00:00Z'),
      },
    ],
  });

  // Rental 4: Return requested with damage inspection notes
  const rental4 = await Rental.create({
    rentalCode: 'MR-1004',
    equipment: eq4._id,
    renter: hospital1._id,
    owner: supplier1._id,
    ownerType: 'supplier',
    quantity: 1,
    startDate: new Date('2026-08-28'),
    endDate: new Date('2026-09-02'),
    days: 5,
    pricePerDay: 650,
    rentalAmount: 3250,
    commissionAmount: 162.5,
    supplierAmount: 3087.5,
    totalAmount: 3250,
    status: 'return_requested',
    paymentStatus: 'captured',
    razorpayOrderId: 'order_MR1004_rzp_demo',
    razorpayPaymentId: 'pay_MR1004_rzp_demo_5521',
    settlementStatus: 'pending',
    returnDetails: {
      requestedDate: new Date('2026-09-02'),
      condition: 'fair',
      damageNotes: 'Minor scratch on left side rail during transit. Functional electronics normal.',
      status: 'return_requested',
    },
  });

  console.log('✅ Demo data successfully seeded!');
  console.log('----------------------------------------------------');
  console.log('🔑 ADMIN LOGIN:');
  console.log('   Email:    admin@medirent.io');
  console.log('   Password: Admin@123');
  console.log('');
  console.log('🏥 HOSPITAL LOGIN:');
  console.log('   Email:    hospital@medirent.io');
  console.log('   Password: Hospital@1');
  console.log('');
  console.log('🏭 SUPPLIER LOGIN:');
  console.log('   Email:    supplier@medirent.io');
  console.log('   Password: Supplier@1');
  console.log('----------------------------------------------------');

  process.exit(0);
}

main().catch((e) => {
  console.error('❌ Error seeding database:', e);
  process.exit(1);
});
