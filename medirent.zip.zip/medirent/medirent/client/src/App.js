import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardLayout from './layouts/DashboardLayout';

import Landing from './pages/Landing';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Forgot from './pages/auth/Forgot';
import Reset from './pages/auth/Reset';

import Profile from './pages/common/Profile';
import Notifications from './pages/common/Notifications';
import EquipmentBrowse from './pages/common/EquipmentBrowse';
import EquipmentDetail from './pages/common/EquipmentDetail';

import HospitalDashboard from './pages/hospital/Dashboard';
import HospitalRentals from './pages/hospital/Rentals';
import HospitalInvoices from './pages/hospital/Invoices';
import HeenList from './pages/heen/HeenList';
import HeenMyListings from './pages/heen/MyListings';

import SupplierDashboard from './pages/supplier/Dashboard';
import SupplierInventory from './pages/supplier/Inventory';
import SupplierEquipmentForm from './pages/supplier/EquipmentForm';
import SupplierRentals from './pages/supplier/Rentals';
import SupplierMaintenance from './pages/supplier/Maintenance';

// Admin Pages
import AdminDashboard from './pages/admin/Dashboard';
import AdminVerification from './pages/admin/Verification';
import AdminHospitals from './pages/admin/Hospitals';
import AdminSuppliers from './pages/admin/Suppliers';
import AdminEquipment from './pages/admin/Equipment';
import AdminRentals from './pages/admin/Rentals';
import AdminPayments from './pages/admin/Payments';
import AdminCommission from './pages/admin/Commission';
import AdminRenewals from './pages/admin/Renewals';
import AdminReturns from './pages/admin/Returns';
import AdminSettings from './pages/admin/Settings';
import AdminUsers from './pages/admin/Users';
import AdminCategories from './pages/admin/Categories';
import AdminReports from './pages/admin/Reports';

import { useAuth } from './context/AuthContext';

function RoleRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'admin')    return <Navigate to="/admin"    replace />;
  if (user.role === 'supplier') return <Navigate to="/supplier" replace />;
  return <Navigate to="/hospital" replace />;
}

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot" element={<Forgot />} />
      <Route path="/reset" element={<Reset />} />

      {/* Dispatch by role */}
      <Route path="/app" element={<ProtectedRoute><RoleRedirect /></ProtectedRoute>} />

      {/* Hospital area */}
      <Route element={<ProtectedRoute roles={['hospital']}><DashboardLayout role="hospital" /></ProtectedRoute>}>
        <Route path="/hospital" element={<HospitalDashboard />} />
        <Route path="/hospital/equipment" element={<EquipmentBrowse />} />
        <Route path="/hospital/equipment/:id" element={<EquipmentDetail />} />
        <Route path="/hospital/rentals" element={<HospitalRentals />} />
        <Route path="/hospital/invoices" element={<HospitalInvoices />} />
        <Route path="/hospital/heen" element={<HeenList />} />
        <Route path="/hospital/heen/mine" element={<HeenMyListings />} />
        <Route path="/hospital/notifications" element={<Notifications />} />
        <Route path="/hospital/profile" element={<Profile />} />
      </Route>

      {/* Supplier area */}
      <Route element={<ProtectedRoute roles={['supplier']}><DashboardLayout role="supplier" /></ProtectedRoute>}>
        <Route path="/supplier" element={<SupplierDashboard />} />
        <Route path="/supplier/inventory" element={<SupplierInventory />} />
        <Route path="/supplier/inventory/new" element={<SupplierEquipmentForm />} />
        <Route path="/supplier/inventory/:id/edit" element={<SupplierEquipmentForm />} />
        <Route path="/supplier/rentals" element={<SupplierRentals />} />
        <Route path="/supplier/maintenance" element={<SupplierMaintenance />} />
        <Route path="/supplier/notifications" element={<Notifications />} />
        <Route path="/supplier/profile" element={<Profile />} />
      </Route>

      {/* Admin area */}
      <Route element={<ProtectedRoute roles={['admin']}><DashboardLayout role="admin" /></ProtectedRoute>}>
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/verification" element={<AdminVerification />} />
        <Route path="/admin/hospitals" element={<AdminHospitals />} />
        <Route path="/admin/suppliers" element={<AdminSuppliers />} />
        <Route path="/admin/equipment" element={<AdminEquipment />} />
        <Route path="/admin/rentals" element={<AdminRentals />} />
        <Route path="/admin/payments" element={<AdminPayments />} />
        <Route path="/admin/commission" element={<AdminCommission />} />
        <Route path="/admin/renewals" element={<AdminRenewals />} />
        <Route path="/admin/returns" element={<AdminReturns />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/categories" element={<AdminCategories />} />
        <Route path="/admin/reports" element={<AdminReports />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
        <Route path="/admin/notifications" element={<Notifications />} />
        <Route path="/admin/profile" element={<Profile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
