import axios from 'axios';
import { mockHandler } from './mockData';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
  timeout: 5000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('medirent_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  async (err) => {
    // If backend is unreachable (ECONNREFUSED / Network Error / 404 / 500 during local demo preview)
    const isNetworkOrOffline =
      !err.response ||
      err.code === 'ERR_NETWORK' ||
      err.code === 'ECONNREFUSED' ||
      err.response.status === 404 ||
      err.response.status === 500;

    if (isNetworkOrOffline && err.config) {
      const { url, method, data, params } = err.config;
      try {
        let parsedData = data;
        if (typeof data === 'string') {
          try { parsedData = JSON.parse(data); } catch (e) {}
        }
        const mockRes = mockHandler.handle(url, method, parsedData, params);
        if (mockRes) {
          return Promise.resolve(mockRes);
        }
      } catch (mockErr) {
        console.warn('Mock fallback handler error:', mockErr);
      }
    }

    if (err?.response?.status === 401 && !window.location.pathname.startsWith('/login')) {
      localStorage.removeItem('medirent_token');
      localStorage.removeItem('medirent_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;
