/**
 * In-memory / LocalStorage Demo Mock Store with Razorpay Test Mode & Commission Split
 */

const INITIAL_DATA = {
  settings: {
    commissionRate: 5.0,
    platformName: 'MediRent',
    tagline: 'Verified. Reliable. Accessible.',
    supportEmail: 'support@medirent.io',
    supportPhone: '+91 98765 43210',
    razorpayKeyId: 'rzp_test_medirent2026',
    razorpayTestMode: true,
    autoVerifyEquipment: false,
  },
  users: [
    {
      _id: 'u_admin_1',
      name: 'Platform Administrator',
      email: 'admin@medirent.io',
      role: 'admin',
      status: 'active',
      verificationStatus: 'verified',
      organizationName: 'MediRent Operations HQ',
      city: 'Chennai',
      phone: '+91 98765 00001',
      createdAt: '2026-08-01T00:00:00Z',
    },
    {
      _id: 'u_hosp_1',
      name: 'Dr. Anand Ramanathan',
      email: 'hospital@medirent.io',
      role: 'hospital',
      status: 'active',
      verificationStatus: 'verified',
      verifiedAt: '2026-08-15T00:00:00Z',
      organizationName: 'City Care Multi-Speciality Hospital',
      registrationNumber: 'HOSP-TN-2024-8891',
      hospitalType: 'Multi-Specialty Tertiary Care',
      contactPerson: 'Dr. Anand Ramanathan (Director)',
      address: '45, Anna Salai, Teynampet',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600018',
      phone: '+91 98401 23456',
      latitude: 13.0418,
      longitude: 80.2507,
      googleMapsUrl: 'https://maps.google.com/?q=13.0418,80.2507',
      documents: [
        { documentType: 'hospital_registration', fileName: 'City_Care_State_Health_Reg_2026.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'gst_pan', fileName: 'City_Care_GST_33AAAAA0000A1Z5.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'authorization', fileName: 'Board_Resolution_Equipment_Procurement.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      ],
      createdAt: '2026-08-10T00:00:00Z',
    },
    {
      _id: 'u_hosp_2',
      name: 'Dr. Priya Sundaram',
      email: 'apollo.clinic@medirent.demo',
      role: 'hospital',
      status: 'pending',
      verificationStatus: 'pending',
      organizationName: 'Kaveri Community Health Center',
      registrationNumber: 'HOSP-TN-2025-1042',
      hospitalType: 'Secondary Care Clinic',
      contactPerson: 'Dr. Priya Sundaram (Chief Administrator)',
      address: '12, Gandhi Road, RS Puram',
      city: 'Coimbatore',
      state: 'Tamil Nadu',
      pincode: '641002',
      phone: '+91 98402 77889',
      latitude: 11.0081,
      longitude: 76.9558,
      googleMapsUrl: 'https://maps.google.com/?q=11.0081,76.9558',
      documents: [
        { documentType: 'hospital_registration', fileName: 'Kaveri_Clinic_Establishment_Certificate.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'gst_pan', fileName: 'Kaveri_PAN_Card.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      ],
      createdAt: '2026-09-01T08:00:00Z',
    },
    {
      _id: 'u_supp_1',
      name: 'Rajesh Sharma',
      email: 'supplier@medirent.io',
      role: 'supplier',
      status: 'active',
      verificationStatus: 'verified',
      verifiedAt: '2026-08-10T00:00:00Z',
      organizationName: 'MedEquip Solutions Pvt Ltd',
      registrationNumber: 'MED-SUP-TN-4519',
      businessType: 'Authorized Equipment Dealer & Service Center',
      authorizedPerson: 'Rajesh Sharma (Managing Director)',
      address: 'Plot 18, 2nd Avenue, Anna Nagar East',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600102',
      phone: '+91 94440 98765',
      latitude: 13.0850,
      longitude: 80.2101,
      googleMapsUrl: 'https://maps.google.com/?q=13.0850,80.2101',
      documents: [
        { documentType: 'business_license', fileName: 'MedEquip_Trade_License_2026.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'gst_certificate', fileName: 'MedEquip_GST_Certificate_33AABCM8921B1Z9.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'dealer_authorization', fileName: 'Philips_Draeger_Authorised_Distributor_Letter.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      ],
      createdAt: '2026-08-05T00:00:00Z',
    },
    {
      _id: 'u_supp_2',
      name: 'Vikram Mehta',
      email: 'apex.med@medirent.demo',
      role: 'supplier',
      status: 'pending',
      verificationStatus: 'pending',
      organizationName: 'Apex Healthcare Devices Ltd',
      registrationNumber: 'MED-SUP-KA-7721',
      businessType: 'Critical Care Devices Rental Provider',
      authorizedPerson: 'Vikram Mehta (Partner)',
      address: '88, Industrial Suburb, Yeshwanthpur',
      city: 'Bangalore',
      state: 'Karnataka',
      pincode: '560022',
      phone: '+91 98801 55443',
      latitude: 13.0238,
      longitude: 77.5529,
      googleMapsUrl: 'https://maps.google.com/?q=13.0238,77.5529',
      documents: [
        { documentType: 'business_license', fileName: 'Apex_Incorporation_Certificate.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
        { documentType: 'ownership_proof', fileName: 'Ventilator_Invoice_Batch_2026.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      ],
      createdAt: '2026-09-01T09:00:00Z',
    },
  ],
  categories: [
    { _id: 'cat_1', name: 'Respiratory Support', description: 'Oxygen concentrators, ventilators, BiPAP/CPAP' },
    { _id: 'cat_2', name: 'ICU & Critical Care', description: 'Electric ICU beds, infusion pumps, syringe drivers' },
    { _id: 'cat_3', name: 'Patient Monitoring', description: 'Multiparameter monitors, ECG machines, pulse oximeters' },
    { _id: 'cat_4', name: 'Mobility & Support', description: 'Motorized wheelchairs, patient transfer hoists' },
    { _id: 'cat_5', name: 'Dialysis & Renal', description: 'Hemodialysis machines, peritoneal dialysis equipment' },
  ],
  equipment: [
    {
      _id: 'eq_1',
      name: 'Philips EverFlo Oxygen Concentrator 10L',
      category: { _id: 'cat_1', name: 'Respiratory Support' },
      manufacturer: 'Philips Healthcare',
      model: 'EverFlo 10L Ultra-Quiet',
      serialNumber: 'PH-OC-2024-9982',
      description: 'High-purity medical grade 10L continuous flow oxygen concentrator with integrated OPI indicator.',
      pricePerDay: 500,
      securityDeposit: 2000,
      quantity: 8,
      available: 7,
      condition: 'excellent',
      location: 'Anna Nagar, Chennai (2.4 km away)',
      maintenanceStatus: 'up_to_date',
      verificationStatus: 'verified',
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', city: 'Chennai', verificationStatus: 'verified' },
      images: ['https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80'],
      documents: [{ fileName: 'Philips_Calibration_Certificate_Q3.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' }],
      createdAt: '2026-08-11T00:00:00Z',
    },
    {
      _id: 'eq_2',
      name: 'Dräger Evita V300 Critical Care Ventilator',
      category: { _id: 'cat_1', name: 'Respiratory Support' },
      manufacturer: 'Dräger Medical',
      model: 'Evita V300',
      serialNumber: 'DR-EV-2025-4410',
      description: 'Intensive care ventilator for adult, pediatric, and neonatal patients with lung protective modes.',
      pricePerDay: 1800,
      securityDeposit: 8000,
      quantity: 4,
      available: 3,
      condition: 'new',
      location: 'Anna Nagar, Chennai',
      maintenanceStatus: 'up_to_date',
      verificationStatus: 'verified',
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', city: 'Chennai', verificationStatus: 'verified' },
      images: ['https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600&auto=format&fit=crop&q=80'],
      createdAt: '2026-08-12T00:00:00Z',
    },
    {
      _id: 'eq_3',
      name: 'GE Healthcare B40 Multiparameter Monitor',
      category: { _id: 'cat_3', name: 'Patient Monitoring' },
      manufacturer: 'GE Healthcare',
      model: 'B40 Patient Monitor',
      serialNumber: 'GE-B40-88124',
      description: '12.1-inch color display monitor for ECG, SpO2, NIBP, Dual Temp, and Respiration monitoring.',
      pricePerDay: 450,
      securityDeposit: 1500,
      quantity: 6,
      available: 6,
      condition: 'excellent',
      location: 'Anna Nagar, Chennai',
      maintenanceStatus: 'up_to_date',
      verificationStatus: 'verified',
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', city: 'Chennai', verificationStatus: 'verified' },
      images: ['https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600&auto=format&fit=crop&q=80'],
      createdAt: '2026-08-12T00:00:00Z',
    },
    {
      _id: 'eq_4',
      name: 'Stryker SV2 5-Function Electric ICU Bed',
      category: { _id: 'cat_2', name: 'ICU & Critical Care' },
      manufacturer: 'Stryker Medical',
      model: 'SV2 Advanced Electric',
      serialNumber: 'STR-SV2-3320',
      description: 'Motorized ICU bed with CPR quick release and integrated digital scale.',
      pricePerDay: 650,
      securityDeposit: 3000,
      quantity: 5,
      available: 5,
      condition: 'good',
      location: 'Anna Nagar, Chennai',
      maintenanceStatus: 'up_to_date',
      verificationStatus: 'verified',
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', city: 'Chennai', verificationStatus: 'verified' },
      images: ['https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=600&auto=format&fit=crop&q=80'],
      createdAt: '2026-08-12T00:00:00Z',
    },
    {
      _id: 'eq_pending_1',
      name: 'Fresenius 4008S Hemodialysis Machine',
      category: { _id: 'cat_5', name: 'Dialysis & Renal' },
      manufacturer: 'Fresenius Medical Care',
      model: '4008S Classic NextGen',
      serialNumber: 'FMC-4008S-9011',
      description: 'High-precision renal replacement therapy system with Online Clearance Monitoring.',
      pricePerDay: 2200,
      securityDeposit: 10000,
      quantity: 2,
      available: 2,
      condition: 'excellent',
      location: 'Yeshwanthpur, Bangalore',
      maintenanceStatus: 'up_to_date',
      verificationStatus: 'pending',
      owner: { _id: 'u_supp_2', name: 'Vikram Mehta', organizationName: 'Apex Healthcare Devices Ltd', city: 'Bangalore', verificationStatus: 'pending' },
      images: ['https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=600&auto=format&fit=crop&q=80'],
      documents: [{ fileName: 'Fresenius_Biomedical_Inspection_Report.pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' }],
      createdAt: '2026-09-01T10:00:00Z',
    },
  ],
  rentals: [
    {
      _id: 'r_1',
      rentalCode: 'MR-1001',
      equipment: { _id: 'eq_1', name: 'Philips EverFlo Oxygen Concentrator 10L', pricePerDay: 500 },
      renter: { _id: 'u_hosp_1', name: 'Dr. Anand Ramanathan', organizationName: 'City Care Multi-Speciality Hospital', email: 'hospital@medirent.io', phone: '+91 98401 23456', city: 'Chennai' },
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', email: 'supplier@medirent.io', phone: '+91 94440 98765', city: 'Chennai' },
      startDate: '2026-09-10T00:00:00Z',
      endDate: '2026-09-15T00:00:00Z',
      days: 5,
      pricePerDay: 500,
      totalAmount: 2500,
      commissionAmount: 125,
      supplierAmount: 2375,
      status: 'active',
      paymentStatus: 'captured',
      razorpayOrderId: 'order_MR1001_rzp_demo',
      razorpayPaymentId: 'pay_MR1001_rzp_demo_9921',
      settlementStatus: 'pending',
      pickupStatus: 'handed_over',
      pickupDetails: {
        pickupDate: '2026-09-10T00:00:00Z',
        pickupTime: '10:30 AM',
        driverName: 'Ravi Kumar',
        driverPhone: '+91 98409 11223',
        vehicleNumber: 'TN 01 AB 1234',
        vehicleType: 'Medical Logistics Van',
      },
      timeline: [
        { status: 'requested', at: '2026-09-08T09:00:00Z', note: 'Hospital requested 5-day rental' },
        { status: 'approved', at: '2026-09-08T11:30:00Z', note: 'Supplier approved rental request' },
        { status: 'paid', at: '2026-09-08T14:15:00Z', note: '₹2,500 captured via Razorpay Test Checkout (Split: ₹125 MediRent Fee + ₹2,375 Supplier Share)' },
        { status: 'pickup_scheduled', at: '2026-09-09T10:00:00Z', note: 'Driver Ravi Kumar (TN 01 AB 1234) assigned' },
        { status: 'handed_over', at: '2026-09-10T11:00:00Z', note: 'Equipment handed over to hospital driver' },
        { status: 'active', at: '2026-09-10T11:30:00Z', note: 'Active rental in progress' },
      ],
      createdAt: '2026-09-08T09:00:00Z',
    },
    {
      _id: 'r_2',
      rentalCode: 'MR-1002',
      equipment: { _id: 'eq_2', name: 'Dräger Evita V300 Critical Care Ventilator', pricePerDay: 1800 },
      renter: { _id: 'u_hosp_1', name: 'Dr. Anand Ramanathan', organizationName: 'City Care Multi-Speciality Hospital', email: 'hospital@medirent.io', phone: '+91 98401 23456', city: 'Chennai' },
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', email: 'supplier@medirent.io', phone: '+91 94440 98765', city: 'Chennai' },
      startDate: '2026-08-20T00:00:00Z',
      endDate: '2026-08-25T00:00:00Z',
      days: 5,
      pricePerDay: 1800,
      totalAmount: 9000,
      commissionAmount: 450,
      supplierAmount: 8550,
      status: 'completed',
      paymentStatus: 'captured',
      razorpayOrderId: 'order_MR1002_rzp_demo',
      razorpayPaymentId: 'pay_MR1002_rzp_demo_8832',
      settlementStatus: 'settled',
      pickupStatus: 'active',
      returnDetails: {
        requestedDate: '2026-08-25T00:00:00Z',
        returnDate: '2026-08-25T00:00:00Z',
        condition: 'good',
        damageNotes: 'Returned in full working order. Cleaned and recalibrated.',
        status: 'completed',
      },
      timeline: [
        { status: 'requested', at: '2026-08-18T10:00:00Z', note: 'Requested' },
        { status: 'approved', at: '2026-08-18T12:00:00Z', note: 'Approved' },
        { status: 'paid', at: '2026-08-18T15:00:00Z', note: '₹9,000 paid (Split: ₹450 Fee + ₹8,550 Supplier Share)' },
        { status: 'handed_over', at: '2026-08-20T09:00:00Z', note: 'Handed over' },
        { status: 'returned', at: '2026-08-25T16:00:00Z', note: 'Inspected and returned' },
        { status: 'completed', at: '2026-08-25T17:00:00Z', note: 'Completed & settled' },
      ],
      createdAt: '2026-08-18T10:00:00Z',
    },
    {
      _id: 'r_3',
      rentalCode: 'MR-1003',
      equipment: { _id: 'eq_3', name: 'GE Healthcare B40 Multiparameter Monitor', pricePerDay: 450 },
      renter: { _id: 'u_hosp_1', name: 'Dr. Anand Ramanathan', organizationName: 'City Care Multi-Speciality Hospital', email: 'hospital@medirent.io', phone: '+91 98401 23456', city: 'Chennai' },
      owner: { _id: 'u_supp_1', name: 'Rajesh Sharma', organizationName: 'MedEquip Solutions Pvt Ltd', email: 'supplier@medirent.io', phone: '+91 94440 98765', city: 'Chennai' },
      startDate: '2026-09-01T00:00:00Z',
      endDate: '2026-09-08T00:00:00Z',
      days: 7,
      pricePerDay: 450,
      totalAmount: 3150,
      commissionAmount: 157.5,
      supplierAmount: 2992.5,
      status: 'approved',
      paymentStatus: 'pending',
      settlementStatus: 'pending',
      pickupStatus: 'waiting_for_payment',
      createdAt: '2026-09-01T00:00:00Z',
    },
  ],
};

function getStorage() {
  const raw = localStorage.getItem('medirent_mock_db');
  if (raw) {
    try { return JSON.parse(raw); } catch (e) {}
  }
  localStorage.setItem('medirent_mock_db', JSON.stringify(INITIAL_DATA));
  return INITIAL_DATA;
}

function saveStorage(data) {
  localStorage.setItem('medirent_mock_db', JSON.stringify(data));
}

export const mockHandler = {
  handle(url, method = 'get', body = null, params = {}) {
    const db = getStorage();
    const cleanUrl = url.split('?')[0];

    // Razorpay Create Order Endpoint
    if (cleanUrl === '/payments/create-order' && method.toLowerCase() === 'post') {
      const { rentalId, amount } = body || {};
      const rental = db.rentals.find((r) => r._id === rentalId);
      const gross = amount || rental?.totalAmount || 2500;
      const orderId = 'order_' + (rental?.rentalCode || 'MR') + '_' + Date.now().toString().slice(-6);
      return {
        data: {
          keyId: db.settings.razorpayKeyId || 'rzp_test_medirent2026',
          orderId,
          amount: gross * 100, // in paise
          currency: 'INR',
          rentalId,
        },
      };
    }

    // Razorpay Verify & Instant Commission Split Endpoint
    if (cleanUrl === '/payments/verify' && method.toLowerCase() === 'post') {
      const { rentalId, razorpayOrderId, razorpayPaymentId, razorpaySignature } = body || {};
      const rental = db.rentals.find((r) => r._id === rentalId);
      if (rental) {
        const rate = db.settings.commissionRate || 5.0;
        const total = rental.totalAmount || 2500;
        const commission = Math.round(total * (rate / 100) * 100) / 100;
        const supplierShare = Math.round((total - commission) * 100) / 100;

        rental.paymentStatus = 'captured';
        rental.status = 'paid';
        rental.commissionAmount = commission;
        rental.supplierAmount = supplierShare;
        rental.razorpayOrderId = razorpayOrderId || ('order_' + Date.now());
        rental.razorpayPaymentId = razorpayPaymentId || ('pay_rzp_test_' + Date.now());
        rental.razorpaySignature = razorpaySignature || 'sig_verified_server_hash';
        rental.settlementStatus = 'pending';
        rental.pickupStatus = 'ready_for_pickup';

        rental.timeline = rental.timeline || [];
        rental.timeline.push({
          status: 'paid',
          at: new Date().toISOString(),
          note: `Captured ₹${total.toLocaleString()} via Razorpay Test Checkout. Automatic Marketplace Split: 5% Commission (₹${commission.toLocaleString()}) + 95% Supplier Share (₹${supplierShare.toLocaleString()}).`,
        });

        saveStorage(db);

        return {
          data: {
            success: true,
            message: 'Payment captured and commission split calculated successfully',
            rental,
            split: {
              gross: total,
              commissionRate: rate,
              commissionAmount: commission,
              supplierPayable: supplierShare,
              razorpayPaymentId: rental.razorpayPaymentId,
            },
          },
        };
      }
      return { data: { success: true, message: 'Verified' } };
    }

    // Auth
    if (cleanUrl === '/auth/login' && method.toLowerCase() === 'post') {
      const email = body?.email?.toLowerCase();
      let user = db.users.find((u) => u.email.toLowerCase() === email);
      if (!user) {
        user = {
          _id: 'u_' + Date.now(),
          name: email.split('@')[0],
          email,
          role: email.includes('admin') ? 'admin' : email.includes('supplier') ? 'supplier' : 'hospital',
          status: 'active',
          verificationStatus: 'verified',
        };
        db.users.push(user);
        saveStorage(db);
      }
      return { data: { token: 'mock_jwt_token_' + user._id, user } };
    }

    if (cleanUrl === '/auth/me') {
      const u = JSON.parse(localStorage.getItem('medirent_user') || 'null') || db.users[0];
      return { data: { user: u } };
    }

    // Admin Dashboard
    if (cleanUrl === '/admin/dashboard') {
      const hospitals = db.users.filter((u) => u.role === 'hospital');
      const suppliers = db.users.filter((u) => u.role === 'supplier');
      const verifiedHospitals = hospitals.filter((h) => h.verificationStatus === 'verified').length;
      const pendingHospitals = hospitals.filter((h) => h.verificationStatus === 'pending').length;
      const verifiedSuppliers = suppliers.filter((s) => s.verificationStatus === 'verified').length;
      const pendingSuppliers = suppliers.filter((s) => s.verificationStatus === 'pending').length;
      const verifiedEquipment = db.equipment.filter((e) => e.verificationStatus === 'verified').length;
      const pendingEquipment = db.equipment.filter((e) => e.verificationStatus === 'pending').length;

      const capturedRentals = db.rentals.filter((r) => r.paymentStatus === 'captured');
      const totalRevenue = capturedRentals.reduce((sum, r) => sum + (r.totalAmount || 0), 0);
      const totalCommission = capturedRentals.reduce((sum, r) => sum + (r.commissionAmount || 0), 0);
      const pendingSettlement = capturedRentals
        .filter((r) => r.settlementStatus === 'pending')
        .reduce((sum, r) => sum + (r.supplierAmount || 0), 0);

      return {
        data: {
          counts: {
            totalHospitals: hospitals.length,
            verifiedHospitals,
            pendingHospitals,
            totalSuppliers: suppliers.length,
            verifiedSuppliers,
            pendingSuppliers,
            totalEquipment: db.equipment.length,
            verifiedEquipment,
            pendingEquipment,
            activeRentals: db.rentals.filter((r) => r.status === 'active').length,
            pendingRentals: db.rentals.filter((r) => r.status === 'pending' || r.status === 'requested').length,
            totalPendingVerification: pendingHospitals + pendingSuppliers + pendingEquipment,
          },
          financials: {
            totalRevenue,
            totalCommission,
            pendingSettlement,
            commissionRate: db.settings.commissionRate,
          },
          monthly: [
            { _id: { y: 2026, m: 4 }, count: 12, revenue: 14500, commission: 725 },
            { _id: { y: 2026, m: 5 }, count: 18, revenue: 22000, commission: 1100 },
            { _id: { y: 2026, m: 6 }, count: 24, revenue: 31000, commission: 1550 },
            { _id: { y: 2026, m: 7 }, count: 28, revenue: 38500, commission: 1925 },
            { _id: { y: 2026, m: 8 }, count: 35, revenue: 49000, commission: 2450 },
            { _id: { y: 2026, m: 9 }, count: 42, revenue: 56500, commission: 2825 },
          ],
          mostRented: [
            { equipment: db.equipment[0], count: 24 },
            { equipment: db.equipment[1], count: 16 },
            { equipment: db.equipment[2], count: 12 },
            { equipment: db.equipment[3], count: 9 },
          ],
          recentRentals: db.rentals.slice(0, 5),
        },
      };
    }

    // Admin Payments
    if (cleanUrl === '/admin/payments') {
      let items = [...db.rentals];
      if (params.paymentStatus) items = items.filter((r) => r.paymentStatus === params.paymentStatus);
      if (params.settlementStatus) items = items.filter((r) => r.settlementStatus === params.settlementStatus);
      const totalGross = items.reduce((sum, r) => sum + (r.totalAmount || 0), 0);
      const totalCommission = items.reduce((sum, r) => sum + (r.commissionAmount || 0), 0);
      const totalSupplierShare = items.reduce((sum, r) => sum + (r.supplierAmount || 0), 0);
      const capturedCount = items.filter((r) => r.paymentStatus === 'captured').length;
      return {
        data: {
          items,
          total: items.length,
          page: 1,
          pages: 1,
          summary: { totalGross, totalCommission, totalSupplierShare, capturedCount },
        },
      };
    }

    if (cleanUrl.startsWith('/admin/payments/') && cleanUrl.endsWith('/settle')) {
      const id = cleanUrl.split('/')[3];
      const r = db.rentals.find((item) => item._id === id);
      if (r) {
        if (body?.paymentStatus) r.paymentStatus = body.paymentStatus;
        if (body?.settlementStatus) r.settlementStatus = body.settlementStatus;
        else r.settlementStatus = r.settlementStatus === 'settled' ? 'pending' : 'settled';
      }
      saveStorage(db);
      return { data: { message: `Settlement updated`, rental: r } };
    }

    // Admin Commission
    if (cleanUrl === '/admin/commission') {
      const capturedRentals = db.rentals.filter((r) => r.paymentStatus === 'captured');
      const totalGross = capturedRentals.reduce((sum, r) => sum + (r.totalAmount || 0), 0);
      const totalCommission = capturedRentals.reduce((sum, r) => sum + (r.commissionAmount || 0), 0);
      const totalSupplierPayable = capturedRentals.reduce((sum, r) => sum + (r.supplierAmount || 0), 0);
      const totalSettled = capturedRentals
        .filter((r) => r.settlementStatus === 'settled')
        .reduce((sum, r) => sum + (r.supplierAmount || 0), 0);
      const totalPendingSettlement = capturedRentals
        .filter((r) => r.settlementStatus === 'pending')
        .reduce((sum, r) => sum + (r.supplierAmount || 0), 0);

      const supplierBreakdown = [
        {
          owner: db.users.find((u) => u._id === 'u_supp_1') || { name: 'MedEquip Solutions', email: 'supplier@medirent.io', city: 'Chennai' },
          gross: totalGross,
          commission: totalCommission,
          supplierShare: totalSupplierPayable,
          settledPayout: totalSettled,
          pendingPayout: totalPendingSettlement,
          rentalCount: capturedRentals.length,
        },
      ];

      return {
        data: {
          summary: {
            totalGross,
            totalCommission,
            totalSupplierPayable,
            totalSettled,
            totalPendingSettlement,
            transactionCount: capturedRentals.length,
            commissionRate: db.settings.commissionRate,
          },
          supplierBreakdown,
        },
      };
    }

    // Rentals
    if (cleanUrl === '/admin/rentals' || cleanUrl === '/rentals') {
      let items = [...db.rentals];
      if (params.status) items = items.filter((r) => r.status === params.status);
      if (params.paymentStatus) items = items.filter((r) => r.paymentStatus === params.paymentStatus);
      return { data: { items, total: items.length, page: 1, pages: 1 } };
    }

    // Equipment
    if (cleanUrl === '/admin/equipment' || cleanUrl === '/equipment') {
      let items = [...db.equipment];
      if (params.verificationStatus) items = items.filter((e) => e.verificationStatus === params.verificationStatus);
      return { data: { items, total: items.length, page: 1, pages: 1 } };
    }

    // Categories
    if (cleanUrl === '/categories') {
      return { data: { items: db.categories, categories: db.categories } };
    }

    // Fallback
    return { data: { ok: true, message: 'Mock response' } };
  },
};
