import { useState, useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const NAV = {
  hospital: [
    { section: 'Overview' },
    { to: '/hospital', label: 'Dashboard', icon: '📊', end: true },
    { to: '/hospital/equipment', label: 'Browse Equipment', icon: '🩺' },
    { to: '/hospital/rentals', label: 'My Rentals', icon: '📦' },
    { to: '/hospital/invoices', label: 'Invoices', icon: '💳' },
    { section: 'HEEN Exchange' },
    { to: '/hospital/heen', label: 'Exchange Network', icon: '🔁' },
    { to: '/hospital/heen/mine', label: 'My Idle Listings', icon: '🏷️' },
    { section: 'Account' },
    { to: '/hospital/notifications', label: 'Notifications', icon: '🔔' },
    { to: '/hospital/profile', label: 'Profile', icon: '👤' },
  ],
  supplier: [
    { section: 'Overview' },
    { to: '/supplier', label: 'Dashboard', icon: '📊', end: true },
    { to: '/supplier/inventory', label: 'Inventory', icon: '📦' },
    { to: '/supplier/rentals', label: 'Rental Requests', icon: '📝' },
    { to: '/supplier/maintenance', label: 'Maintenance', icon: '🛠️' },
    { section: 'Account' },
    { to: '/supplier/notifications', label: 'Notifications', icon: '🔔' },
    { to: '/supplier/profile', label: 'Profile', icon: '👤' },
  ],
  admin: [
    { section: 'Overview' },
    { to: '/admin', label: 'Dashboard', icon: '📊', end: true },
    { section: 'Verification Desk' },
    { to: '/admin/verification', label: 'Verification Center', icon: '🛡️', badge: 'pendingCount' },
    { to: '/admin/hospitals', label: 'Hospitals', icon: '🏥' },
    { to: '/admin/suppliers', label: 'Suppliers', icon: '🏭' },
    { to: '/admin/equipment', label: 'Equipment Catalog', icon: '🩺' },
    { section: 'Marketplace Operations' },
    { to: '/admin/rentals', label: 'Rental Monitoring', icon: '📦' },
    { to: '/admin/payments', label: 'Payment Monitoring', icon: '💳' },
    { to: '/admin/commission', label: 'Commission & Payouts', icon: '💰' },
    { to: '/admin/renewals', label: 'Renewals & Extensions', icon: '🔄' },
    { to: '/admin/returns', label: 'Returns & Inspection', icon: '↩️' },
    { section: 'Platform Governance' },
    { to: '/admin/users', label: 'Users', icon: '👥' },
    { to: '/admin/categories', label: 'Categories', icon: '🗂️' },
    { to: '/admin/reports', label: 'Reports & Analytics', icon: '📈' },
    { to: '/admin/settings', label: 'Settings', icon: '⚙️' },
    { section: 'Account' },
    { to: '/admin/notifications', label: 'Notifications', icon: '🔔' },
    { to: '/admin/profile', label: 'Profile', icon: '👤' },
  ],
};

export default function DashboardLayout({ role }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    if (role === 'admin') {
      api.get('/admin/verification')
        .then((res) => {
          if (res.data?.totalPending !== undefined) {
            setPendingCount(res.data.totalPending);
          }
        })
        .catch(() => {});
    }
  }, [role]);

  const items = NAV[role] || [];
  const initials = (user?.name || '?').split(' ').map((s) => s[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark">M</div>
          <div>
            <div className="brand-name">MediRent</div>
            <div className="brand-tag">Verified. Reliable. Accessible.</div>
          </div>
        </div>
        <nav className="side-nav">
          {items.map((it, i) =>
            it.section
              ? <div key={i} className="side-section">{it.section}</div>
              : (
                <NavLink key={i} to={it.to} end={it.end} onClick={() => setOpen(false)}>
                  <span>{it.icon}</span>
                  <span style={{ flex: 1 }}>{it.label}</span>
                  {it.badge === 'pendingCount' && pendingCount > 0 && (
                    <span className="badge badge-danger badge-sm" style={{ padding: '0.15rem 0.45rem', fontSize: '0.7rem' }}>
                      {pendingCount}
                    </span>
                  )}
                </NavLink>
              )
          )}
          <div style={{ marginTop: '1.5rem', paddingBottom: '1rem' }}>
            <button className="btn btn-ghost" style={{ color: '#fff', width: '100%', justifyContent: 'flex-start' }} onClick={() => { logout(); nav('/'); }}>
              🚪 Sign out
            </button>
          </div>
        </nav>
      </aside>

      <div className="main">
        <header className="topbar">
          <button className="btn btn-ghost" style={{ display: 'none' }} onClick={() => setOpen(!open)}>☰</button>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <span className="badge badge-primary" style={{ textTransform: 'uppercase', letterSpacing: '1px' }}>{role}</span>
            <span style={{ fontWeight: 600, color: 'var(--slate-700)' }}>Portal</span>
          </div>
          <div className="search">
            <input placeholder="Search equipment, hospitals, suppliers, transactions…" />
          </div>
          <div className="user">
            <div className="avatar">{initials}</div>
            <div style={{ lineHeight: 1.2 }}>
              <div style={{ fontWeight: 600, fontSize: '.9rem' }}>{user?.name}</div>
              <div className="text-xs text-muted">{user?.organizationName || user?.email}</div>
            </div>
          </div>
        </header>
        <main className="content"><Outlet /></main>
      </div>
    </div>
  );
}
