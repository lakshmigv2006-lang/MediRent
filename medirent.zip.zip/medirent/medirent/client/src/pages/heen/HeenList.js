import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function HeenList() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const toast = useToast();

  const load = () => api.get('/exchange', { params: { q } }).then((r) => setItems(r.data.items));
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [q]);

  const request = async (eqId) => {
    const start = prompt('Start date (YYYY-MM-DD)'); if (!start) return;
    const end = prompt('End date (YYYY-MM-DD)'); if (!end) return;
    try {
      await api.post('/rentals', { equipment: eqId, quantity: 1, startDate: start, endDate: end });
      toast.success('HEEN rental request sent');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  return (
    <div>
      <div className="between mb-2">
        <div>
          <h1>HEEN — Healthcare Equipment Exchange Network</h1>
          <p className="text-muted">Idle equipment listed by other hospitals for peer-to-peer rental.</p>
        </div>
        <input className="form-control" style={{ maxWidth: 260 }} placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="grid grid-3">
        {items.map((l) => (
          <div key={l._id} className="eq-card">
            <div className="thumb">{l.equipment?.name?.[0] || '?'}</div>
            <div className="body">
              <div className="row mb-1"><span className="badge badge-primary">HEEN</span><span className="badge">{l.equipment?.condition}</span></div>
              <div style={{ fontWeight: 600 }}>{l.equipment?.name}</div>
              <div className="meta">Listed by {l.hospital?.organizationName || l.hospital?.name} · {l.hospital?.city}</div>
              <div className="between mt-1">
                <div className="price">₹{l.equipment?.pricePerDay}<span className="text-xs text-muted"> /day</span></div>
              </div>
              <div className="row mt-2">
                <Link className="btn btn-sm" to={`/hospital/equipment/${l.equipment?._id}`}>Details</Link>
                <button className="btn btn-sm btn-primary" onClick={() => request(l.equipment?._id)}>Request rental</button>
              </div>
            </div>
          </div>
        ))}
        {items.length === 0 && <div className="card text-muted">No idle equipment listed yet.</div>}
      </div>
    </div>
  );
}
