import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function HeenMyListings() {
  const { user } = useAuth();
  const toast = useToast();
  const [equipment, setEquipment] = useState([]);
  const [listings, setListings] = useState([]);
  const [form, setForm] = useState({ equipment: '', availableFrom: '', availableTo: '', note: '' });
  const [creating, setCreating] = useState(false);
  const [newEq, setNewEq] = useState({ name: '', category: '', pricePerDay: '', quantity: 1, condition: 'good', description: '' });
  const [cats, setCats] = useState([]);

  const loadMine = () => {
    api.get('/equipment', { params: { owner: user._id, ownerType: 'hospital', limit: 100 } })
      .then((r) => setEquipment(r.data.items));
    api.get('/exchange').then((r) => setListings(r.data.items.filter((l) => l.hospital?._id === user._id)));
  };
  useEffect(() => { loadMine(); api.get('/categories').then((r) => setCats(r.data.items)); /* eslint-disable-next-line */ }, []);

  const create = async (e) => {
    e.preventDefault();
    try {
      await api.post('/exchange', form);
      toast.success('Listed on HEEN');
      setForm({ equipment: '', availableFrom: '', availableTo: '', note: '' });
      loadMine();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const createEquipment = async (e) => {
    e.preventDefault();
    try {
      await api.post('/equipment', newEq);
      toast.success('Idle equipment added');
      setCreating(false);
      setNewEq({ name: '', category: '', pricePerDay: '', quantity: 1, condition: 'good', description: '' });
      loadMine();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const close = async (id) => { await api.patch(`/exchange/${id}/close`); loadMine(); };

  return (
    <div>
      <div className="between mb-2">
        <div>
          <h1>My HEEN Listings</h1>
          <p className="text-muted">List idle equipment your hospital owns for peer-to-peer rental.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setCreating(!creating)}>
          {creating ? 'Close' : '+ Add idle equipment'}
        </button>
      </div>

      {creating && (
        <form className="card mb-3" onSubmit={createEquipment}>
          <h3>Add idle equipment</h3>
          <div className="form-row">
            <div className="form-group"><label>Name</label>
              <input className="form-control" value={newEq.name} onChange={(e) => setNewEq({ ...newEq, name: e.target.value })} required /></div>
            <div className="form-group"><label>Category</label>
              <select className="form-control" value={newEq.category} onChange={(e) => setNewEq({ ...newEq, category: e.target.value })} required>
                <option value="">Select…</option>{cats.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Price / day (₹)</label>
              <input type="number" className="form-control" value={newEq.pricePerDay}
                onChange={(e) => setNewEq({ ...newEq, pricePerDay: e.target.value })} required /></div>
            <div className="form-group"><label>Quantity</label>
              <input type="number" min="1" className="form-control" value={newEq.quantity}
                onChange={(e) => setNewEq({ ...newEq, quantity: Number(e.target.value) })} /></div>
          </div>
          <div className="form-group"><label>Description</label>
            <textarea className="form-control" rows="3" value={newEq.description}
              onChange={(e) => setNewEq({ ...newEq, description: e.target.value })} /></div>
          <button className="btn btn-primary">Save equipment</button>
        </form>
      )}

      <div className="grid grid-2">
        <form className="card" onSubmit={create}>
          <h3>New HEEN listing</h3>
          <div className="form-group"><label>Equipment</label>
            <select className="form-control" value={form.equipment} onChange={(e) => setForm({ ...form, equipment: e.target.value })} required>
              <option value="">Select your equipment…</option>
              {equipment.map((e) => <option key={e._id} value={e._id}>{e.name}</option>)}
            </select>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Available from</label>
              <input type="date" className="form-control" value={form.availableFrom}
                onChange={(e) => setForm({ ...form, availableFrom: e.target.value })} /></div>
            <div className="form-group"><label>Available to</label>
              <input type="date" className="form-control" value={form.availableTo}
                onChange={(e) => setForm({ ...form, availableTo: e.target.value })} /></div>
          </div>
          <div className="form-group"><label>Note</label>
            <textarea className="form-control" rows="2" value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
          <button className="btn btn-primary">Publish listing</button>
        </form>

        <div className="card">
          <h3>My active listings</h3>
          {listings.length === 0 ? <div className="text-muted">You have no active HEEN listings.</div> : (
            <table className="table">
              <thead><tr><th>Equipment</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {listings.map((l) => (
                  <tr key={l._id}>
                    <td>{l.equipment?.name}</td>
                    <td><span className="badge badge-info">{l.status}</span></td>
                    <td className="right">
                      {l.status !== 'closed' && <button className="btn btn-sm" onClick={() => close(l._id)}>Close</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
