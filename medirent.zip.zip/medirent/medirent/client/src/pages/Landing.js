import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div className="public-shell">
      <header className="public-nav" style={{ padding: '1rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', borderBottom: '1px solid var(--border)' }}>
        <div className="logo" style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontWeight: 700, fontSize: '1.25rem' }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10,
            background: 'linear-gradient(135deg, var(--teal-500), var(--accent))',
            color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700,
          }}>M</div>
          <div>
            <div>MediRent</div>
            <div style={{ fontSize: '0.65rem', color: 'var(--muted)', fontWeight: 500, letterSpacing: '0.5px' }}>
              Verified. Reliable. Accessible.
            </div>
          </div>
        </div>
        <div className="row">
          <Link to="/login" className="btn btn-ghost">Sign in</Link>
          <Link to="/register" className="btn btn-primary">Find Equipment</Link>
        </div>
      </header>

      <section className="hero">
        <h1>Healthcare Equipment. <span className="highlight">Available When You Need It.</span></h1>
        <p>
          MediRent connects verified hospitals with verified healthcare equipment suppliers through a trusted rental marketplace. Intelligently matching equipment by availability, condition, price, and distance with digital payments and coordinated pickup.
        </p>
        <div className="hero-cta">
          <Link to="/login" className="btn btn-primary">Find Equipment</Link>
          <Link to="/register" className="btn btn-outline">List Your Equipment</Link>
          <Link to="/login" className="btn btn-ghost" style={{ background: '#f1f5f9' }}>👑 Admin Access</Link>
        </div>
      </section>

      {/* How It Works (Section 6 of master prompt) */}
      <section className="features">
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <h2 style={{ fontSize: '1.8rem' }}>How MediRent Works</h2>
          <p className="text-muted">A complete verified healthcare rental lifecycle from registration to return.</p>
        </div>

        <div className="grid grid-4 mb-3">
          <div className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>1️⃣ 🏥</div>
            <h4>Register & Verify</h4>
            <p className="text-xs text-muted">Hospitals & suppliers upload licenses and certifications for Admin verification.</p>
          </div>

          <div className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>2️⃣ 🩺</div>
            <h4>Smart Discovery</h4>
            <p className="text-xs text-muted">Search medical grade equipment with location awareness and AI recommendation.</p>
          </div>

          <div className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>3️⃣ 💳</div>
            <h4>Digital Payment</h4>
            <p className="text-xs text-muted">Razorpay checkout, verified server-side capture, and 5% marketplace commission split.</p>
          </div>

          <div className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>4️⃣ 🚚</div>
            <h4>Pickup & Return</h4>
            <p className="text-xs text-muted">Hospital arranges driver pickup, supplier hands over device, with easy renewal or return.</p>
          </div>
        </div>

        {/* 3 Core Roles */}
        <div className="grid grid-3">
          <div className="feature card">
            <div className="icon">🏥</div>
            <h3>For Hospitals</h3>
            <p>On-demand access to oxygen concentrators, ventilators, monitors, and ICU beds with verified certificates and distance calculation.</p>
          </div>
          <div className="feature card">
            <div className="icon">🏭</div>
            <h3>For Suppliers</h3>
            <p>Monetize equipment inventory, receive instant requests, track vehicle handovers, manage maintenance, and receive settlements.</p>
          </div>
          <div className="feature card">
            <div className="icon">🛡️</div>
            <h3>Admin Governance</h3>
            <p>Verification desk for credentials, rental transaction lifecycle monitoring, Razorpay audit logs, and platform revenue splits.</p>
          </div>
        </div>
      </section>

      <footer style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)', borderTop: '1px solid var(--border)', background: '#fff' }}>
        <strong>MediRent — Healthcare Equipment Rental Platform</strong> · Verified. Reliable. Accessible. · © {new Date().getFullYear()}
      </footer>
    </div>
  );
}
