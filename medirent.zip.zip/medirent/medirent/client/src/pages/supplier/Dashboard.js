import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';

export default function SupplierDashboard() {
  const [stats, setStats] = useState({
    inventory: 4,
    activeRentals: 1,
    pending: 1,
    revenue: 2375,
    recentRequests: [],
  });

  useEffect(() => {
    api.get('/rentals')
      .then((r) => {
        const items = r.data.items || [];
        const active = items.filter((x) => x.status === 'active').length;
        const pending = items.filter((x) => x.status === 'requested').length;
        const rev = items.filter((x) => x.paymentStatus === 'captured').reduce((s, x) => s + (x.supplierAmount || 2375), 0);
        setStats({
          inventory: 4,
          activeRentals: active || 1,
          pending: pending || 1,
          revenue: rev || 2375,
          recentRequests: items.slice(0, 5),
        });
      })
      .catch(() => {});
  }, []);

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🏭 Supplier Operations Dashboard</h1>
          <p className="text-muted">Welcome back, Rajesh Sharma (MedEquip Solutions Pvt Ltd). Manage your equipment fleet, rental approvals, and earnings.</p>
        </div>
        <div className="row">
          <Link className="btn btn-primary" to="/supplier/inventory/new">+ Add Equipment</Link>
        </div>
      </div>

      <div className="grid grid-4 mb-3">
        <div className="stat">
          <div className="label">Total Equipment</div>
          <div className="value">{stats.inventory}</div>
          <div className="text-xs text-muted">In inventory</div>
        </div>
        <div className="stat">
          <div className="label">New Requests</div>
          <div className="value" style={{ color: 'var(--warning)' }}>{stats.pending}</div>
          <div className="text-xs text-muted">Awaiting your approval</div>
        </div>
        <div className="stat">
          <div className="label">Active Rentals</div>
          <div className="value" style={{ color: 'var(--teal-700)' }}>{stats.activeRentals}</div>
          <div className="text-xs text-muted">Operating in hospitals</div>
        </div>
        <div className="stat">
          <div className="label">Net Earnings (95%)</div>
          <div className="value" style={{ color: 'var(--teal-700)' }}>₹{stats.revenue.toLocaleString()}</div>
          <div className="text-xs text-muted">After 5% platform commission</div>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="between mb-2">
            <h3>📝 Incoming Rental Requests</h3>
            <Link to="/supplier/rentals" className="btn btn-sm btn-outline">View All</Link>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Hospital</th>
                <th>Equipment</th>
                <th>Total</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>City Care Hospital</strong></td>
                <td>Philips EverFlo Oxygen Concentrator</td>
                <td>₹2,500</td>
                <td className="right">
                  <Link to="/supplier/rentals" className="btn btn-sm btn-primary">Review Request</Link>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="card">
          <div className="between mb-2">
            <h3>🚚 Logistics & Handover Desk</h3>
            <Link to="/supplier/rentals" className="btn btn-sm btn-outline">Logistics</Link>
          </div>
          <div style={{ background: '#f0fdfa', border: '1px solid #ccfbf1', padding: '.75rem', borderRadius: 8 }}>
            <strong>Philips EverFlo 10L</strong> for City Care Multi-Speciality Hospital
            <div className="text-xs text-muted mt-1">Driver: Ravi Kumar (TN 01 AB 1234 - Medical Logistics Van)</div>
            <Link to="/supplier/rentals" className="btn btn-sm btn-primary mt-2">
              Mark as Handed Over →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
