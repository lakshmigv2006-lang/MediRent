import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function SupplierMaintenance() {
  const [items, setItems] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [form, setForm] = useState({ equipment: '', scheduledFor: '', cost: 0, notes: '' });
  const toast = useToast();

  const load = () => api.get('/maintenance').then((r) => setItems(r.data.items));
  useEffect(() => {
    load();
    api.get('/equipment', { params: { limit: 100 } }).then((r) => setEquipment(r.data.items));
  }, []);

  const create = async (e) => {
    e.preventDefault();
    try { await api.post('/maintenance', form); toast.success('Scheduled'); setForm({ equipment: '', scheduledFor: '', cost: 0, notes: '' }); load(); }
    catch (err) { toast.error('Failed'); }
  };

  const complete = async (id) => { await api.patch(`/maintenance/${id}`, { status: 'completed', performedAt: new Date() }); load(); };

  return (
    <div>
      <h1>Maintenance</h1>
      <div className="grid grid-2">
        <form className="card" onSubmit={create}>
          <h3>Schedule maintenance</h3>
          <div className="form-group"><label>Equipment</label>
            <select className="form-control" value={form.equipment} onChange={(e) => setForm({ ...form, equipment: e.target.value })} required>
              <option value="">Select…</option>
              {equipment.map((e) => <option key={e._id} value={e._id}>{e.name}</option>)}
            </select></div>
          <div className="form-row">
            <div className="form-group"><label>Scheduled for</label>
              <input type="date" className="form-control" value={form.scheduledFor} onChange={(e) => setForm({ ...form, scheduledFor: e.target.value })} required /></div>
            <div className="form-group"><label>Cost (₹)</label>
              <input type="number" className="form-control" value={form.cost} onChange={(e) => setForm({ ...form, cost: Number(e.target.value) })} /></div>
          </div>
          <div className="form-group"><label>Notes</label>
            <textarea className="form-control" rows="3" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          <button className="btn btn-primary">Schedule</button>
        </form>
        <div className="card">
          <h3>Service history</h3>
          <table className="table">
            <thead><tr><th>Equipment</th><th>Date</th><th>Cost</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {items.map((m) => (
                <tr key={m._id}>
                  <td>{m.equipment?.name}</td>
                  <td>{m.scheduledFor ? new Date(m.scheduledFor).toLocaleDateString() : '—'}</td>
                  <td>₹{m.cost || 0}</td>
                  <td><span className={`badge ${m.status === 'completed' ? 'badge-success' : 'badge-warn'}`}>{m.status}</span></td>
                  <td className="right">{m.status !== 'completed' && <button className="btn btn-sm" onClick={() => complete(m._id)}>Complete</button>}</td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan="5" className="text-muted">No maintenance scheduled.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
