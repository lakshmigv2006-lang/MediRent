import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function SupplierInventory() {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const load = () => {
    setLoading(true);
    api.get('/equipment', { params: { owner: user._id, limit: 100 } })
      .then((r) => setItems(r.data.items)).finally(() => setLoading(false));
  };
  useEffect(load, [user._id]);
  const del = async (id) => {
    if (!window.confirm('Delete this equipment?')) return;
    await api.delete(`/equipment/${id}`);
    toast.success('Deleted'); load();
  };
  return (
    <div>
      <div className="between mb-2"><h1>Inventory</h1>
        <Link className="btn btn-primary" to="/supplier/inventory/new">+ Add equipment</Link></div>
      {loading ? <div className="center-loader"><div className="spinner" /></div> : (
        <table className="table">
          <thead><tr><th>Name</th><th>Category</th><th>Price/day</th><th>Available</th><th>Condition</th><th></th></tr></thead>
          <tbody>
            {items.map((e) => (
              <tr key={e._id}>
                <td>{e.name}</td>
                <td>{e.category?.name}</td>
                <td>₹{e.pricePerDay}</td>
                <td>{e.available}/{e.quantity}</td>
                <td><span className="badge">{e.condition}</span></td>
                <td className="right">
                  <Link className="btn btn-sm" to={`/supplier/inventory/${e._id}/edit`}>Edit</Link>{' '}
                  <button className="btn btn-sm btn-danger" onClick={() => del(e._id)}>Delete</button>
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan="6" className="text-muted">No equipment yet.</td></tr>}
          </tbody>
        </table>
      )}
    </div>
  );
}
