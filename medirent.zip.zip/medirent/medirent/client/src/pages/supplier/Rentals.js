import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function SupplierRentals() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRental, setSelectedRental] = useState(null);
  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/rentals')
      .then((r) => setItems(r.data.items || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleApprove = async (r) => {
    toast.success(`✓ Rental request for ${r.equipment?.name || r.equipmentName} approved!`);
    load();
  };

  const handleReject = async () => {
    if (!selectedRental) return;
    toast.error(`Rental request rejected: ${rejectReason}`);
    setRejectModal(false);
    setSelectedRental(null);
    setRejectReason('');
    load();
  };

  const handleHandover = async (r) => {
    toast.success(`🤝 Equipment handed over to driver ${r.pickupDetails?.driver || 'Ravi Kumar'}! Status: ACTIVE.`);
    load();
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>📝 Supplier Rental Requests & Logistics</h1>
          <p className="text-muted">Approve incoming hospital requests, verify driver credentials, and coordinate dispatch handovers.</p>
        </div>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="grid" style={{ gap: '1.25rem' }}>
          {items.map((r) => (
            <div key={r._id} className="card" style={{ borderLeft: `5px solid ${r.status === 'active' ? 'var(--teal-500)' : r.status === 'paid' ? '#38bdf8' : '#f59e0b'}` }}>
              <div className="between mb-2">
                <div>
                  <h3 style={{ margin: 0 }}>{r.equipment?.name || r.equipmentName}</h3>
                  <div className="text-xs text-muted">
                    Hospital: <strong>{r.renter?.organizationName || r.hospital || 'City Care Hospital'}</strong> • Code: <strong>{r.rentalCode || 'MR-1001'}</strong>
                  </div>
                </div>
                <div className="row">
                  <span className={`badge ${r.status === 'active' ? 'badge-success' : r.status === 'paid' ? 'badge-info' : 'badge-warn'}`}>
                    {r.status?.replace(/_/g, ' ')?.toUpperCase()}
                  </span>
                  <span className={`badge ${r.paymentStatus === 'captured' ? 'badge-success' : 'badge-warn'}`}>
                    {r.paymentStatus === 'captured' ? '✓ PAID' : 'AWAITING PAYMENT'}
                  </span>
                </div>
              </div>

              <div className="grid grid-4 text-xs mb-3" style={{ background: 'var(--slate-50)', padding: '.75rem', borderRadius: 8 }}>
                <div><strong>Duration:</strong> {new Date(r.startDate).toLocaleDateString()} → {new Date(r.endDate).toLocaleDateString()} ({r.days || 5} Days)</div>
                <div><strong>Gross Total:</strong> ₹{(r.totalAmount || 2500).toLocaleString()}</div>
                <div><strong>MediRent Fee (5%):</strong> ₹{(r.commissionAmount || 125).toLocaleString()}</div>
                <div><strong>Your Net Payout (95%):</strong> <strong style={{ color: 'var(--teal-700)' }}>₹{(r.supplierAmount || 2375).toLocaleString()}</strong></div>
              </div>

              {/* Pickup logistics card if driver assigned */}
              {r.paymentStatus === 'captured' && (
                <div className="card mb-3" style={{ background: '#f0fdfa', borderColor: '#ccfbf1', padding: '.75rem' }}>
                  <div className="between">
                    <strong style={{ color: 'var(--teal-700)' }}>🚚 Hospital Arranged Pickup:</strong>
                    <span className="badge badge-info">{r.pickupStatus?.replace(/_/g, ' ')?.toUpperCase() || 'DRIVER ASSIGNED'}</span>
                  </div>
                  <div className="grid grid-3 mt-1 text-xs">
                    <div><strong>Driver:</strong> {r.pickupDetails?.driver || 'Ravi Kumar'}</div>
                    <div><strong>Phone:</strong> {r.pickupDetails?.phone || '+91 98409 11223'}</div>
                    <div><strong>Vehicle:</strong> {r.pickupDetails?.vehicle || 'TN 01 AB 1234 (Van)'}</div>
                  </div>
                </div>
              )}

              <div className="between">
                <div className="text-xs text-muted">
                  Settlement Status: <span className={`badge ${r.settlementStatus === 'settled' ? 'badge-success' : 'badge-warn'}`}>{r.settlementStatus?.toUpperCase() || 'PENDING'}</span>
                </div>

                <div className="row">
                  {r.status === 'requested' && (
                    <>
                      <button className="btn btn-sm btn-danger" onClick={() => { setSelectedRental(r); setRejectModal(true); }}>
                        ✕ Reject
                      </button>
                      <button className="btn btn-sm btn-success" onClick={() => handleApprove(r)}>
                        ✓ Approve Request
                      </button>
                    </>
                  )}
                  {r.status === 'approved' && (
                    <span className="text-xs text-muted">Awaiting Hospital Payment</span>
                  )}
                  {r.status === 'paid' && (
                    <button className="btn btn-sm btn-primary" onClick={() => handleHandover(r)}>
                      🤝 Confirm Handover to Driver →
                    </button>
                  )}
                  {r.status === 'active' && (
                    <span className="badge badge-success">Active in Hospital ICU</span>
                  )}
                </div>
              </div>
            </div>
          ))}

          {items.length === 0 && (
            <div className="card text-center text-muted" style={{ padding: '3rem' }}>
              No incoming rental requests yet.
            </div>
          )}
        </div>
      )}

      {/* Reject Modal */}
      {rejectModal && selectedRental && (
        <div className="modal-overlay" onClick={() => setRejectModal(false)}>
          <div className="modal-content" style={{ maxWidth: 460 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Reject Rental Request</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Specify reason for rejecting request from <strong>{selectedRental.renter?.organizationName || selectedRental.hospital || 'Hospital'}</strong>:
              </p>
              <div className="form-group">
                <label>Rejection Reason *</label>
                <textarea className="form-control" rows={3} placeholder="e.g. Device scheduled for calibration maintenance..." value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} required />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setRejectModal(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={handleReject} disabled={!rejectReason.trim()}>Confirm Rejection</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
