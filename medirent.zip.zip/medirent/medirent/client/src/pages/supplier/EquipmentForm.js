import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

const empty = {
  name: '', category: '', description: '', pricePerDay: '', quantity: 1,
  condition: 'good', location: '', warranty: '', maintenanceCertificate: '',
};

export default function EquipmentForm() {
  const { id } = useParams();
  const nav = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(empty);
  const [cats, setCats] = useState([]);

  useEffect(() => {
    api.get('/categories').then((r) => setCats(r.data.items));
    if (id) api.get(`/equipment/${id}`).then((r) => {
      const e = r.data.item;
      setForm({
        name: e.name, category: e.category?._id || '', description: e.description || '',
        pricePerDay: e.pricePerDay, quantity: e.quantity, condition: e.condition,
        location: e.location || '', warranty: e.warranty || '',
        maintenanceCertificate: e.maintenanceCertificate || '',
      });
    });
  }, [id]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try {
      if (id) await api.put(`/equipment/${id}`, form);
      else await api.post('/equipment', form);
      toast.success('Saved');
      nav('/supplier/inventory');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  return (
    <form className="card" onSubmit={submit} style={{ maxWidth: 800 }}>
      <h1>{id ? 'Edit' : 'Add'} equipment</h1>
      <div className="form-row">
        <div className="form-group"><label>Name</label>
          <input className="form-control" value={form.name} onChange={set('name')} required /></div>
        <div className="form-group"><label>Category</label>
          <select className="form-control" value={form.category} onChange={set('category')} required>
            <option value="">Select…</option>
            {cats.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select></div>
      </div>
      <div className="form-group"><label>Description</label>
        <textarea className="form-control" rows="3" value={form.description} onChange={set('description')} /></div>
      <div className="form-row">
        <div className="form-group"><label>Price / day (₹)</label>
          <input type="number" className="form-control" value={form.pricePerDay} onChange={set('pricePerDay')} required /></div>
        <div className="form-group"><label>Quantity</label>
          <input type="number" min="1" className="form-control" value={form.quantity} onChange={set('quantity')} /></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label>Condition</label>
          <select className="form-control" value={form.condition} onChange={set('condition')}>
            <option>new</option><option>excellent</option><option>good</option><option>fair</option>
          </select></div>
        <div className="form-group"><label>Location</label>
          <input className="form-control" value={form.location} onChange={set('location')} /></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label>Warranty</label>
          <input className="form-control" value={form.warranty} onChange={set('warranty')} /></div>
        <div className="form-group"><label>Maintenance certificate</label>
          <input className="form-control" value={form.maintenanceCertificate} onChange={set('maintenanceCertificate')} /></div>
      </div>
      <button className="btn btn-primary">Save</button>
    </form>
  );
}
