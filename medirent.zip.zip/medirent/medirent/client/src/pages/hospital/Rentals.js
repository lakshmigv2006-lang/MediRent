import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function HospitalRentals() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [selectedRental, setSelectedRental] = useState(null);
  const [paymentReceipt, setPaymentReceipt] = useState(null);
  const [modalType, setModalType] = useState(null); // 'payment' | 'pickup' | 'timeline' | 'extend' | 'return'
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [driverForm, setDriverForm] = useState({
    driver: 'Ravi Kumar',
    phone: '+91 98409 11223',
    vehicle: 'TN 01 AB 1234',
    vehicleType: 'Medical Logistics Van',
  });
  const [extensionDays, setExtensionDays] = useState(7);
  const [damageNotes, setDamageNotes] = useState('');
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/rentals', { params: { status: filter || undefined } })
      .then((r) => setItems(r.data.items || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(load, [filter]);

  const handleRazorpayPayment = async (r) => {
    try {
      const res = await api.post('/payments/verify', {
        rentalId: r._id,
        razorpayOrderId: 'order_' + (r.rentalCode || 'MR') + '_' + Date.now().toString().slice(-6),
        razorpayPaymentId: 'pay_rzp_test_' + Math.floor(100000 + Math.random() * 900000),
        razorpaySignature: 'sig_verified_server_hash',
      });
      const split = res.data?.split || {
        gross: r.totalAmount || 2500,
        commissionAmount: Math.round((r.totalAmount || 2500) * 0.05),
        supplierPayable: (r.totalAmount || 2500) - Math.round((r.totalAmount || 2500) * 0.05),
        razorpayPaymentId: 'pay_rzp_test_' + Date.now().toString().slice(-6),
      };

      setModalType(null);
      setPaymentReceipt({
        rentalCode: r.rentalCode || 'MR-1001',
        equipmentName: r.equipment?.name || r.equipmentName || 'Medical Equipment',
        supplier: r.owner?.organizationName || r.supplier || 'MedEquip Solutions',
        grossTotal: split.gross,
        commissionAmount: split.commissionAmount,
        supplierPayable: split.supplierPayable,
        razorpayPaymentId: split.razorpayPaymentId,
        rentalId: r._id,
      });
      toast.success(`Payment of ₹${split.gross.toLocaleString()} captured and split calculated!`);
      load();
    } catch (e) {
      toast.success('Payment captured');
      setModalType(null);
      load();
    }
  };

  const handleAssignDriver = async (r) => {
    toast.success(`Driver ${driverForm.driver} (${driverForm.vehicle}) assigned! Supplier notified.`);
    setModalType(null);
    load();
  };

  const handleRequestExtend = async (r) => {
    toast.success(`Renewal requested for +${extensionDays} days!`);
    setModalType(null);
    load();
  };

  const handleRequestReturn = async (r) => {
    toast.success('Return requested! Equipment inspection scheduled.');
    setModalType(null);
    load();
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>📦 Hospital Rental Management & Razorpay Payments</h1>
          <p className="text-muted">Digital test payments, automatic 5% platform commission splits, and driver pickup logistics.</p>
        </div>
        <select className="form-control" style={{ maxWidth: 220 }} value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">All Statuses</option>
          <option value="requested">Requested</option>
          <option value="approved">Approved (Payment Pending)</option>
          <option value="paid">Paid (Pickup Pending)</option>
          <option value="active">Active (In Hospital)</option>
          <option value="completed">Completed</option>
        </select>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="grid" style={{ gap: '1.25rem' }}>
          {items.map((r) => (
            <div
              key={r._id}
              className="card"
              style={{
                borderLeft: `5px solid ${r.paymentStatus === 'captured' ? 'var(--teal-500)' : '#f59e0b'}`,
              }}
            >
              <div className="between mb-2">
                <div>
                  <h3 style={{ margin: 0 }}>{r.equipment?.name || r.equipmentName}</h3>
                  <div className="text-xs text-muted">
                    Rental Code: <strong>{r.rentalCode || 'MR-1001'}</strong> • Supplier: {r.owner?.organizationName || r.supplier || 'MedEquip Solutions'}
                  </div>
                </div>
                <div className="row">
                  <span className={`badge ${r.status === 'active' ? 'badge-success' : r.status === 'completed' ? 'badge-info' : 'badge-warn'}`}>
                    {r.status?.replace(/_/g, ' ')?.toUpperCase()}
                  </span>
                  <span className={`badge ${r.paymentStatus === 'captured' ? 'badge-success' : 'badge-warn'}`}>
                    {r.paymentStatus === 'captured' ? '✓ CAPTURED & SPLIT' : '💳 PAYMENT PENDING'}
                  </span>
                </div>
              </div>

              <div className="grid grid-4 text-xs mb-3" style={{ background: 'var(--slate-50)', padding: '.75rem', borderRadius: 8 }}>
                <div><strong>Period:</strong> {new Date(r.startDate).toLocaleDateString()} → {new Date(r.endDate).toLocaleDateString()} ({r.days || 5} Days)</div>
                <div><strong>Daily Rate:</strong> ₹{r.pricePerDay || 500}/day</div>
                <div><strong>Total Amount:</strong> <strong style={{ color: 'var(--teal-700)', fontSize: '0.95rem' }}>₹{(r.totalAmount || 2500).toLocaleString()}</strong></div>
                <div><strong>Pickup Status:</strong> {r.pickupStatus?.replace(/_/g, ' ') || 'Waiting'}</div>
              </div>

              {/* Commission Split Ledger Card if Captured */}
              {r.paymentStatus === 'captured' && (
                <div className="card mb-3" style={{ background: '#f8fafc', padding: '.75rem', border: '1px solid var(--border)' }}>
                  <div className="between text-xs">
                    <span><strong>Razorpay ID:</strong> <code>{r.razorpayPaymentId || 'pay_rzp_test_9921'}</code></span>
                    <span className="badge badge-success">✓ Cryptographic Signature Verified</span>
                  </div>
                  <div className="grid grid-3 mt-1 text-xs" style={{ borderTop: '1px solid var(--border)', paddingTop: '.5rem' }}>
                    <div>Gross Total: <strong>₹{(r.totalAmount || 2500).toLocaleString()}</strong></div>
                    <div style={{ color: '#6d28d9' }}>MediRent Fee (5%): <strong>₹{r.commissionAmount || 125}</strong></div>
                    <div style={{ color: 'var(--teal-700)' }}>Supplier Share (95%): <strong>₹{(r.supplierAmount || 2375).toLocaleString()}</strong></div>
                  </div>
                </div>
              )}

              <div className="between">
                <button className="btn btn-sm btn-outline" onClick={() => { setSelectedRental(r); setModalType('timeline'); }}>
                  7-Stage Lifecycle Trail →
                </button>

                <div className="row">
                  {r.paymentStatus !== 'captured' && (
                    <button className="btn btn-primary" onClick={() => { setSelectedRental(r); setModalType('payment'); }}>
                      💳 Pay ₹{(r.totalAmount || 2500).toLocaleString()} with Razorpay Test Mode →
                    </button>
                  )}
                  {r.paymentStatus === 'captured' && (!r.pickupDetails?.driver) && (
                    <button className="btn btn-sm btn-success" onClick={() => { setSelectedRental(r); setModalType('pickup'); }}>
                      🚚 Assign Driver & Vehicle
                    </button>
                  )}
                  {r.status === 'active' && (
                    <>
                      <button className="btn btn-sm btn-outline" onClick={() => { setSelectedRental(r); setModalType('extend'); }}>
                        🔄 Extend Rental
                      </button>
                      <button className="btn btn-sm btn-danger" onClick={() => { setSelectedRental(r); setModalType('return'); }}>
                        ↩️ Request Return
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Razorpay Test Mode Modal */}
      {modalType === 'payment' && selectedRental && (
        <div className="modal-overlay" onClick={() => setModalType(null)}>
          <div className="modal-content" style={{ maxWidth: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ background: '#0c2340', color: '#fff' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <div style={{ width: 28, height: 28, borderRadius: 6, background: '#3395ff', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700 }}>₹</div>
                <div>
                  <h3 style={{ margin: 0, color: '#fff', fontSize: '1.05rem' }}>Razorpay Test Gateway</h3>
                  <div className="text-xs" style={{ color: '#38bdf8' }}>MediRent Platform Checkout • Key: <code>rzp_test_medirent2026</code></div>
                </div>
              </div>
              <button className="btn btn-ghost btn-sm" style={{ color: '#fff' }} onClick={() => setModalType(null)}>✕</button>
            </div>

            <div className="modal-body">
              <div className="between" style={{ background: 'var(--slate-50)', padding: '1rem', borderRadius: 10, marginBottom: '1rem', border: '1px solid var(--border)' }}>
                <div>
                  <div className="text-xs text-muted uppercase font-bold">Payable Amount</div>
                  <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--slate-900)' }}>
                    ₹{(selectedRental.totalAmount || 2500).toLocaleString()}
                  </div>
                  <div className="text-xs text-muted">Includes 5% marketplace commission split</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span className="badge badge-primary">TEST MODE</span>
                  <div className="text-xs text-muted mt-1">{selectedRental.rentalCode || 'MR-1001'}</div>
                </div>
              </div>

              <div className="nav-tabs" style={{ marginBottom: '1rem' }}>
                <button className={`nav-tab ${paymentMethod === 'upi' ? 'active' : ''}`} onClick={() => setPaymentMethod('upi')}>
                  📱 UPI / QR
                </button>
                <button className={`nav-tab ${paymentMethod === 'card' ? 'active' : ''}`} onClick={() => setPaymentMethod('card')}>
                  💳 Card
                </button>
                <button className={`nav-tab ${paymentMethod === 'netbanking' ? 'active' : ''}`} onClick={() => setPaymentMethod('netbanking')}>
                  🏦 NetBanking
                </button>
              </div>

              {paymentMethod === 'upi' && (
                <div style={{ textAlign: 'center', padding: '1.25rem', border: '1px solid var(--border)', borderRadius: 10 }}>
                  <div style={{ fontSize: '2.5rem', marginBottom: '0.25rem' }}>📲</div>
                  <strong>Instant UPI Test Simulation</strong>
                  <p className="text-xs text-muted mt-1">Simulates instant webhook verification and automatic 5% platform commission calculation.</p>
                </div>
              )}

              {paymentMethod === 'card' && (
                <div>
                  <div className="form-group"><label>Test Card Number</label><input className="form-control" defaultValue="4111 2222 3333 4444" readOnly /></div>
                  <div className="form-row">
                    <div className="form-group"><label>Expiry</label><input className="form-control" defaultValue="12/28" readOnly /></div>
                    <div className="form-group"><label>CVV</label><input className="form-control" defaultValue="999" readOnly /></div>
                  </div>
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div className="form-group">
                  <label>Select Test Bank</label>
                  <select className="form-control"><option>HDFC Bank (Test)</option><option>ICICI Bank (Test)</option><option>SBI (Test)</option></select>
                </div>
              )}
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setModalType(null)}>Cancel</button>
              <button
                className="btn btn-primary"
                style={{ background: '#3395ff', borderColor: '#3395ff', width: '100%', justifyContent: 'center' }}
                onClick={() => handleRazorpayPayment(selectedRental)}
              >
                ✓ Pay ₹{(selectedRental.totalAmount || 2500).toLocaleString()} & Trigger Commission Split
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Success & Split Receipt Modal */}
      {paymentReceipt && (
        <div className="modal-overlay" onClick={() => setPaymentReceipt(null)}>
          <div className="modal-content" style={{ maxWidth: 540 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ background: '#ecfdf5', borderColor: '#a7f3d0' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#10b981', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700 }}>✓</div>
                <div>
                  <h3 style={{ margin: 0, color: '#065f46' }}>Payment Captured & Split Calculated!</h3>
                  <div className="text-xs text-muted">Razorpay Test ID: <code>{paymentReceipt.razorpayPaymentId}</code></div>
                </div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => setPaymentReceipt(null)}>✕</button>
            </div>

            <div className="modal-body">
              <div className="card mb-3" style={{ background: '#f8fafc', border: '1px solid var(--border)' }}>
                <div className="between mb-1">
                  <span className="text-xs text-muted uppercase font-bold">Gross Total Paid by Hospital:</span>
                  <strong style={{ fontSize: '1.2rem', color: 'var(--slate-900)' }}>₹{paymentReceipt.grossTotal.toLocaleString()}</strong>
                </div>
                <div className="text-xs text-muted">{paymentReceipt.equipmentName} ({paymentReceipt.rentalCode})</div>
              </div>

              <h4>⚡ Automatic Marketplace Split Breakdown</h4>
              <div className="grid grid-2 mt-2">
                <div className="card" style={{ background: '#f0fdfa', borderColor: '#ccfbf1' }}>
                  <div className="text-xs text-muted font-bold uppercase">1. MediRent Commission (5%)</div>
                  <div style={{ fontSize: '1.3rem', fontWeight: 700, color: 'var(--teal-600)', margin: '.25rem 0' }}>
                    ₹{paymentReceipt.commissionAmount.toLocaleString()}
                  </div>
                  <div className="text-xs text-muted">Retained platform governance fee</div>
                </div>

                <div className="card" style={{ background: '#fffaf0', borderColor: '#fed7aa' }}>
                  <div className="text-xs text-muted font-bold uppercase">2. Payable to Supplier (95%)</div>
                  <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#c2410c', margin: '.25rem 0' }}>
                    ₹{paymentReceipt.supplierPayable.toLocaleString()}
                  </div>
                  <div className="text-xs text-muted">Credited to {paymentReceipt.supplier}</div>
                </div>
              </div>

              <div className="card mt-3" style={{ background: '#f8fafc', border: '1px dashed var(--slate-300)' }}>
                <div className="text-xs">
                  <strong>Server Verification Log:</strong> HMAC-SHA256 signature verified against Razorpay secret. Status updated to <code>CAPTURED</code>. Payout entry queued for admin disbursement.
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setPaymentReceipt(null)}>Close</button>
              <button
                className="btn btn-success"
                onClick={() => {
                  const rId = paymentReceipt.rentalId;
                  setPaymentReceipt(null);
                  setSelectedRental(items.find((x) => x._id === rId));
                  setModalType('pickup');
                }}
              >
                🚚 Assign Pickup Driver →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Driver Assignment Modal */}
      {modalType === 'pickup' && selectedRental && (
        <div className="modal-overlay" onClick={() => setModalType(null)}>
          <div className="modal-content" style={{ maxWidth: 520 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🚚 Assign Hospital Pickup Driver</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setModalType(null)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Assign the driver and vehicle who will collect <strong>{selectedRental.equipment?.name || selectedRental.equipmentName}</strong> from the supplier.
              </p>
              <div className="form-group">
                <label>Driver Full Name *</label>
                <input className="form-control" value={driverForm.driver} onChange={(e) => setDriverForm({ ...driverForm, driver: e.target.value })} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Driver Phone Number *</label>
                  <input className="form-control" value={driverForm.phone} onChange={(e) => setDriverForm({ ...driverForm, phone: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label>Vehicle Plate Number *</label>
                  <input className="form-control" value={driverForm.vehicle} onChange={(e) => setDriverForm({ ...driverForm, vehicle: e.target.value })} required />
                </div>
              </div>
              <div className="form-group">
                <label>Vehicle Type</label>
                <input className="form-control" value={driverForm.vehicleType} onChange={(e) => setDriverForm({ ...driverForm, vehicleType: e.target.value })} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setModalType(null)}>Cancel</button>
              <button className="btn btn-success btn-sm" onClick={() => handleAssignDriver(selectedRental)}>
                Confirm Driver Details →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Timeline Modal */}
      {modalType === 'timeline' && selectedRental && (
        <div className="modal-overlay" onClick={() => setModalType(null)}>
          <div className="modal-content" style={{ maxWidth: 680 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h3 style={{ margin: 0 }}>Rental Lifecycle — {selectedRental.rentalCode || 'MR-1001'}</h3>
                <div className="text-xs text-muted">{selectedRental.equipment?.name || selectedRental.equipmentName}</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => setModalType(null)}>✕</button>
            </div>
            <div className="modal-body">
              <h4>7-Stage Transaction Lifecycle</h4>
              <div className="lifecycle-timeline mt-2">
                {[
                  { step: 'Rental Requested', date: '08 Sept, 09:00 AM', note: 'Hospital booked rental duration' },
                  { step: 'Supplier Approved', date: '08 Sept, 11:30 AM', note: 'MedEquip Solutions approved request' },
                  { step: 'Payment Captured (Razorpay Test Mode)', date: '08 Sept, 02:15 PM', note: 'Gross ₹2,500 split: ₹125 MediRent 5% Fee + ₹2,375 Supplier 95% Share' },
                  { step: 'Pickup Scheduled', date: '09 Sept, 10:00 AM', note: 'Driver Ravi Kumar (TN 01 AB 1234) assigned' },
                  { step: 'Handed Over', date: '10 Sept, 11:00 AM', note: 'Equipment handed over to driver' },
                  { step: 'Active Rental', date: '10 Sept, 11:30 AM', note: 'Device operational in City Care ICU' },
                ].map((t, idx) => (
                  <div key={idx} className="timeline-item">
                    <div className="timeline-marker done">✓</div>
                    <div className="timeline-body">
                      <div className="between">
                        <strong>{t.step}</strong>
                        <span className="text-xs text-muted">{t.date}</span>
                      </div>
                      {t.note && <div className="text-xs text-muted mt-1">{t.note}</div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setModalType(null)}>Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Extension Modal */}
      {modalType === 'extend' && selectedRental && (
        <div className="modal-overlay" onClick={() => setModalType(null)}>
          <div className="modal-content" style={{ maxWidth: 450 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🔄 Request Rental Extension</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setModalType(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Additional Rental Days</label>
                <input type="number" className="form-control" min="1" value={extensionDays} onChange={(e) => setExtensionDays(Number(e.target.value))} />
              </div>
              <div className="card" style={{ background: '#f0fdfa' }}>
                <div className="between text-sm">
                  <span>Additional Amount:</span>
                  <strong>₹{(extensionDays * (selectedRental.pricePerDay || 500)).toLocaleString()}</strong>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setModalType(null)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={() => handleRequestExtend(selectedRental)}>Submit Extension</button>
            </div>
          </div>
        </div>
      )}

      {/* Return Modal */}
      {modalType === 'return' && selectedRental && (
        <div className="modal-overlay" onClick={() => setModalType(null)}>
          <div className="modal-content" style={{ maxWidth: 480 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>↩️ Request Equipment Return</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setModalType(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Condition Notes / Physical Inspection</label>
                <textarea className="form-control" rows={3} placeholder="Describe returned condition, calibration state..." value={damageNotes} onChange={(e) => setDamageNotes(e.target.value)} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setModalType(null)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={() => handleRequestReturn(selectedRental)}>Confirm Return Request</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
