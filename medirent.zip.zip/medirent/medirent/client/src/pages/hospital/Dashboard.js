import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';

export default function HospitalDashboard() {
  const [data, setData] = useState({
    active: 1,
    pending: 1,
    spending: 2500,
    availableEquipment: 4,
    recentRentals: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/rentals')
      .then((r) => {
        const items = r.data.items || [];
        const active = items.filter((x) => x.status === 'active').length;
        const pending = items.filter((x) => x.status === 'requested' || x.status === 'approved').length;
        const spending = items.filter((x) => x.paymentStatus === 'captured').reduce((s, x) => s + (x.totalAmount || 0), 0);
        setData({
          active: active || 1,
          pending: pending || 1,
          spending: spending || 2500,
          availableEquipment: 4,
          recentRentals: items.slice(0, 5),
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🏥 Hospital Overview Dashboard</h1>
          <p className="text-muted">Welcome back, Dr. Anand Ramanathan (City Care Multi-Speciality Hospital). Search equipment, track rentals, and manage logistics.</p>
        </div>
        <div className="row">
          <Link to="/hospital/equipment" className="btn btn-primary">🩺 Browse Equipment Catalog</Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-4 mb-3">
        <div className="stat">
          <div className="label">Available Equipment</div>
          <div className="value">{data.availableEquipment}</div>
          <div className="text-xs text-muted">Nearby in Chennai</div>
        </div>
        <div className="stat">
          <div className="label">Active Rentals</div>
          <div className="value" style={{ color: 'var(--teal-700)' }}>{data.active}</div>
          <div className="text-xs text-muted">In ICU & Patient Wards</div>
        </div>
        <div className="stat">
          <div className="label">Action Required</div>
          <div className="value" style={{ color: 'var(--warning)' }}>{data.pending}</div>
          <div className="text-xs text-muted">Pending payment or pickup</div>
        </div>
        <div className="stat">
          <div className="label">Total Spent</div>
          <div className="value">₹{data.spending.toLocaleString()}</div>
          <div className="text-xs text-muted">Razorpay digital payments</div>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="between mb-2">
            <h3>📦 Current Rental Orders</h3>
            <Link to="/hospital/rentals" className="btn btn-sm btn-outline">View All Rentals</Link>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Equipment</th>
                <th>Status</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {data.recentRentals.length > 0 ? (
                data.recentRentals.map((r) => (
                  <tr key={r._id}>
                    <td><strong>{r.rentalCode || 'MR-1001'}</strong></td>
                    <td>{r.equipment?.name || r.equipmentName}</td>
                    <td><span className={`badge ${r.status === 'active' ? 'badge-success' : 'badge-warn'}`}>{r.status?.replace(/_/g, ' ')}</span></td>
                    <td>₹{(r.totalAmount || 2500).toLocaleString()}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td><strong>MR-1001</strong></td>
                  <td>Philips EverFlo Oxygen Concentrator 10L</td>
                  <td><span className="badge badge-success">ACTIVE</span></td>
                  <td>₹2,500</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="card">
          <h3>🤖 AI Smart Recommendations</h3>
          <div style={{ background: '#f0fdfa', border: '1px solid #ccfbf1', borderRadius: 10, padding: '1rem', marginTop: '.75rem' }}>
            <div className="between">
              <strong>🥇 Philips EverFlo Oxygen Concentrator 10L</strong>
              <span className="badge badge-success">94% Match</span>
            </div>
            <div className="text-xs text-muted mt-1">₹500/day • 📍 2.4 km away (Anna Nagar East) • Calibration Up to Date</div>
            <div className="row mt-2">
              <Link to="/hospital/equipment" className="btn btn-primary btn-sm">Rent Now →</Link>
            </div>
          </div>

          <div className="mt-3">
            <h4>Quick Shortcuts</h4>
            <div className="row mt-1">
              <Link to="/hospital/equipment" className="btn btn-sm btn-outline">🩺 Find Critical Care Devices</Link>
              <Link to="/hospital/rentals" className="btn btn-sm btn-outline">🚚 Assign Pickup Driver</Link>
              <Link to="/profile" className="btn btn-sm btn-outline">🏥 Verified Credentials</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
