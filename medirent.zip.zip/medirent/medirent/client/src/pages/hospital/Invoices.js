import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function HospitalInvoices() {
  const [items, setItems] = useState([]);
  const toast = useToast();
  const load = () => api.get('/invoices').then((r) => setItems(r.data.items));
  useEffect(() => { load(); }, []);
  const pay = async (id) => { await api.patch(`/invoices/${id}/pay`); toast.success('Marked as paid'); load(); };

  return (
    <div>
      <h1>Invoices</h1>
      <table className="table">
        <thead><tr><th>#</th><th>Amount</th><th>Due</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {items.map((i) => (
            <tr key={i._id}>
              <td><b>{i.number}</b></td>
              <td>₹{i.total?.toLocaleString()}</td>
              <td>{i.dueDate ? new Date(i.dueDate).toLocaleDateString() : '—'}</td>
              <td><span className={`badge ${i.status === 'paid' ? 'badge-success' : 'badge-warn'}`}>{i.status}</span></td>
              <td className="right">{i.status !== 'paid' && <button className="btn btn-sm btn-primary" onClick={() => pay(i._id)}>Mark paid</button>}</td>
            </tr>
          ))}
          {items.length === 0 && <tr><td colSpan="5" className="text-muted">No invoices yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
