import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function EquipmentDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const toast = useToast();
  const [eq, setEq] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [form, setForm] = useState({
    quantity: 1, startDate: '', endDate: '', emergency: false, notes: '',
  });
  const [rev, setRev] = useState({ rating: 5, comment: '' });
  const [busy, setBusy] = useState(false);

  const load = () => {
    api.get(`/equipment/${id}`).then((r) => setEq(r.data.item));
    api.get(`/reviews/equipment/${id}`).then((r) => setReviews(r.data.items));
  };
  useEffect(load, [id]);

  const rent = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post('/rentals', { equipment: id, ...form });
      toast.success('Rental request submitted');
      nav('/hospital/rentals');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setBusy(false); }
  };

  const submitReview = async (e) => {
    e.preventDefault();
    try {
      await api.post('/reviews', { equipment: id, ...rev });
      toast.success('Thanks for the review');
      setRev({ rating: 5, comment: '' });
      load();
    } catch (err) { toast.error('Failed'); }
  };

  if (!eq) return <div className="center-loader"><div className="spinner" /></div>;

  return (
    <div className="grid grid-2">
      <div>
        <div className="card">
          <div style={{ height: 260, background: 'linear-gradient(135deg, var(--teal-100), var(--slate-100))',
            borderRadius: 10, display: 'grid', placeItems: 'center', color: 'var(--teal-700)',
            fontSize: '3rem', fontWeight: 700, marginBottom: '1rem' }}>
            {eq.images?.[0] ? <img src={eq.images[0]} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 10 }} /> : eq.name[0]}
          </div>
          <div className="row mb-1">
            <span className={`badge ${eq.ownerType === 'hospital' ? 'badge-primary' : 'badge-info'}`}>
              {eq.ownerType === 'hospital' ? 'HEEN listing' : 'Supplier'}
            </span>
            <span className="badge">{eq.condition}</span>
            <span className="badge badge-success">{eq.available} available</span>
          </div>
          <h1 style={{ marginBottom: 4 }}>{eq.name}</h1>
          <div className="text-muted">{eq.category?.name} · {eq.location || '—'}</div>
          <p className="mt-2">{eq.description}</p>
          <div className="mt-2">
            <div className="text-xs text-muted">Provider</div>
            <div style={{ fontWeight: 600 }}>{eq.owner?.organizationName || eq.owner?.name}</div>
            <div className="text-sm text-muted">{eq.owner?.email} · {eq.owner?.phone}</div>
          </div>
          {eq.warranty && <div className="mt-2 text-sm"><b>Warranty:</b> {eq.warranty}</div>}
          {eq.maintenanceCertificate && <div className="text-sm"><b>Maintenance cert:</b> {eq.maintenanceCertificate}</div>}
        </div>

        <div className="card mt-2">
          <h3>Reviews · {eq.ratingAvg ? eq.ratingAvg.toFixed(1) : '—'} ({eq.ratingCount || 0})</h3>
          {reviews.map((r) => (
            <div key={r._id} className="mt-2" style={{ borderTop: '1px solid var(--border)', paddingTop: '.6rem' }}>
              <div className="between"><b>{r.user?.organizationName || r.user?.name}</b><span>{'★'.repeat(r.rating)}</span></div>
              <div className="text-sm text-muted">{r.comment}</div>
            </div>
          ))}
          <form onSubmit={submitReview} className="mt-3">
            <h4>Leave a review</h4>
            <div className="form-row">
              <div className="form-group">
                <label>Rating</label>
                <select className="form-control" value={rev.rating} onChange={(e) => setRev({ ...rev, rating: Number(e.target.value) })}>
                  {[5,4,3,2,1].map((n) => <option key={n} value={n}>{n} ★</option>)}
                </select>
              </div>
              <div className="form-group"><label>Comment</label>
                <input className="form-control" value={rev.comment} onChange={(e) => setRev({ ...rev, comment: e.target.value })} /></div>
            </div>
            <button className="btn btn-primary btn-sm">Submit review</button>
          </form>
        </div>
      </div>

      <div>
        <div className="card">
          <h3>Request Rental</h3>
          <div className="between mb-2">
            <span className="text-muted">Price</span>
            <span style={{ fontSize: '1.4rem', color: 'var(--teal-600)', fontWeight: 700 }}>
              ₹{eq.pricePerDay}<span className="text-xs text-muted"> /day</span>
            </span>
          </div>
          <form onSubmit={rent}>
            <div className="form-row">
              <div className="form-group"><label>Quantity</label>
                <input className="form-control" type="number" min="1" max={eq.available}
                  value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} /></div>
              <div className="form-group"><label>Emergency</label>
                <select className="form-control" value={form.emergency ? 'y' : 'n'}
                  onChange={(e) => setForm({ ...form, emergency: e.target.value === 'y' })}>
                  <option value="n">No</option><option value="y">Yes — urgent</option>
                </select></div>
            </div>
            <div className="form-row">
              <div className="form-group"><label>Start date</label>
                <input className="form-control" type="date" value={form.startDate}
                  onChange={(e) => setForm({ ...form, startDate: e.target.value })} required /></div>
              <div className="form-group"><label>End date</label>
                <input className="form-control" type="date" value={form.endDate}
                  onChange={(e) => setForm({ ...form, endDate: e.target.value })} required /></div>
            </div>
            <div className="form-group"><label>Notes</label>
              <textarea className="form-control" rows="3" value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            <button className="btn btn-primary" style={{ width: '100%' }} disabled={busy || eq.available < 1}>
              {busy ? <span className="spinner spinner-inline" /> : 'Submit rental request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
