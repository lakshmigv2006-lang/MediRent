import { useState } from 'react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({
    name: user?.name || '', phone: user?.phone || '', address: user?.address || '',
    city: user?.city || '', organizationName: user?.organizationName || '',
    licenseNumber: user?.licenseNumber || '',
  });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' });

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const setP = (k) => (e) => setPw({ ...pw, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    try {
      const { data } = await api.put('/auth/me', form);
      updateUser(data.user);
      toast.success('Profile updated');
    } catch (err) { toast.error('Failed to update'); }
  };
  const changePw = async (e) => {
    e.preventDefault();
    try {
      await api.put('/auth/change-password', pw);
      toast.success('Password changed');
      setPw({ currentPassword: '', newPassword: '' });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  return (
    <div>
      <h1>Profile</h1>
      <div className="grid grid-2">
        <form className="card" onSubmit={save}>
          <h3>Account details</h3>
          <div className="form-row">
            <div className="form-group"><label>Name</label><input className="form-control" value={form.name} onChange={set('name')} /></div>
            <div className="form-group"><label>Organization</label><input className="form-control" value={form.organizationName} onChange={set('organizationName')} /></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Phone</label><input className="form-control" value={form.phone} onChange={set('phone')} /></div>
            <div className="form-group"><label>City</label><input className="form-control" value={form.city} onChange={set('city')} /></div>
          </div>
          <div className="form-group"><label>Address</label><input className="form-control" value={form.address} onChange={set('address')} /></div>
          <div className="form-group"><label>License #</label><input className="form-control" value={form.licenseNumber} onChange={set('licenseNumber')} /></div>
          <button className="btn btn-primary">Save changes</button>
        </form>
        <form className="card" onSubmit={changePw}>
          <h3>Change password</h3>
          <div className="form-group"><label>Current password</label>
            <input className="form-control" type="password" value={pw.currentPassword} onChange={setP('currentPassword')} required /></div>
          <div className="form-group"><label>New password</label>
            <input className="form-control" type="password" value={pw.newPassword} onChange={setP('newPassword')} required minLength={6} /></div>
          <button className="btn btn-primary">Update password</button>
        </form>
      </div>
    </div>
  );
}
