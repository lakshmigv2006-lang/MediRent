import { useEffect, useState } from 'react';
import api from '../../services/api';

export default function Notifications() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api.get('/notifications').then((r) => setItems(r.data.items)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const markAll = async () => { await api.patch('/notifications/read-all'); load(); };
  const markOne = async (id) => { await api.patch(`/notifications/${id}/read`); load(); };

  return (
    <div>
      <div className="between mb-2">
        <h1>Notifications</h1>
        <button className="btn" onClick={markAll}>Mark all read</button>
      </div>
      {loading ? <div className="center-loader"><div className="spinner" /></div>
        : items.length === 0 ? <div className="card text-muted">You're all caught up.</div>
        : (
          <div className="grid" style={{ gap: '.6rem' }}>
            {items.map((n) => (
              <div key={n._id} className="card between" style={{ opacity: n.read ? .65 : 1 }}>
                <div>
                  <div style={{ fontWeight: 600 }}>{n.title || n.type}</div>
                  <div className="text-sm text-muted">{n.message}</div>
                  <div className="text-xs text-muted mt-1">{new Date(n.createdAt).toLocaleString()}</div>
                </div>
                <div className="row">
                  <span className={`badge ${n.read ? '' : 'badge-info'}`}>{n.read ? 'read' : 'new'}</span>
                  {!n.read && <button className="btn btn-sm" onClick={() => markOne(n._id)}>Mark read</button>}
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}
