import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';

export default function EquipmentBrowse() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    q: '', category: '', minPrice: '', maxPrice: '',
    condition: '', location: '', available: 'true', page: 1,
  });

  useEffect(() => { api.get('/categories').then((r) => setCategories(r.data.items)); }, []);

  useEffect(() => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== '' && v !== null));
    api.get('/equipment', { params }).then((r) => setData(r.data)).finally(() => setLoading(false));
  }, [filters]);

  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.value, page: 1 });

  return (
    <div>
      <h1>Browse Equipment</h1>
      <p className="text-muted mb-2">Search across suppliers and the HEEN hospital exchange.</p>

      <div className="card mb-2">
        <div className="grid grid-4">
          <div className="form-group" style={{ margin: 0 }}>
            <label>Search</label>
            <input className="form-control" placeholder="e.g. ventilator" value={filters.q} onChange={set('q')} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Category</label>
            <select className="form-control" value={filters.category} onChange={set('category')}>
              <option value="">All</option>
              {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Location</label>
            <input className="form-control" placeholder="City" value={filters.location} onChange={set('location')} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Condition</label>
            <select className="form-control" value={filters.condition} onChange={set('condition')}>
              <option value="">Any</option><option>new</option><option>excellent</option><option>good</option><option>fair</option>
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Min ₹/day</label>
            <input type="number" className="form-control" value={filters.minPrice} onChange={set('minPrice')} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Max ₹/day</label>
            <input type="number" className="form-control" value={filters.maxPrice} onChange={set('maxPrice')} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Availability</label>
            <select className="form-control" value={filters.available} onChange={set('available')}>
              <option value="true">Available only</option><option value="">All</option>
            </select>
          </div>
        </div>
      </div>

      {loading ? <div className="center-loader"><div className="spinner" /></div>
        : (
          <>
            <div className="grid grid-4">
              {data.items.map((e) => (
                <Link key={e._id} to={`/hospital/equipment/${e._id}`} className="eq-card" style={{ color: 'inherit', textDecoration: 'none' }}>
                  <div className="thumb">{e.images?.[0] ? <img src={e.images[0]} alt="" /> : (e.name?.[0] || '?')}</div>
                  <div className="body">
                    <div className="between mb-1">
                      <span className={`badge ${e.ownerType === 'hospital' ? 'badge-primary' : 'badge-info'}`}>
                        {e.ownerType === 'hospital' ? 'HEEN' : 'Supplier'}
                      </span>
                      <span className="badge">{e.condition}</span>
                    </div>
                    <div style={{ fontWeight: 600 }}>{e.name}</div>
                    <div className="meta">{e.category?.name} · {e.location || '—'}</div>
                    <div className="between mt-1">
                      <div className="price">₹{e.pricePerDay}<span className="text-xs text-muted"> /day</span></div>
                      <div className="text-xs text-muted">{e.available} available</div>
                    </div>
                  </div>
                </Link>
              ))}
              {data.items.length === 0 && <div className="card text-muted">No equipment matches your filters.</div>}
            </div>

            {data.pages > 1 && (
              <div className="pagination">
                {Array.from({ length: data.pages }).map((_, i) => (
                  <button key={i} className={filters.page === i + 1 ? 'active' : ''}
                    onClick={() => setFilters({ ...filters, page: i + 1 })}>{i + 1}</button>
                ))}
              </div>
            )}
          </>
        )}
    </div>
  );
}
