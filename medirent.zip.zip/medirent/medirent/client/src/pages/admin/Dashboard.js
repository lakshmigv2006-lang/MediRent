import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  const loadData = () => {
    setLoading(true);
    api.get('/admin/dashboard')
      .then((res) => setData(res.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load dashboard data'))
      .finally(() => setLoading(false));
  };

  useEffect(loadData, []);

  if (loading || !data) {
    return <div className="center-loader"><div className="spinner" /></div>;
  }

  const { counts, financials, monthly, mostRented, recentRentals, pendingVerificationUsers } = data;
  const maxRevenue = Math.max(1, ...(monthly || []).map((m) => m.revenue || 0));

  return (
    <div>
      {/* Top Header Banner */}
      <div className="between mb-3">
        <div>
          <h1 style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <span>Admin Executive Dashboard</span>
            <span className="badge badge-primary">Operations HQ</span>
          </h1>
          <p className="text-muted" style={{ margin: 0 }}>
            Marketplace trust, verification governance, rental monitoring, and revenue settlement.
          </p>
        </div>
        <div className="row">
          <Link to="/admin/verification" className="btn btn-primary btn-sm">
            🛡️ Verification Center ({counts.totalPendingVerification})
          </Link>
          <button className="btn btn-outline btn-sm" onClick={loadData}>
            🔄 Refresh
          </button>
        </div>
      </div>

      {/* Pending Action Banner if items pending */}
      {counts.totalPendingVerification > 0 && (
        <div style={{
          background: 'linear-gradient(135deg, #fffbeb, #fef3c7)',
          border: '1px solid #fde68a',
          borderRadius: 'var(--radius)',
          padding: '1rem 1.25rem',
          marginBottom: '1.5rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '0.75rem',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
            <span style={{ fontSize: '1.5rem' }}>⚠️</span>
            <div>
              <strong style={{ color: '#92400e', fontSize: '0.95rem' }}>
                {counts.totalPendingVerification} Verification Request(s) Pending Review
              </strong>
              <div className="text-xs text-muted" style={{ color: '#b45309' }}>
                {counts.pendingHospitals} Hospitals • {counts.pendingSuppliers} Suppliers • {counts.pendingEquipment} Equipment items awaiting verification
              </div>
            </div>
          </div>
          <Link to="/admin/verification" className="btn btn-sm btn-primary" style={{ background: '#d97706', borderColor: '#d97706' }}>
            Review Pending Queue →
          </Link>
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-4 mb-3">
        <div className="stat">
          <div className="between">
            <div className="label">Hospitals</div>
            <span className="badge badge-success">{counts.verifiedHospitals} Verified</span>
          </div>
          <div className="value">{counts.totalHospitals}</div>
          <div className="text-xs text-muted mt-1">
            {counts.pendingHospitals > 0 ? (
              <span style={{ color: 'var(--warning)', fontWeight: 600 }}>⚠️ {counts.pendingHospitals} pending verification</span>
            ) : (
              'All verified'
            )}
          </div>
        </div>

        <div className="stat">
          <div className="between">
            <div className="label">Suppliers</div>
            <span className="badge badge-success">{counts.verifiedSuppliers} Verified</span>
          </div>
          <div className="value">{counts.totalSuppliers}</div>
          <div className="text-xs text-muted mt-1">
            {counts.pendingSuppliers > 0 ? (
              <span style={{ color: 'var(--warning)', fontWeight: 600 }}>⚠️ {counts.pendingSuppliers} pending verification</span>
            ) : (
              'All verified'
            )}
          </div>
        </div>

        <div className="stat">
          <div className="between">
            <div className="label">Equipment Listed</div>
            <span className="badge badge-info">{counts.verifiedEquipment} Active</span>
          </div>
          <div className="value">{counts.totalEquipment}</div>
          <div className="text-xs text-muted mt-1">
            {counts.pendingEquipment > 0 ? (
              <span style={{ color: 'var(--warning)', fontWeight: 600 }}>⚠️ {counts.pendingEquipment} pending listing</span>
            ) : (
              'Marketplace synced'
            )}
          </div>
        </div>

        <div className="stat">
          <div className="between">
            <div className="label">Active Rentals</div>
            <span className="badge badge-primary">{counts.activeRentals} Live</span>
          </div>
          <div className="value">{counts.activeRentals}</div>
          <div className="text-xs text-muted mt-1">{counts.pendingRentals} pending approvals</div>
        </div>
      </div>

      {/* Financial KPIs Grid */}
      <div className="grid grid-3 mb-3">
        <div className="card" style={{ background: 'linear-gradient(135deg, #f0fdfa, #fff)', borderColor: '#ccfbf1' }}>
          <div className="text-xs text-muted" style={{ textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>
            Gross Platform Volume
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--teal-700)', marginTop: '0.35rem' }}>
            ₹{financials.totalRevenue.toLocaleString()}
          </div>
          <div className="text-xs text-muted mt-1">
            Captured via Razorpay Test Gateway
          </div>
        </div>

        <div className="card" style={{ background: 'linear-gradient(135deg, #f5f3ff, #fff)', borderColor: '#ddd6fe' }}>
          <div className="between">
            <div className="text-xs text-muted" style={{ textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>
              MediRent Platform Commission
            </div>
            <span className="badge badge-purple">{financials.commissionRate}% Rate</span>
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#6d28d9', marginTop: '0.35rem' }}>
            ₹{Math.round(financials.totalCommission).toLocaleString()}
          </div>
          <div className="text-xs text-muted mt-1">
            Retained marketplace earnings
          </div>
        </div>

        <div className="card" style={{ background: 'linear-gradient(135deg, #fff7ed, #fff)', borderColor: '#ffedd5' }}>
          <div className="text-xs text-muted" style={{ textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>
            Supplier Payable (Pending Settlement)
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: '#c2410c', marginTop: '0.35rem' }}>
            ₹{Math.round(financials.pendingSettlement).toLocaleString()}
          </div>
          <div className="text-xs text-muted mt-1">
            <Link to="/admin/commission" style={{ color: '#c2410c', fontWeight: 600 }}>
              Review Supplier Settlements →
            </Link>
          </div>
        </div>
      </div>

      {/* Analytics Charts & Pipeline */}
      <div className="grid grid-2 mb-3">
        <div className="card">
          <div className="between mb-2">
            <h3>📈 Monthly Transaction Volume</h3>
            <span className="text-xs text-muted">Last 6 months</span>
          </div>
          <div className="bars" style={{ height: 170 }}>
            {monthly && monthly.length > 0 ? (
              monthly.map((m, i) => {
                const height = Math.max(8, (m.revenue / maxRevenue) * 130);
                const monthName = MONTHS[(m._id.m - 1) % 12] || `M${m._id.m}`;
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div className="bar" style={{ height, width: '70%' }}>
                      <span>₹{Math.round(m.revenue).toLocaleString()}</span>
                    </div>
                    <div className="label">{monthName} '{String(m._id.y).slice(2)}</div>
                  </div>
                );
              })
            ) : (
              <div className="text-muted" style={{ alignSelf: 'center', margin: 'auto' }}>No revenue records yet.</div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="between mb-2">
            <h3>🩺 High-Demand Equipment</h3>
            <Link to="/admin/equipment" className="text-xs">View all</Link>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Equipment Name</th>
                <th>Category</th>
                <th>Price/Day</th>
                <th className="right">Rentals</th>
              </tr>
            </thead>
            <tbody>
              {mostRented && mostRented.length > 0 ? (
                mostRented.map((r, i) => (
                  <tr key={i}>
                    <td>
                      <strong>{r.equipment?.name || 'Equipment'}</strong>
                      <div className="text-xs text-muted">{r.equipment?.manufacturer || 'Medical Grade'}</div>
                    </td>
                    <td><span className="badge badge-info">{r.equipment?.condition || 'Good'}</span></td>
                    <td>₹{r.equipment?.pricePerDay || 0}/d</td>
                    <td className="right"><span className="badge badge-primary">{r.count} Bookings</span></td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-muted" style={{ textAlign: 'center', padding: '1.5rem' }}>
                    No rental demand records yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Marketplace Activity & Pending Registrations */}
      <div className="grid grid-2">
        <div className="card">
          <div className="between mb-2">
            <h3>📦 Recent Rental Transactions</h3>
            <Link to="/admin/rentals" className="text-xs">View all rentals →</Link>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Hospital</th>
                <th>Equipment</th>
                <th>Status</th>
                <th className="right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {recentRentals && recentRentals.length > 0 ? (
                recentRentals.map((r) => (
                  <tr key={r._id}>
                    <td><strong>{r.rentalCode || r._id.slice(-6).toUpperCase()}</strong></td>
                    <td>
                      <div>{r.renter?.organizationName || r.renter?.name}</div>
                      <div className="text-xs text-muted">{r.renter?.city || 'Chennai'}</div>
                    </td>
                    <td>{r.equipment?.name}</td>
                    <td>
                      <span className={`badge ${
                        r.status === 'active' ? 'badge-success' :
                        r.status === 'completed' ? 'badge-info' :
                        r.status === 'payment_pending' ? 'badge-warn' : 'badge-primary'
                      }`}>
                        {r.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="right"><strong>₹{r.totalAmount?.toLocaleString()}</strong></td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="text-muted" style={{ textAlign: 'center', padding: '1rem' }}>No recent rentals</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="card">
          <div className="between mb-2">
            <h3>🛡️ Pending Verification Queue</h3>
            <Link to="/admin/verification" className="text-xs">Open Verification Center →</Link>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Organization</th>
                <th>Role</th>
                <th>City</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              {pendingVerificationUsers && pendingVerificationUsers.length > 0 ? (
                pendingVerificationUsers.map((u) => (
                  <tr key={u._id}>
                    <td>
                      <strong>{u.organizationName || u.name}</strong>
                      <div className="text-xs text-muted">{u.email}</div>
                    </td>
                    <td>
                      <span className={`badge ${u.role === 'hospital' ? 'badge-info' : 'badge-purple'}`}>
                        {u.role}
                      </span>
                    </td>
                    <td>{u.city || '—'}</td>
                    <td className="right">
                      <Link to="/admin/verification" className="btn btn-sm btn-primary">
                        Review
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-muted" style={{ textAlign: 'center', padding: '1rem' }}>
                    ✅ All hospitals and suppliers are verified!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
