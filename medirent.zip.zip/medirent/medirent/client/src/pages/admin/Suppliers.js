import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminSuppliers() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [filters, setFilters] = useState({ verificationStatus: '', status: '', q: '', page: 1 });
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/admin/suppliers', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load suppliers'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  const handleApprove = async (id) => {
    try {
      await api.put(`/admin/suppliers/${id}/approve`);
      toast.success('Supplier verified and activated!');
      setSelectedSupplier(null);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Approval failed');
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Please enter a rejection reason');
      return;
    }
    try {
      await api.put(`/admin/suppliers/${selectedSupplier._id}/reject`, { reason: rejectReason });
      toast.success('Supplier application rejected');
      setShowRejectModal(false);
      setSelectedSupplier(null);
      setRejectReason('');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Rejection failed');
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🏭 Supplier Verification & Inventory Governance</h1>
          <p className="text-muted">Review, verify, and monitor equipment suppliers and authorized distributors.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Filters Bar */}
      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 280 }}
            placeholder="Search supplier, city, reg #…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 200 }}
            value={filters.verificationStatus}
            onChange={(e) => setFilters({ ...filters, verificationStatus: e.target.value, page: 1 })}
          >
            <option value="">All Verification Statuses</option>
            <option value="verified">Verified</option>
            <option value="pending">Pending Verification</option>
            <option value="rejected">Rejected</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 180 }}
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
          >
            <option value="">All Account Statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Business Name</th>
                <th>Reg / License #</th>
                <th>Business Type</th>
                <th>City / State</th>
                <th>Authorized Person</th>
                <th>Verification</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((s) => (
                <tr key={s._id}>
                  <td>
                    <strong>{s.organizationName || s.name}</strong>
                    <div className="text-xs text-muted">{s.email}</div>
                  </td>
                  <td><code>{s.registrationNumber || 'PENDING'}</code></td>
                  <td>{s.businessType || 'Equipment Dealer'}</td>
                  <td>
                    <div>{s.city}, {s.state}</div>
                    <div className="text-xs text-muted">{s.pincode}</div>
                  </td>
                  <td>
                    <div>{s.authorizedPerson || s.name}</div>
                    <div className="text-xs text-muted">{s.phone}</div>
                  </td>
                  <td>
                    <span className={`badge ${
                      s.verificationStatus === 'verified' ? 'badge-success' :
                      s.verificationStatus === 'rejected' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {s.verificationStatus === 'verified' ? '✓ VERIFIED' : s.verificationStatus?.toUpperCase() || 'PENDING'}
                    </span>
                  </td>
                  <td className="right">
                    <div className="row" style={{ justifyContent: 'flex-end' }}>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => setSelectedSupplier(s)}
                      >
                        Inspect Dossier
                      </button>
                      {s.verificationStatus !== 'verified' && (
                        <button
                          className="btn btn-sm btn-success"
                          onClick={() => handleApprove(s._id)}
                        >
                          Approve
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="7" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No suppliers found matching current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {/* Supplier Details Modal */}
      {selectedSupplier && !showRejectModal && (
        <div className="modal-overlay" onClick={() => setSelectedSupplier(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🏭 Supplier Business Profile & Verification Dossier</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedSupplier(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="card mb-3" style={{ background: 'var(--slate-50)' }}>
                <div className="between">
                  <div>
                    <h3 style={{ margin: 0 }}>{selectedSupplier.organizationName || selectedSupplier.name}</h3>
                    <div className="text-xs text-muted">Business Registration: {selectedSupplier.registrationNumber || 'N/A'}</div>
                  </div>
                  <span className={`badge ${selectedSupplier.verificationStatus === 'verified' ? 'badge-success' : 'badge-warn'}`}>
                    {selectedSupplier.verificationStatus?.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="grid grid-2 mb-3">
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Business Details</div>
                  <div>Type: {selectedSupplier.businessType || 'Distributor'}</div>
                  <div>Address: {selectedSupplier.address}</div>
                  <div>Location: {selectedSupplier.city}, {selectedSupplier.state} - {selectedSupplier.pincode}</div>
                  {selectedSupplier.googleMapsUrl && (
                    <div className="mt-1">
                      <a href={selectedSupplier.googleMapsUrl} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline">
                        📍 View on Google Maps / Directions
                      </a>
                    </div>
                  )}
                </div>
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Authorized Representative</div>
                  <div>{selectedSupplier.authorizedPerson || selectedSupplier.name}</div>
                  <div>Phone: {selectedSupplier.phone || '—'}</div>
                  <div>Email: {selectedSupplier.email}</div>
                  {selectedSupplier.verifiedAt && (
                    <div className="text-xs text-muted mt-1">
                      Verified Date: {new Date(selectedSupplier.verifiedAt).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>

              {selectedSupplier.rejectionReason && (
                <div className="card mb-3" style={{ background: '#fef2f2', borderColor: '#fee2e2' }}>
                  <div className="text-xs font-bold" style={{ color: 'var(--danger)' }}>Previous Rejection Reason:</div>
                  <p className="text-sm" style={{ color: '#991b1b', margin: 0 }}>{selectedSupplier.rejectionReason}</p>
                </div>
              )}

              <div>
                <h4>Uploaded Business, License & Authorization Documents</h4>
                {selectedSupplier.documents && selectedSupplier.documents.length > 0 ? (
                  <div className="doc-grid">
                    {selectedSupplier.documents.map((d, i) => (
                      <div key={i} className="doc-card">
                        <div className="doc-icon">PDF</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: '0.85rem', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                            {d.fileName}
                          </div>
                          <div className="text-xs text-muted">{d.documentType?.replace(/_/g, ' ')}</div>
                          <a href={d.fileUrl} target="_blank" rel="noreferrer" className="text-xs" style={{ color: 'var(--teal-600)', fontWeight: 600 }}>
                            👁️ Open & Verify Document
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-muted text-sm">No verification documents uploaded.</div>
                )}
              </div>
            </div>

            <div className="modal-footer">
              {selectedSupplier.verificationStatus !== 'rejected' && (
                <button className="btn btn-danger btn-sm" onClick={() => setShowRejectModal(true)}>
                  ✕ Reject
                </button>
              )}
              {selectedSupplier.verificationStatus !== 'verified' && (
                <button className="btn btn-success btn-sm" onClick={() => handleApprove(selectedSupplier._id)}>
                  ✓ Approve Supplier
                </button>
              )}
              <button className="btn btn-outline btn-sm" onClick={() => setSelectedSupplier(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rejection Modal */}
      {showRejectModal && selectedSupplier && (
        <div className="modal-overlay" onClick={() => setShowRejectModal(false)}>
          <div className="modal-content" style={{ maxWidth: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Reject Supplier Application</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Specify reason for rejecting <strong>{selectedSupplier.organizationName || selectedSupplier.name}</strong>:
              </p>
              <div className="form-group">
                <label>Rejection Reason *</label>
                <textarea
                  className="form-control"
                  rows={4}
                  placeholder="e.g. Manufacturer authorization certificate is invalid or dealership expired."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setShowRejectModal(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={handleReject} disabled={!rejectReason.trim()}>
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
