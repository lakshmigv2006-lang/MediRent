import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminReports() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  useEffect(() => {
    api.get('/admin/dashboard')
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load report analytics'))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return <div className="center-loader"><div className="spinner" /></div>;
  }

  const { counts, financials, monthly, mostRented } = data;

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>📈 Platform Analytics & Audit Reports</h1>
          <p className="text-muted">Marketplace volume performance, equipment utilization, and commission reports.</p>
        </div>
      </div>

      {/* Highlights */}
      <div className="grid grid-3 mb-3">
        <div className="stat">
          <div className="label">Total Platform Volume</div>
          <div className="value">₹{financials.totalRevenue.toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">{counts.activeRentals} Active rentals</div>
        </div>
        <div className="stat">
          <div className="label">MediRent Commission Retained</div>
          <div className="value" style={{ color: '#6d28d9' }}>₹{Math.round(financials.totalCommission).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">Platform operational fee</div>
        </div>
        <div className="stat">
          <div className="label">Verified Marketplace Entities</div>
          <div className="value">{counts.verifiedHospitals + counts.verifiedSuppliers}</div>
          <div className="text-xs text-muted mt-1">
            {counts.verifiedHospitals} Hospitals • {counts.verifiedSuppliers} Suppliers
          </div>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="between mb-2">
            <h3>Monthly Transaction Revenue Breakdown</h3>
            <span className="text-xs text-muted">Aggregated audit</span>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Month</th>
                <th>Rentals Count</th>
                <th>Gross Volume</th>
                <th>Commission (5%)</th>
              </tr>
            </thead>
            <tbody>
              {monthly && monthly.length > 0 ? (
                monthly.map((m, i) => (
                  <tr key={i}>
                    <td><strong>{m._id.m}/{m._id.y}</strong></td>
                    <td><span className="badge badge-info">{m.count} Bookings</span></td>
                    <td>₹{Math.round(m.revenue).toLocaleString()}</td>
                    <td style={{ color: '#6d28d9', fontWeight: 600 }}>₹{Math.round(m.commission || m.revenue * 0.05).toLocaleString()}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-muted" style={{ textAlign: 'center', padding: '1.5rem' }}>No monthly transactions logged.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="card">
          <div className="between mb-2">
            <h3>Equipment Demand & Utilization Index</h3>
            <span className="text-xs text-muted">Top booked items</span>
          </div>
          <table className="table">
            <thead>
              <tr>
                <th>Equipment Name</th>
                <th>Manufacturer</th>
                <th>Price/Day</th>
                <th className="right">Total Bookings</th>
              </tr>
            </thead>
            <tbody>
              {mostRented && mostRented.length > 0 ? (
                mostRented.map((r, i) => (
                  <tr key={i}>
                    <td><strong>{r.equipment?.name}</strong></td>
                    <td className="text-xs text-muted">{r.equipment?.manufacturer || 'Standard'}</td>
                    <td>₹{r.equipment?.pricePerDay || 0}</td>
                    <td className="right"><span className="badge badge-primary">{r.count} Bookings</span></td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-muted" style={{ textAlign: 'center', padding: '1.5rem' }}>No equipment rentals yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
