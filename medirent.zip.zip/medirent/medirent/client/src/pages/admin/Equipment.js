import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminEquipment() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({ verificationStatus: '', category: '', condition: '', q: '', page: 1 });
  const [selectedEq, setSelectedEq] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    api.get('/categories').then((r) => setCategories(r.data.categories || r.data || [])).catch(() => {});
  }, []);

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/admin/equipment', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load equipment'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  const handleApprove = async (id) => {
    try {
      await api.put(`/admin/equipment/${id}/approve`);
      toast.success('Equipment listing verified and published!');
      setSelectedEq(null);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Approval failed');
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Please enter a rejection reason');
      return;
    }
    try {
      await api.put(`/admin/equipment/${selectedEq._id}/reject`, { reason: rejectReason });
      toast.success('Equipment listing rejected');
      setShowRejectModal(false);
      setSelectedEq(null);
      setRejectReason('');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Rejection failed');
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🩺 Equipment Verification & Catalog</h1>
          <p className="text-muted">Review medical equipment specifications, calibration certificates, and public listing status.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Filter Bar */}
      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 260 }}
            placeholder="Search equipment, brand, model…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 190 }}
            value={filters.verificationStatus}
            onChange={(e) => setFilters({ ...filters, verificationStatus: e.target.value, page: 1 })}
          >
            <option value="">All Verification Statuses</option>
            <option value="verified">Verified (Live)</option>
            <option value="pending">Pending Verification</option>
            <option value="rejected">Rejected</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 190 }}
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value, page: 1 })}
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c._id} value={c._id}>{c.name}</option>
            ))}
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 160 }}
            value={filters.condition}
            onChange={(e) => setFilters({ ...filters, condition: e.target.value, page: 1 })}
          >
            <option value="">All Conditions</option>
            <option value="new">New</option>
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="fair">Fair</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Equipment Name</th>
                <th>Supplier / Owner</th>
                <th>Category</th>
                <th>Daily Rate</th>
                <th>Condition</th>
                <th>Maintenance</th>
                <th>Verification</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((eq) => (
                <tr key={eq._id}>
                  <td>
                    <strong>{eq.name}</strong>
                    <div className="text-xs text-muted">{eq.manufacturer || 'Medical Grade'} • {eq.model || 'Standard'}</div>
                  </td>
                  <td>
                    <div>{eq.owner?.organizationName || eq.owner?.name}</div>
                    <div className="text-xs text-muted">{eq.owner?.city}</div>
                  </td>
                  <td>{eq.category?.name || 'General'}</td>
                  <td><strong>₹{eq.pricePerDay}</strong>/day</td>
                  <td><span className="badge badge-info">{eq.condition}</span></td>
                  <td>
                    <span className={`badge ${eq.maintenanceStatus === 'up_to_date' ? 'badge-success' : 'badge-warn'}`}>
                      {eq.maintenanceStatus?.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${
                      eq.verificationStatus === 'verified' ? 'badge-success' :
                      eq.verificationStatus === 'rejected' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {eq.verificationStatus === 'verified' ? '✓ VERIFIED' : eq.verificationStatus?.toUpperCase() || 'PENDING'}
                    </span>
                  </td>
                  <td className="right">
                    <div className="row" style={{ justifyContent: 'flex-end' }}>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => setSelectedEq(eq)}
                      >
                        Inspect
                      </button>
                      {eq.verificationStatus !== 'verified' && (
                        <button
                          className="btn btn-sm btn-success"
                          onClick={() => handleApprove(eq._id)}
                        >
                          Approve
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="8" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No equipment listings found matching current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {/* Equipment Inspect Modal */}
      {selectedEq && !showRejectModal && (
        <div className="modal-overlay" onClick={() => setSelectedEq(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🩺 Equipment Verification Dossier</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedEq(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="card mb-3" style={{ background: 'var(--slate-50)' }}>
                <div className="between">
                  <div>
                    <h3 style={{ margin: 0 }}>{selectedEq.name}</h3>
                    <div className="text-xs text-muted">
                      Manufacturer: {selectedEq.manufacturer || 'N/A'} | Model: {selectedEq.model || 'N/A'} | SN: {selectedEq.serialNumber || 'N/A'}
                    </div>
                  </div>
                  <span className={`badge ${selectedEq.verificationStatus === 'verified' ? 'badge-success' : 'badge-warn'}`}>
                    {selectedEq.verificationStatus?.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="grid grid-2 mb-3">
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Pricing & Availability</div>
                  <div>Daily Rental: <strong>₹{selectedEq.pricePerDay}</strong></div>
                  <div>Security Deposit: ₹{selectedEq.securityDeposit || 0}</div>
                  <div>Stock Quantity: {selectedEq.quantity} units (Available: {selectedEq.available})</div>
                  <div>Condition: <span className="badge badge-info">{selectedEq.condition}</span></div>
                </div>
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Supplier & Location</div>
                  <div>{selectedEq.owner?.organizationName || selectedEq.owner?.name}</div>
                  <div>Location: {selectedEq.location || selectedEq.owner?.city || 'Chennai'}</div>
                  <div>Supplier Verification: <span className="badge badge-success">✓ Verified</span></div>
                  <div>
                    Maintenance Status: <span className="badge badge-success">{selectedEq.maintenanceStatus?.replace(/_/g, ' ')}</span>
                  </div>
                </div>
              </div>

              <div className="mb-3">
                <div className="text-xs text-muted font-bold uppercase">Description</div>
                <p className="text-sm">{selectedEq.description || 'No description entered'}</p>
              </div>

              {selectedEq.images && selectedEq.images.length > 0 && (
                <div className="mb-3">
                  <h4>Equipment Gallery</h4>
                  <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
                    {selectedEq.images.map((img, idx) => (
                      <img
                        key={idx}
                        src={img}
                        alt="Equipment preview"
                        style={{ width: 140, height: 100, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {selectedEq.rejectionReason && (
                <div className="card mb-3" style={{ background: '#fef2f2', borderColor: '#fee2e2' }}>
                  <div className="text-xs font-bold" style={{ color: 'var(--danger)' }}>Rejection Reason:</div>
                  <p className="text-sm" style={{ color: '#991b1b', margin: 0 }}>{selectedEq.rejectionReason}</p>
                </div>
              )}

              {selectedEq.documents && selectedEq.documents.length > 0 && (
                <div>
                  <h4>Compliance & Calibration Certificates</h4>
                  <div className="doc-grid">
                    {selectedEq.documents.map((doc, idx) => (
                      <div key={idx} className="doc-card">
                        <div className="doc-icon">PDF</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: '0.85rem', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                            {doc.fileName}
                          </div>
                          <a href={doc.fileUrl} target="_blank" rel="noreferrer" className="text-xs" style={{ color: 'var(--teal-600)', fontWeight: 600 }}>
                            👁️ View Certificate
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="modal-footer">
              {selectedEq.verificationStatus !== 'rejected' && (
                <button className="btn btn-danger btn-sm" onClick={() => setShowRejectModal(true)}>
                  ✕ Reject Listing
                </button>
              )}
              {selectedEq.verificationStatus !== 'verified' && (
                <button className="btn btn-success btn-sm" onClick={() => handleApprove(selectedEq._id)}>
                  ✓ Approve & Publish
                </button>
              )}
              <button className="btn btn-outline btn-sm" onClick={() => setSelectedEq(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && selectedEq && (
        <div className="modal-overlay" onClick={() => setShowRejectModal(false)}>
          <div className="modal-content" style={{ maxWidth: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Reject Equipment Listing</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Specify reason for rejecting <strong>{selectedEq.name}</strong>:
              </p>
              <div className="form-group">
                <label>Rejection Reason *</label>
                <textarea
                  className="form-control"
                  rows={4}
                  placeholder="e.g. Calibration certificate is outdated or serial number is illegible."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setShowRejectModal(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={handleReject} disabled={!rejectReason.trim()}>
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
