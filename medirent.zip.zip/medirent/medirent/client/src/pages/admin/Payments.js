import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminPayments() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1, summary: {} });
  const [filters, setFilters] = useState({ paymentStatus: '', settlementStatus: '', q: '', page: 1 });
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/admin/payments', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load payments'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  const toggleSettle = async (id, currentStatus) => {
    const nextStatus = currentStatus === 'settled' ? 'pending' : 'settled';
    try {
      await api.patch(`/admin/payments/${id}/settle`, { settlementStatus: nextStatus });
      toast.success(`Settlement status updated to ${nextStatus.toUpperCase()}`);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Failed to update settlement status');
    }
  };

  const { summary } = data;

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>💳 Payment Monitoring & Settlement Engine</h1>
          <p className="text-muted">
            Track server-side Razorpay test captures, platform commission calculation, and supplier settlement splits.
          </p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Visual Marketplace Payment Architecture Box (Section 63 of Master Prompt) */}
      <div className="payment-split-box">
        <div className="between">
          <strong style={{ color: 'var(--teal-700)', fontSize: '1rem' }}>
            ⚡ MediRent Marketplace Split & Settlement Model
          </strong>
          <span className="badge badge-primary">Razorpay Test Gateway Mode</span>
        </div>
        <div className="split-flow">
          <div className="split-card">
            <div className="text-xs text-muted font-bold uppercase">1. Hospital Payment</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--slate-900)', marginTop: '0.25rem' }}>
              ₹2,500
            </div>
            <div className="text-xs text-muted">Paid digitally via Razorpay</div>
          </div>

          <div style={{ fontSize: '1.5rem', color: 'var(--teal-500)', fontWeight: 700 }}>➔</div>

          <div className="split-card" style={{ borderColor: 'var(--teal-300)', background: '#f0fdfa' }}>
            <div className="text-xs text-muted font-bold uppercase">2. MediRent Commission (5%)</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--teal-600)', marginTop: '0.25rem' }}>
              ₹125
            </div>
            <div className="text-xs text-muted">Retained platform governance fee</div>
          </div>

          <div style={{ fontSize: '1.5rem', color: 'var(--teal-500)', fontWeight: 700 }}>+</div>

          <div className="split-card" style={{ borderColor: '#fed7aa', background: '#fffaf0' }}>
            <div className="text-xs text-muted font-bold uppercase">3. Supplier Payable (95%)</div>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#c2410c', marginTop: '0.25rem' }}>
              ₹2,375
            </div>
            <div className="text-xs text-muted">Settled via marketplace payout</div>
          </div>
        </div>
        <div className="text-xs text-muted mt-2" style={{ textAlign: 'center' }}>
          ℹ️ <em>Production settlement is handled through marketplace payment infrastructure. Razorpay Test Mode demonstrates server-side payment capture and signature verification.</em>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-4 mb-3">
        <div className="stat">
          <div className="label">Total Gross Captured</div>
          <div className="value">₹{(summary.totalGross || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">{summary.capturedCount || 0} Successful transactions</div>
        </div>
        <div className="stat">
          <div className="label">MediRent Commission (5%)</div>
          <div className="value" style={{ color: '#6d28d9' }}>₹{Math.round(summary.totalCommission || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">Net platform revenue</div>
        </div>
        <div className="stat">
          <div className="label">Supplier Net Share</div>
          <div className="value" style={{ color: '#c2410c' }}>₹{Math.round(summary.totalSupplierShare || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">95% split to equipment owners</div>
        </div>
        <div className="stat">
          <div className="label">Gateway Mode</div>
          <div className="value" style={{ fontSize: '1.4rem', color: 'var(--teal-600)' }}>Razorpay Test</div>
          <div className="text-xs text-muted mt-1">Server signature verified</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 280 }}
            placeholder="Search Rental ID, Order ID, Payment ID…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 190 }}
            value={filters.paymentStatus}
            onChange={(e) => setFilters({ ...filters, paymentStatus: e.target.value, page: 1 })}
          >
            <option value="">All Payment Statuses</option>
            <option value="captured">Captured</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 190 }}
            value={filters.settlementStatus}
            onChange={(e) => setFilters({ ...filters, settlementStatus: e.target.value, page: 1 })}
          >
            <option value="">All Settlements</option>
            <option value="pending">Pending Settlement</option>
            <option value="settled">Settled</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Rental ID</th>
                <th>Hospital (Payer)</th>
                <th>Supplier (Payee)</th>
                <th>Total Amount</th>
                <th>Commission (5%)</th>
                <th>Supplier Share</th>
                <th>Razorpay IDs</th>
                <th>Payment Status</th>
                <th>Settlement</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((r) => (
                <tr key={r._id}>
                  <td><strong>{r.rentalCode || r._id.slice(-6).toUpperCase()}</strong></td>
                  <td>
                    <div>{r.renter?.organizationName || r.renter?.name}</div>
                    <div className="text-xs text-muted">{r.renter?.email}</div>
                  </td>
                  <td>
                    <div>{r.owner?.organizationName || r.owner?.name}</div>
                    <div className="text-xs text-muted">{r.owner?.email}</div>
                  </td>
                  <td><strong>₹{r.totalAmount?.toLocaleString()}</strong></td>
                  <td style={{ color: '#6d28d9', fontWeight: 600 }}>₹{Math.round(r.commissionAmount || 0).toLocaleString()}</td>
                  <td style={{ color: '#c2410c', fontWeight: 600 }}>₹{Math.round(r.supplierAmount || 0).toLocaleString()}</td>
                  <td>
                    <div className="text-xs"><code>{r.razorpayOrderId || 'rzp_order_mock'}</code></div>
                    <div className="text-xs text-muted"><code>{r.razorpayPaymentId || 'rzp_pay_mock'}</code></div>
                  </td>
                  <td>
                    <span className={`badge ${r.paymentStatus === 'captured' ? 'badge-success' : 'badge-warn'}`}>
                      {r.paymentStatus === 'captured' ? '✓ CAPTURED' : r.paymentStatus?.toUpperCase() || 'PENDING'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${r.settlementStatus === 'settled' ? 'badge-success' : 'badge-warn'}`}>
                      {r.settlementStatus === 'settled' ? 'SETTLED' : 'PENDING'}
                    </span>
                  </td>
                  <td className="right">
                    <button
                      className={`btn btn-sm ${r.settlementStatus === 'settled' ? 'btn-outline' : 'btn-primary'}`}
                      onClick={() => toggleSettle(r._id, r.settlementStatus)}
                    >
                      {r.settlementStatus === 'settled' ? 'Undo Settle' : 'Mark Settled'}
                    </button>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="10" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No payment records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
