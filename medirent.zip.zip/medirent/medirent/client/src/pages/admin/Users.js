import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminUsers() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [filters, setFilters] = useState({ role: '', status: '', q: '', page: 1 });
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/users', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load users'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  const setStatus = async (id, status) => {
    try {
      await api.patch(`/users/${id}/status`, { status });
      toast.success(`User status updated to ${status}`);
      load();
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Are you sure you want to permanently delete this user?')) return;
    try {
      await api.delete(`/users/${id}`);
      toast.success('User deleted');
      load();
    } catch (e) {
      toast.error('Failed to delete user');
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>👥 System Users & Role Governance</h1>
          <p className="text-muted">Manage user roles, access statuses, and account authorizations.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 280 }}
            placeholder="Search name, email, organization…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 180 }}
            value={filters.role}
            onChange={(e) => setFilters({ ...filters, role: e.target.value, page: 1 })}
          >
            <option value="">All Roles</option>
            <option value="hospital">Hospital</option>
            <option value="supplier">Supplier</option>
            <option value="admin">Admin</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 180 }}
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
          >
            <option value="">All Statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>User Name</th>
                <th>Email Address</th>
                <th>System Role</th>
                <th>Organization</th>
                <th>Account Status</th>
                <th>Verification</th>
                <th className="right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((u) => (
                <tr key={u._id}>
                  <td><strong>{u.name}</strong></td>
                  <td>{u.email}</td>
                  <td>
                    <span className={`badge ${
                      u.role === 'admin' ? 'badge-primary' :
                      u.role === 'hospital' ? 'badge-info' : 'badge-purple'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td>{u.organizationName || '—'}</td>
                  <td>
                    <span className={`badge ${
                      u.status === 'active' ? 'badge-success' :
                      u.status === 'suspended' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {u.status}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${
                      u.verificationStatus === 'verified' ? 'badge-success' :
                      u.verificationStatus === 'rejected' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {u.verificationStatus || 'PENDING'}
                    </span>
                  </td>
                  <td className="right">
                    <div className="row" style={{ justifyContent: 'flex-end' }}>
                      {u.status !== 'active' && (
                        <button className="btn btn-sm btn-primary" onClick={() => setStatus(u._id, 'active')}>
                          Activate
                        </button>
                      )}
                      {u.status !== 'suspended' && (
                        <button className="btn btn-sm btn-outline" onClick={() => setStatus(u._id, 'suspended')}>
                          Suspend
                        </button>
                      )}
                      {u.role !== 'admin' && (
                        <button className="btn btn-sm btn-danger" onClick={() => remove(u._id)}>
                          Delete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="7" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No users matching criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
