import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminCategories() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', description: '' });
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/categories')
      .then((r) => setItems(r.data.items || r.data.categories || r.data || []))
      .catch(() => toast.error('Failed to load categories'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const create = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    try {
      await api.post('/categories', form);
      setForm({ name: '', description: '' });
      load();
      toast.success('Category created successfully');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to create category');
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Are you sure you want to delete this category?')) return;
    try {
      await api.delete(`/categories/${id}`);
      toast.success('Category removed');
      load();
    } catch (err) {
      toast.error('Failed to delete category');
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🗂️ Equipment Categories Management</h1>
          <p className="text-muted">Manage taxonomy and categorization for medical equipment discovery.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      <div className="grid grid-2">
        <form className="card" onSubmit={create} style={{ height: 'fit-content' }}>
          <h3>Add New Medical Category</h3>
          <div className="form-group">
            <label>Category Name *</label>
            <input
              className="form-control"
              placeholder="e.g. Respiratory Support, ICU & Critical Care"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Description & Scope</label>
            <input
              className="form-control"
              placeholder="e.g. Oxygen concentrators, CPAP/BiPAP, ventilators"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            + Create Category
          </button>
        </form>

        <div className="card">
          <div className="between mb-2">
            <h3>Existing Categories</h3>
            <span className="text-xs text-muted">{items.length} Total categories</span>
          </div>
          {loading ? (
            <div className="center-loader"><div className="spinner" /></div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Category Name</th>
                  <th>Description</th>
                  <th className="right">Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((c) => (
                  <tr key={c._id}>
                    <td><strong>{c.name}</strong></td>
                    <td className="text-sm text-muted">{c.description || '—'}</td>
                    <td className="right">
                      <button className="btn btn-sm btn-danger" onClick={() => remove(c._id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan="3" className="text-muted" style={{ textAlign: 'center', padding: '1.5rem' }}>
                      No categories registered yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
