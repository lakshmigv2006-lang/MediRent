import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminHospitals() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [filters, setFilters] = useState({ verificationStatus: '', status: '', q: '', page: 1 });
  const [selectedHospital, setSelectedHospital] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/admin/hospitals', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load hospitals'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  const handleApprove = async (id) => {
    try {
      await api.put(`/admin/hospitals/${id}/approve`);
      toast.success('Hospital verified successfully!');
      setSelectedHospital(null);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Approval failed');
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Please enter a rejection reason');
      return;
    }
    try {
      await api.put(`/admin/hospitals/${selectedHospital._id}/reject`, { reason: rejectReason });
      toast.success('Hospital registration rejected');
      setShowRejectModal(false);
      setSelectedHospital(null);
      setRejectReason('');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Rejection failed');
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🏥 Hospital Verification & Governance</h1>
          <p className="text-muted">Review, verify, and manage hospital accounts across the rental marketplace.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Filters Bar */}
      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 280 }}
            placeholder="Search hospital, city, reg #…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 200 }}
            value={filters.verificationStatus}
            onChange={(e) => setFilters({ ...filters, verificationStatus: e.target.value, page: 1 })}
          >
            <option value="">All Verification Statuses</option>
            <option value="verified">Verified</option>
            <option value="pending">Pending Verification</option>
            <option value="rejected">Rejected</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 180 }}
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
          >
            <option value="">All Account Statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Hospital Name</th>
                <th>Reg Number</th>
                <th>City / State</th>
                <th>Contact</th>
                <th>Verification</th>
                <th>Account</th>
                <th className="right">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((h) => (
                <tr key={h._id}>
                  <td>
                    <strong>{h.organizationName || h.name}</strong>
                    <div className="text-xs text-muted">{h.hospitalType || 'Multi-Specialty'}</div>
                  </td>
                  <td><code>{h.registrationNumber || 'PENDING'}</code></td>
                  <td>
                    <div>{h.city}, {h.state}</div>
                    <div className="text-xs text-muted">{h.pincode}</div>
                  </td>
                  <td>
                    <div>{h.contactPerson || h.name}</div>
                    <div className="text-xs text-muted">{h.phone}</div>
                  </td>
                  <td>
                    <span className={`badge ${
                      h.verificationStatus === 'verified' ? 'badge-success' :
                      h.verificationStatus === 'rejected' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {h.verificationStatus === 'verified' ? '✓ VERIFIED' : h.verificationStatus?.toUpperCase() || 'PENDING'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${h.status === 'active' ? 'badge-info' : 'badge-warn'}`}>
                      {h.status}
                    </span>
                  </td>
                  <td className="right">
                    <div className="row" style={{ justifyContent: 'flex-end' }}>
                      <button
                        className="btn btn-sm btn-outline"
                        onClick={() => setSelectedHospital(h)}
                      >
                        Inspect Dossier
                      </button>
                      {h.verificationStatus !== 'verified' && (
                        <button
                          className="btn btn-sm btn-success"
                          onClick={() => handleApprove(h._id)}
                        >
                          Approve
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="7" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No hospitals found matching current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {/* Hospital Details Modal */}
      {selectedHospital && !showRejectModal && (
        <div className="modal-overlay" onClick={() => setSelectedHospital(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🏥 Hospital Profile & Verification Dossier</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedHospital(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="card mb-3" style={{ background: 'var(--slate-50)' }}>
                <div className="between">
                  <div>
                    <h3 style={{ margin: 0 }}>{selectedHospital.organizationName || selectedHospital.name}</h3>
                    <div className="text-xs text-muted">Registration Number: {selectedHospital.registrationNumber || 'N/A'}</div>
                  </div>
                  <span className={`badge ${selectedHospital.verificationStatus === 'verified' ? 'badge-success' : 'badge-warn'}`}>
                    {selectedHospital.verificationStatus?.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="grid grid-2 mb-3">
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Hospital Details</div>
                  <div>Type: {selectedHospital.hospitalType || 'Tertiary Care'}</div>
                  <div>Address: {selectedHospital.address}</div>
                  <div>Location: {selectedHospital.city}, {selectedHospital.state} - {selectedHospital.pincode}</div>
                  {selectedHospital.googleMapsUrl && (
                    <div className="mt-1">
                      <a href={selectedHospital.googleMapsUrl} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline">
                        📍 View on Google Maps / Directions
                      </a>
                    </div>
                  )}
                </div>
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Authorized Representative</div>
                  <div>{selectedHospital.contactPerson || selectedHospital.name}</div>
                  <div>Phone: {selectedHospital.phone || '—'}</div>
                  <div>Email: {selectedHospital.email}</div>
                  {selectedHospital.verifiedAt && (
                    <div className="text-xs text-muted mt-1">
                      Verified Date: {new Date(selectedHospital.verifiedAt).toLocaleDateString()}
                    </div>
                  )}
                </div>
              </div>

              {selectedHospital.rejectionReason && (
                <div className="card mb-3" style={{ background: '#fef2f2', borderColor: '#fee2e2' }}>
                  <div className="text-xs font-bold" style={{ color: 'var(--danger)' }}>Previous Rejection Reason:</div>
                  <p className="text-sm" style={{ color: '#991b1b', margin: 0 }}>{selectedHospital.rejectionReason}</p>
                </div>
              )}

              <div>
                <h4>Uploaded Legal & Regulatory Documents</h4>
                {selectedHospital.documents && selectedHospital.documents.length > 0 ? (
                  <div className="doc-grid">
                    {selectedHospital.documents.map((d, i) => (
                      <div key={i} className="doc-card">
                        <div className="doc-icon">PDF</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: '0.85rem', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                            {d.fileName}
                          </div>
                          <div className="text-xs text-muted">{d.documentType?.replace(/_/g, ' ')}</div>
                          <a href={d.fileUrl} target="_blank" rel="noreferrer" className="text-xs" style={{ color: 'var(--teal-600)', fontWeight: 600 }}>
                            👁️ Open & Verify Document
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-muted text-sm">No regulatory certificates uploaded.</div>
                )}
              </div>
            </div>

            <div className="modal-footer">
              {selectedHospital.verificationStatus !== 'rejected' && (
                <button className="btn btn-danger btn-sm" onClick={() => setShowRejectModal(true)}>
                  ✕ Reject
                </button>
              )}
              {selectedHospital.verificationStatus !== 'verified' && (
                <button className="btn btn-success btn-sm" onClick={() => handleApprove(selectedHospital._id)}>
                  ✓ Approve Hospital
                </button>
              )}
              <button className="btn btn-outline btn-sm" onClick={() => setSelectedHospital(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rejection Modal */}
      {showRejectModal && selectedHospital && (
        <div className="modal-overlay" onClick={() => setShowRejectModal(false)}>
          <div className="modal-content" style={{ maxWidth: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Reject Hospital Application</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Specify rejection reason for <strong>{selectedHospital.organizationName || selectedHospital.name}</strong>:
              </p>
              <div className="form-group">
                <label>Rejection Reason *</label>
                <textarea
                  className="form-control"
                  rows={4}
                  placeholder="e.g. State medical council registration is unverified or expired."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setShowRejectModal(false)}>Cancel</button>
              <button className="btn btn-danger btn-sm" onClick={handleReject} disabled={!rejectReason.trim()}>
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
