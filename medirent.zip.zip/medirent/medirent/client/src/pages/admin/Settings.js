import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminSettings() {
  const [settings, setSettings] = useState({
    commissionRate: 5.0,
    platformName: 'MediRent',
    tagline: 'Verified. Reliable. Accessible.',
    supportEmail: 'support@medirent.io',
    supportPhone: '+91 98765 43210',
    razorpayKeyId: 'rzp_test_medirent2026',
    razorpayTestMode: true,
    autoVerifyEquipment: false,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/admin/settings')
      .then((r) => {
        if (r.data.settings) setSettings(r.data.settings);
      })
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load platform settings'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.put('/admin/settings', settings);
      toast.success('Platform settings updated successfully!');
      load();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="center-loader"><div className="spinner" /></div>;
  }

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>⚙️ Platform Settings & Configuration</h1>
          <p className="text-muted">Configure marketplace commission rates, payment gateway rules, and platform governance parameters.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      <form onSubmit={handleSave} style={{ maxWidth: 800 }}>
        {/* Marketplace Commission Rule */}
        <div className="card mb-3">
          <div className="card-header">
            <h3>💰 Marketplace Commission Settings</h3>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Default Platform Commission Percentage (%)</label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="50"
                  className="form-control"
                  value={settings.commissionRate}
                  onChange={(e) => setSettings({ ...settings, commissionRate: Number(e.target.value) })}
                  required
                />
                <span style={{ fontWeight: 700 }}>%</span>
              </div>
              <div className="text-xs text-muted mt-1">
                Default: 5%. Calculated dynamically during rental order creation.
              </div>
            </div>

            <div className="form-group">
              <label>Auto-Verify Equipment Listings</label>
              <select
                className="form-control"
                value={settings.autoVerifyEquipment ? 'true' : 'false'}
                onChange={(e) => setSettings({ ...settings, autoVerifyEquipment: e.target.value === 'true' })}
              >
                <option value="false">Manual Review Required (Recommended)</option>
                <option value="true">Auto-Approve from Verified Suppliers</option>
              </select>
            </div>
          </div>
        </div>

        {/* Payment Gateway & Razorpay Settings */}
        <div className="card mb-3">
          <div className="card-header">
            <h3>💳 Payment Gateway & Razorpay Test Integration</h3>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Razorpay Key ID (Test Mode)</label>
              <input
                className="form-control"
                value={settings.razorpayKeyId || ''}
                onChange={(e) => setSettings({ ...settings, razorpayKeyId: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Payment Gateway Mode</label>
              <select
                className="form-control"
                value={settings.razorpayTestMode ? 'true' : 'false'}
                onChange={(e) => setSettings({ ...settings, razorpayTestMode: e.target.value === 'true' })}
              >
                <option value="true">Test Mode (Mock Order & Signature Verification)</option>
                <option value="false">Live Production Mode</option>
              </select>
            </div>
          </div>
          <div className="text-xs text-muted">
            ℹ️ Payments are verified server-side with cryptographic signature checking before activating rentals.
          </div>
        </div>

        {/* Support & Brand Details */}
        <div className="card mb-3">
          <div className="card-header">
            <h3>🏢 Platform Branding & Support Contacts</h3>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Platform Name</label>
              <input
                className="form-control"
                value={settings.platformName || ''}
                onChange={(e) => setSettings({ ...settings, platformName: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Platform Tagline</label>
              <input
                className="form-control"
                value={settings.tagline || ''}
                onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Support Email Address</label>
              <input
                type="email"
                className="form-control"
                value={settings.supportEmail || ''}
                onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Emergency Support Helpline</label>
              <input
                className="form-control"
                value={settings.supportPhone || ''}
                onChange={(e) => setSettings({ ...settings, supportPhone: e.target.value })}
              />
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="between">
          <span className="text-xs text-muted">All changes apply in real-time across the marketplace.</span>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving Changes…' : '💾 Save Platform Settings'}
          </button>
        </div>
      </form>
    </div>
  );
}
