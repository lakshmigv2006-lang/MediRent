import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminCommission() {
  const [data, setData] = useState({ summary: {}, supplierBreakdown: [] });
  const [loading, setLoading] = useState(true);
  const [commissionRate, setCommissionRate] = useState(5.0);
  const [savingRate, setSavingRate] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/admin/commission')
      .then((r) => {
        setData(r.data);
        if (r.data.summary?.commissionRate !== undefined) {
          setCommissionRate(r.data.summary.commissionRate);
        }
      })
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load commission data'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleSaveRate = async () => {
    setSavingRate(true);
    try {
      await api.put('/admin/settings', { commissionRate: Number(commissionRate) });
      toast.success(`Platform commission rate updated to ${commissionRate}%`);
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Failed to update commission rate');
    } finally {
      setSavingRate(false);
    }
  };

  const { summary, supplierBreakdown } = data;

  if (loading) {
    return <div className="center-loader"><div className="spinner" /></div>;
  }

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>💰 Commission & Supplier Payout Settlement</h1>
          <p className="text-muted">Manage marketplace commission rules, supplier payout balances, and disbursement settlements.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-4 mb-3">
        <div className="stat">
          <div className="label">Total Transaction Value</div>
          <div className="value">₹{(summary.totalGross || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">{summary.transactionCount || 0} Paid transactions</div>
        </div>

        <div className="stat">
          <div className="label">MediRent Commission Earned</div>
          <div className="value" style={{ color: '#6d28d9' }}>₹{Math.round(summary.totalCommission || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">{summary.commissionRate || 5}% Platform revenue cut</div>
        </div>

        <div className="stat">
          <div className="label">Total Supplier Share</div>
          <div className="value" style={{ color: 'var(--teal-700)' }}>₹{Math.round(summary.totalSupplierPayable || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">95% Share allocated to suppliers</div>
        </div>

        <div className="stat">
          <div className="label">Pending Payout Settlement</div>
          <div className="value" style={{ color: '#c2410c' }}>₹{Math.round(summary.totalPendingSettlement || 0).toLocaleString()}</div>
          <div className="text-xs text-muted mt-1">Settled so far: ₹{Math.round(summary.totalSettled || 0).toLocaleString()}</div>
        </div>
      </div>

      {/* Commission Rate Settings Configuration Card */}
      <div className="card mb-3" style={{ background: 'linear-gradient(135deg, #f8fafc, #fff)', border: '1px solid var(--border)' }}>
        <div className="between">
          <div>
            <h3 style={{ margin: 0 }}>⚙️ Configurable Platform Commission Rate</h3>
            <p className="text-xs text-muted" style={{ margin: '0.25rem 0 0' }}>
              Set the default platform revenue percentage charged automatically on every healthcare equipment rental booking.
            </p>
          </div>
          <div className="row">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                type="number"
                step="0.5"
                min="0"
                max="50"
                className="form-control"
                style={{ width: 90, textAlign: 'center', fontWeight: 700, fontSize: '1rem' }}
                value={commissionRate}
                onChange={(e) => setCommissionRate(e.target.value)}
              />
              <span style={{ fontWeight: 700 }}>%</span>
            </div>
            <button
              className="btn btn-primary btn-sm"
              onClick={handleSaveRate}
              disabled={savingRate}
            >
              {savingRate ? 'Saving…' : 'Save Commission Rule'}
            </button>
          </div>
        </div>
      </div>

      {/* Supplier Settlement Breakdown Table */}
      <div className="card mb-3">
        <div className="between mb-2">
          <h3>🏭 Supplier Payout Balances & Settlement Queue</h3>
          <span className="text-xs text-muted">Grouped by verified supplier partners</span>
        </div>

        <div className="table-wrap" style={{ border: 'none' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Supplier Partner</th>
                <th>City</th>
                <th>Total Rentals</th>
                <th>Gross Bookings</th>
                <th>MediRent Commission</th>
                <th>Supplier Net Earnings</th>
                <th>Settled Payouts</th>
                <th>Pending Payout Balance</th>
                <th className="right">Settlement Status</th>
              </tr>
            </thead>
            <tbody>
              {supplierBreakdown && supplierBreakdown.length > 0 ? (
                supplierBreakdown.map((item, idx) => (
                  <tr key={idx}>
                    <td>
                      <strong>{item.owner?.organizationName || item.owner?.name}</strong>
                      <div className="text-xs text-muted">{item.owner?.email}</div>
                    </td>
                    <td>{item.owner?.city || 'Chennai'}</td>
                    <td><span className="badge badge-info">{item.rentalCount} Bookings</span></td>
                    <td>₹{item.gross?.toLocaleString()}</td>
                    <td style={{ color: '#6d28d9', fontWeight: 600 }}>₹{Math.round(item.commission).toLocaleString()}</td>
                    <td style={{ fontWeight: 700 }}>₹{Math.round(item.supplierShare).toLocaleString()}</td>
                    <td style={{ color: '#16a34a' }}>₹{Math.round(item.settledPayout).toLocaleString()}</td>
                    <td style={{ color: '#c2410c', fontWeight: 700, fontSize: '1rem' }}>
                      ₹{Math.round(item.pendingPayout).toLocaleString()}
                    </td>
                    <td className="right">
                      {item.pendingPayout > 0 ? (
                        <span className="badge badge-warn">PENDING DISBURSEMENT</span>
                      ) : (
                        <span className="badge badge-success">ALL SETTLED</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No supplier payout balances found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
