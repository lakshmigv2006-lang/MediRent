import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminVerification() {
  const [activeTab, setActiveTab] = useState('hospitals'); // 'hospitals' | 'suppliers' | 'equipment'
  const [data, setData] = useState({ hospitals: [], suppliers: [], equipment: [], totalPending: 0 });
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const toast = useToast();

  const loadData = () => {
    setLoading(true);
    api.get('/admin/verification')
      .then((res) => setData(res.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load verification queue'))
      .finally(() => setLoading(false));
  };

  useEffect(loadData, []);

  const handleApprove = async (type, id) => {
    setActionLoading(true);
    try {
      if (type === 'hospital') {
        await api.put(`/admin/hospitals/${id}/approve`);
        toast.success('Hospital verified and activated!');
      } else if (type === 'supplier') {
        await api.put(`/admin/suppliers/${id}/approve`);
        toast.success('Supplier verified and approved for listings!');
      } else if (type === 'equipment') {
        await api.put(`/admin/equipment/${id}/approve`);
        toast.success('Equipment verified and published to marketplace!');
      }
      setSelectedItem(null);
      loadData();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Approval failed');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Please specify a rejection reason');
      return;
    }
    setActionLoading(true);
    try {
      const { type, _id } = selectedItem;
      if (type === 'hospital') {
        await api.put(`/admin/hospitals/${_id}/reject`, { reason: rejectReason });
        toast.success('Hospital registration rejected');
      } else if (type === 'supplier') {
        await api.put(`/admin/suppliers/${_id}/reject`, { reason: rejectReason });
        toast.success('Supplier registration rejected');
      } else if (type === 'equipment') {
        await api.put(`/admin/equipment/${_id}/reject`, { reason: rejectReason });
        toast.success('Equipment listing rejected');
      }
      setShowRejectModal(false);
      setSelectedItem(null);
      setRejectReason('');
      loadData();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Rejection failed');
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🛡️ Verification Center</h1>
          <p className="text-muted">
            Inspect onboarding credentials, licenses, certificates, and equipment compliance before marketplace activation.
          </p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={loadData}>
          🔄 Refresh Queue
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="nav-tabs">
        <button
          className={`nav-tab ${activeTab === 'hospitals' ? 'active' : ''}`}
          onClick={() => setActiveTab('hospitals')}
        >
          🏥 Pending Hospitals
          <span className={`badge ${data.hospitals.length > 0 ? 'badge-warn' : 'badge-success'}`}>
            {data.hospitals.length}
          </span>
        </button>

        <button
          className={`nav-tab ${activeTab === 'suppliers' ? 'active' : ''}`}
          onClick={() => setActiveTab('suppliers')}
        >
          🏭 Pending Suppliers
          <span className={`badge ${data.suppliers.length > 0 ? 'badge-warn' : 'badge-success'}`}>
            {data.suppliers.length}
          </span>
        </button>

        <button
          className={`nav-tab ${activeTab === 'equipment' ? 'active' : ''}`}
          onClick={() => setActiveTab('equipment')}
        >
          🩺 Pending Equipment Listings
          <span className={`badge ${data.equipment.length > 0 ? 'badge-warn' : 'badge-success'}`}>
            {data.equipment.length}
          </span>
        </button>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div>
          {/* 1. Hospitals Tab */}
          {activeTab === 'hospitals' && (
            <div>
              {data.hospitals.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
                  <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>✅</div>
                  <h3>No Pending Hospital Verifications</h3>
                  <p className="text-muted">All registered hospitals are currently verified and active.</p>
                </div>
              ) : (
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Hospital Name</th>
                        <th>Reg Number</th>
                        <th>Location</th>
                        <th>Contact Person</th>
                        <th>Submitted Date</th>
                        <th>Documents</th>
                        <th className="right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.hospitals.map((h) => (
                        <tr key={h._id}>
                          <td>
                            <strong>{h.organizationName || h.name}</strong>
                            <div className="text-xs text-muted">{h.hospitalType || 'Hospital'}</div>
                          </td>
                          <td><code>{h.registrationNumber || 'PENDING'}</code></td>
                          <td>
                            <div>{h.city}, {h.state}</div>
                            <div className="text-xs text-muted">{h.address}</div>
                          </td>
                          <td>
                            <div>{h.contactPerson || h.name}</div>
                            <div className="text-xs text-muted">{h.phone}</div>
                          </td>
                          <td>{new Date(h.createdAt).toLocaleDateString()}</td>
                          <td>
                            <span className="badge badge-info">
                              📄 {h.documents?.length || 0} Docs
                            </span>
                          </td>
                          <td className="right">
                            <div className="row" style={{ justifyContent: 'flex-end' }}>
                              <button
                                className="btn btn-sm btn-primary"
                                onClick={() => setSelectedItem({ ...h, type: 'hospital' })}
                              >
                                Review Dossier
                              </button>
                              <button
                                className="btn btn-sm btn-success"
                                onClick={() => handleApprove('hospital', h._id)}
                                disabled={actionLoading}
                              >
                                ✓ Approve
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* 2. Suppliers Tab */}
          {activeTab === 'suppliers' && (
            <div>
              {data.suppliers.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
                  <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>✅</div>
                  <h3>No Pending Supplier Verifications</h3>
                  <p className="text-muted">All supplier businesses and equipment distributors are verified.</p>
                </div>
              ) : (
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Supplier Business</th>
                        <th>Registration No</th>
                        <th>Business Type</th>
                        <th>Location</th>
                        <th>Authorized Person</th>
                        <th>Documents</th>
                        <th className="right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.suppliers.map((s) => (
                        <tr key={s._id}>
                          <td>
                            <strong>{s.organizationName || s.name}</strong>
                            <div className="text-xs text-muted">{s.email}</div>
                          </td>
                          <td><code>{s.registrationNumber || 'PENDING'}</code></td>
                          <td>{s.businessType || 'Equipment Dealer'}</td>
                          <td>{s.city}, {s.state}</td>
                          <td>
                            <div>{s.authorizedPerson || s.name}</div>
                            <div className="text-xs text-muted">{s.phone}</div>
                          </td>
                          <td>
                            <span className="badge badge-info">
                              📄 {s.documents?.length || 0} Docs
                            </span>
                          </td>
                          <td className="right">
                            <div className="row" style={{ justifyContent: 'flex-end' }}>
                              <button
                                className="btn btn-sm btn-primary"
                                onClick={() => setSelectedItem({ ...s, type: 'supplier' })}
                              >
                                Review Dossier
                              </button>
                              <button
                                className="btn btn-sm btn-success"
                                onClick={() => handleApprove('supplier', s._id)}
                                disabled={actionLoading}
                              >
                                ✓ Approve
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* 3. Equipment Tab */}
          {activeTab === 'equipment' && (
            <div>
              {data.equipment.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
                  <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>✅</div>
                  <h3>No Equipment Awaiting Listing Verification</h3>
                  <p className="text-muted">All supplier equipment listings are inspected and verified.</p>
                </div>
              ) : (
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Equipment</th>
                        <th>Supplier</th>
                        <th>Category</th>
                        <th>Price/Day</th>
                        <th>Condition</th>
                        <th>Maintenance</th>
                        <th className="right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.equipment.map((eq) => (
                        <tr key={eq._id}>
                          <td>
                            <strong>{eq.name}</strong>
                            <div className="text-xs text-muted">{eq.manufacturer} • {eq.model}</div>
                          </td>
                          <td>
                            <div>{eq.owner?.organizationName || eq.owner?.name}</div>
                            <div className="text-xs text-muted">{eq.owner?.city}</div>
                          </td>
                          <td>{eq.category?.name || 'General'}</td>
                          <td><strong>₹{eq.pricePerDay}</strong></td>
                          <td><span className="badge badge-info">{eq.condition}</span></td>
                          <td>
                            <span className={`badge ${eq.maintenanceStatus === 'up_to_date' ? 'badge-success' : 'badge-warn'}`}>
                              {eq.maintenanceStatus?.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="right">
                            <div className="row" style={{ justifyContent: 'flex-end' }}>
                              <button
                                className="btn btn-sm btn-primary"
                                onClick={() => setSelectedItem({ ...eq, type: 'equipment' })}
                              >
                                Review Specs
                              </button>
                              <button
                                className="btn btn-sm btn-success"
                                onClick={() => handleApprove('equipment', eq._id)}
                                disabled={actionLoading}
                              >
                                ✓ Approve
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Review Dossier Modal for Hospital / Supplier / Equipment */}
      {selectedItem && !showRejectModal && (
        <div className="modal-overlay" onClick={() => setSelectedItem(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>
                {selectedItem.type === 'hospital' && '🏥 Hospital Verification Dossier'}
                {selectedItem.type === 'supplier' && '🏭 Supplier Business Dossier'}
                {selectedItem.type === 'equipment' && '🩺 Equipment Listing Inspection'}
              </h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedItem(null)}>✕</button>
            </div>

            <div className="modal-body">
              {/* Common Header Info */}
              <div className="card mb-3" style={{ background: 'var(--slate-50)' }}>
                <div className="between">
                  <div>
                    <h3 style={{ margin: 0 }}>{selectedItem.organizationName || selectedItem.name}</h3>
                    <div className="text-sm text-muted">
                      {selectedItem.registrationNumber ? `Reg: ${selectedItem.registrationNumber}` : selectedItem.email}
                    </div>
                  </div>
                  <span className="badge badge-warn">PENDING VERIFICATION</span>
                </div>
              </div>

              {/* Entity-specific breakdown */}
              {selectedItem.type !== 'equipment' ? (
                <>
                  <div className="grid grid-2 mb-3">
                    <div>
                      <div className="text-xs text-muted uppercase font-bold">Address & Region</div>
                      <div>{selectedItem.address || '—'}</div>
                      <div>{selectedItem.city}, {selectedItem.state} - {selectedItem.pincode}</div>
                      {selectedItem.googleMapsUrl && (
                        <div className="mt-1">
                          <a
                            href={selectedItem.googleMapsUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="btn btn-sm btn-outline"
                          >
                            📍 View on Google Maps
                          </a>
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-xs text-muted uppercase font-bold">Contact & Representative</div>
                      <div>{selectedItem.contactPerson || selectedItem.authorizedPerson || selectedItem.name}</div>
                      <div>Phone: {selectedItem.phone || '—'}</div>
                      <div>Email: {selectedItem.email}</div>
                    </div>
                  </div>

                  {/* Uploaded Documents */}
                  <div>
                    <h4>Uploaded Verification Documents</h4>
                    {selectedItem.documents && selectedItem.documents.length > 0 ? (
                      <div className="doc-grid">
                        {selectedItem.documents.map((doc, idx) => (
                          <div key={idx} className="doc-card">
                            <div className="doc-icon">PDF</div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontWeight: 600, fontSize: '0.85rem', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                                {doc.fileName}
                              </div>
                              <div className="text-xs text-muted">
                                {doc.documentType?.replace(/_/g, ' ')}
                              </div>
                              <a
                                href={doc.fileUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-xs"
                                style={{ color: 'var(--teal-600)', fontWeight: 600 }}
                              >
                                👁️ Open Document
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-muted text-sm">No supporting documents uploaded.</div>
                    )}
                  </div>
                </>
              ) : (
                /* Equipment dossier */
                <>
                  <div className="grid grid-2 mb-3">
                    <div>
                      <div className="text-xs text-muted font-bold uppercase">Manufacturer & Model</div>
                      <div>{selectedItem.manufacturer || '—'} / {selectedItem.model || '—'}</div>
                      <div className="text-xs text-muted">Serial No: {selectedItem.serialNumber || 'N/A'}</div>
                      <div className="mt-1">
                        <strong>Daily Rate:</strong> ₹{selectedItem.pricePerDay} | <strong>Deposit:</strong> ₹{selectedItem.securityDeposit || 0}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted font-bold uppercase">Condition & Maintenance</div>
                      <div>Condition: <span className="badge badge-info">{selectedItem.condition}</span></div>
                      <div className="mt-1">
                        Maintenance Status: <span className="badge badge-success">{selectedItem.maintenanceStatus?.replace(/_/g, ' ')}</span>
                      </div>
                      <div className="text-xs text-muted mt-1">
                        Next Service Due: {selectedItem.nextServiceDate ? new Date(selectedItem.nextServiceDate).toLocaleDateString() : 'N/A'}
                      </div>
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="text-xs text-muted font-bold uppercase">Description</div>
                    <p className="text-sm">{selectedItem.description || 'No description provided'}</p>
                  </div>

                  {selectedItem.images && selectedItem.images.length > 0 && (
                    <div className="mb-3">
                      <h4>Equipment Photos</h4>
                      <div style={{ display: 'flex', gap: '0.5rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
                        {selectedItem.images.map((img, i) => (
                          <img
                            key={i}
                            src={img}
                            alt="Equipment preview"
                            style={{ width: 120, height: 90, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedItem.documents && selectedItem.documents.length > 0 && (
                    <div>
                      <h4>Service & Compliance Certificates</h4>
                      <div className="doc-grid">
                        {selectedItem.documents.map((doc, idx) => (
                          <div key={idx} className="doc-card">
                            <div className="doc-icon">PDF</div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{doc.fileName}</div>
                              <a href={doc.fileUrl} target="_blank" rel="noreferrer" className="text-xs" style={{ color: 'var(--teal-600)', fontWeight: 600 }}>
                                👁️ View Certificate
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="modal-footer">
              <button
                className="btn btn-danger btn-sm"
                onClick={() => setShowRejectModal(true)}
              >
                ✕ Reject with Reason
              </button>
              <button
                className="btn btn-success btn-sm"
                onClick={() => handleApprove(selectedItem.type, selectedItem._id)}
                disabled={actionLoading}
              >
                {actionLoading ? 'Processing…' : '✓ Approve & Activate'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rejection Reason Modal */}
      {showRejectModal && selectedItem && (
        <div className="modal-overlay" onClick={() => setShowRejectModal(false)}>
          <div className="modal-content" style={{ maxWidth: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Specify Rejection Reason</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p className="text-sm text-muted">
                Explain why <strong>{selectedItem.organizationName || selectedItem.name}</strong> cannot be verified. This reason will be logged and dispatched to the applicant.
              </p>
              <div className="form-group">
                <label>Rejection Reason / Required Rectifications *</label>
                <textarea
                  className="form-control"
                  rows={4}
                  placeholder="e.g. Uploaded GST certificate expired; registration license number does not match health department records."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setShowRejectModal(false)}>
                Cancel
              </button>
              <button
                className="btn btn-danger btn-sm"
                onClick={handleReject}
                disabled={actionLoading || !rejectReason.trim()}
              >
                {actionLoading ? 'Submitting…' : 'Confirm Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
