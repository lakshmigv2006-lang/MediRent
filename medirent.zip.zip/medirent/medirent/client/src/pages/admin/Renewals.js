import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminRenewals() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/admin/renewals')
      .then((r) => setItems(r.data.items || []))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load renewal requests'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>🔄 Rental Renewals & Duration Extension Monitoring</h1>
          <p className="text-muted">Monitor hospital extension requests, supplier approvals, and additional rental payments.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Rental ID</th>
                <th>Hospital</th>
                <th>Supplier</th>
                <th>Equipment</th>
                <th>Original End Date</th>
                <th>Extension Requested</th>
                <th>Additional Days</th>
                <th>Additional Amount</th>
                <th>Renewal Status</th>
                <th className="right">Payment & Sync</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => {
                const latestReq = r.renewalRequests?.[r.renewalRequests.length - 1];
                return (
                  <tr key={r._id}>
                    <td><strong>{r.rentalCode || r._id.slice(-6).toUpperCase()}</strong></td>
                    <td>
                      <div>{r.renter?.organizationName || r.renter?.name}</div>
                      <div className="text-xs text-muted">{r.renter?.city}</div>
                    </td>
                    <td>
                      <div>{r.owner?.organizationName || r.owner?.name}</div>
                      <div className="text-xs text-muted">{r.owner?.city}</div>
                    </td>
                    <td>{r.equipment?.name}</td>
                    <td>{new Date(r.endDate).toLocaleDateString()}</td>
                    <td>
                      {latestReq?.requestedEndDate ? (
                        <strong>{new Date(latestReq.requestedEndDate).toLocaleDateString()}</strong>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td>
                      <span className="badge badge-info">
                        +{latestReq?.additionalDays || 0} Days
                      </span>
                    </td>
                    <td>
                      <strong>₹{latestReq?.additionalAmount?.toLocaleString() || 0}</strong>
                    </td>
                    <td>
                      <span className={`badge ${
                        latestReq?.status === 'approved' ? 'badge-success' :
                        latestReq?.status === 'rejected' ? 'badge-danger' : 'badge-warn'
                      }`}>
                        {latestReq?.status?.toUpperCase() || r.status?.toUpperCase()}
                      </span>
                    </td>
                    <td className="right">
                      <span className="badge badge-primary">
                        {r.paymentStatus === 'captured' ? 'Captured' : 'Pending'}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {items.length === 0 && (
                <tr>
                  <td colSpan="10" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No rental renewals or extensions requested yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
