import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminRentals() {
  const [data, setData] = useState({ items: [], total: 0, page: 1, pages: 1 });
  const [filters, setFilters] = useState({ status: '', paymentStatus: '', q: '', page: 1 });
  const [selectedRental, setSelectedRental] = useState(null);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
    api.get('/admin/rentals', { params })
      .then((r) => setData(r.data))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load rentals'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [filters]);

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>📦 Platform Rental Monitoring & Lifecycle</h1>
          <p className="text-muted">Monitor end-to-end healthcare equipment transactions, logistics, payments, and active rentals.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {/* Filter Bar */}
      <div className="card mb-3" style={{ padding: '0.85rem 1.25rem' }}>
        <div className="row">
          <input
            className="form-control"
            style={{ maxWidth: 280 }}
            placeholder="Search Rental ID, notes…"
            value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value, page: 1 })}
          />
          <select
            className="form-control"
            style={{ maxWidth: 220 }}
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
          >
            <option value="">All Rental Lifecycle Stages</option>
            <option value="requested">Requested</option>
            <option value="approved">Approved</option>
            <option value="payment_pending">Payment Pending</option>
            <option value="paid">Paid (Confirmed)</option>
            <option value="ready_for_pickup">Ready for Pickup</option>
            <option value="pickup_scheduled">Pickup Scheduled</option>
            <option value="handed_over">Handed Over</option>
            <option value="active">Active Rental</option>
            <option value="renewal_requested">Renewal Requested</option>
            <option value="return_requested">Return Requested</option>
            <option value="returned">Returned</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            className="form-control"
            style={{ maxWidth: 190 }}
            value={filters.paymentStatus}
            onChange={(e) => setFilters({ ...filters, paymentStatus: e.target.value, page: 1 })}
          >
            <option value="">All Payment Statuses</option>
            <option value="captured">Captured (Paid)</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Rental ID</th>
                <th>Hospital (Renter)</th>
                <th>Supplier (Owner)</th>
                <th>Equipment</th>
                <th>Period (Days)</th>
                <th>Gross Total</th>
                <th>Rental Status</th>
                <th>Payment</th>
                <th>Pickup</th>
                <th className="right">Lifecycle</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((r) => (
                <tr key={r._id}>
                  <td><strong>{r.rentalCode || r._id.slice(-6).toUpperCase()}</strong></td>
                  <td>
                    <div>{r.renter?.organizationName || r.renter?.name}</div>
                    <div className="text-xs text-muted">{r.renter?.city}</div>
                  </td>
                  <td>
                    <div>{r.owner?.organizationName || r.owner?.name}</div>
                    <div className="text-xs text-muted">{r.owner?.city}</div>
                  </td>
                  <td>
                    <strong>{r.equipment?.name || 'Equipment'}</strong>
                    <div className="text-xs text-muted">₹{r.pricePerDay || r.equipment?.pricePerDay}/day</div>
                  </td>
                  <td>
                    <div>{new Date(r.startDate).toLocaleDateString()} - {new Date(r.endDate).toLocaleDateString()}</div>
                    <div className="text-xs text-muted">{r.days} Days</div>
                  </td>
                  <td>
                    <strong>₹{r.totalAmount?.toLocaleString()}</strong>
                    <div className="text-xs text-muted">Fee: ₹{r.commissionAmount || 0}</div>
                  </td>
                  <td>
                    <span className={`badge ${
                      r.status === 'active' ? 'badge-success' :
                      r.status === 'completed' ? 'badge-info' :
                      r.status === 'paid' ? 'badge-primary' :
                      r.status === 'renewal_requested' ? 'badge-purple' :
                      r.status === 'return_requested' ? 'badge-warn' :
                      r.status === 'rejected' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {r.status?.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${r.paymentStatus === 'captured' ? 'badge-success' : 'badge-warn'}`}>
                      {r.paymentStatus === 'captured' ? '✓ CAPTURED' : r.paymentStatus?.toUpperCase() || 'PENDING'}
                    </span>
                  </td>
                  <td>
                    <span className="badge badge-info">
                      {r.pickupStatus?.replace(/_/g, ' ') || 'Waiting'}
                    </span>
                  </td>
                  <td className="right">
                    <button
                      className="btn btn-sm btn-primary"
                      onClick={() => setSelectedRental(r)}
                    >
                      Lifecycle →
                    </button>
                  </td>
                </tr>
              ))}
              {data.items.length === 0 && (
                <tr>
                  <td colSpan="10" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No rental records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {data.pages > 1 && (
        <div className="pagination">
          {Array.from({ length: data.pages }).map((_, i) => (
            <button
              key={i}
              className={filters.page === i + 1 ? 'active' : ''}
              onClick={() => setFilters({ ...filters, page: i + 1 })}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {/* Rental Lifecycle Timeline Modal */}
      {selectedRental && (
        <div className="modal-overlay" onClick={() => setSelectedRental(null)}>
          <div className="modal-content" style={{ maxWidth: 750 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h3 style={{ margin: 0 }}>Rental Transaction Lifecycle — {selectedRental.rentalCode || selectedRental._id}</h3>
                <div className="text-xs text-muted">Created: {new Date(selectedRental.createdAt).toLocaleString()}</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedRental(null)}>✕</button>
            </div>
            <div className="modal-body">
              {/* Summary Cards */}
              <div className="grid grid-3 mb-3">
                <div className="card" style={{ background: 'var(--slate-50)', padding: '0.85rem' }}>
                  <div className="text-xs text-muted font-bold">Hospital (Renter)</div>
                  <div><strong>{selectedRental.renter?.organizationName || selectedRental.renter?.name}</strong></div>
                  <div className="text-xs text-muted">{selectedRental.renter?.phone}</div>
                </div>
                <div className="card" style={{ background: 'var(--slate-50)', padding: '0.85rem' }}>
                  <div className="text-xs text-muted font-bold">Supplier (Owner)</div>
                  <div><strong>{selectedRental.owner?.organizationName || selectedRental.owner?.name}</strong></div>
                  <div className="text-xs text-muted">{selectedRental.owner?.phone}</div>
                </div>
                <div className="card" style={{ background: 'var(--slate-50)', padding: '0.85rem' }}>
                  <div className="text-xs text-muted font-bold">Financial Split</div>
                  <div>Total: <strong>₹{selectedRental.totalAmount?.toLocaleString()}</strong></div>
                  <div className="text-xs text-muted">
                    Comm (5%): ₹{selectedRental.commissionAmount || 0} | Supplier: ₹{selectedRental.supplierAmount || 0}
                  </div>
                </div>
              </div>

              {/* Pickup & Vehicle info if exists */}
              {selectedRental.pickupDetails?.driverName && (
                <div className="card mb-3" style={{ background: '#f0fdfa', borderColor: '#ccfbf1' }}>
                  <div className="between">
                    <strong style={{ color: 'var(--teal-700)' }}>🚚 Hospital Arranged Logistics & Pickup Details</strong>
                    <span className="badge badge-success">{selectedRental.pickupStatus?.replace(/_/g, ' ')}</span>
                  </div>
                  <div className="grid grid-3 mt-1 text-sm">
                    <div><strong>Driver:</strong> {selectedRental.pickupDetails.driverName}</div>
                    <div><strong>Phone:</strong> {selectedRental.pickupDetails.driverPhone}</div>
                    <div><strong>Vehicle:</strong> {selectedRental.pickupDetails.vehicleNumber} ({selectedRental.pickupDetails.vehicleType})</div>
                  </div>
                </div>
              )}

              {/* Complete Lifecycle Timeline */}
              <h4>Transaction Stages & Audit Trail</h4>
              <div className="lifecycle-timeline mt-2">
                {selectedRental.timeline && selectedRental.timeline.length > 0 ? (
                  selectedRental.timeline.map((t, idx) => (
                    <div key={idx} className="timeline-item">
                      <div className="timeline-marker done">✓</div>
                      <div className="timeline-body">
                        <div className="between">
                          <strong style={{ textTransform: 'capitalize' }}>{t.status?.replace(/_/g, ' ')}</strong>
                          <span className="text-xs text-muted">{new Date(t.at).toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-muted" style={{ margin: '0.25rem 0 0' }}>{t.note || 'State transitioned successfully'}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-muted text-sm">No detailed timeline logged.</div>
                )}
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setSelectedRental(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
