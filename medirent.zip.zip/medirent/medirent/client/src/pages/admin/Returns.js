import { useEffect, useState } from 'react';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function AdminReturns() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReturn, setSelectedReturn] = useState(null);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    api.get('/admin/returns')
      .then((r) => setItems(r.data.items || []))
      .catch((err) => toast.error(err?.response?.data?.message || 'Failed to load return records'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  return (
    <div>
      <div className="between mb-3">
        <div>
          <h1>↩️ Returns & Equipment Condition Inspection</h1>
          <p className="text-muted">Monitor hospital return requests, post-rental physical condition inspections, and damage audits.</p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
      </div>

      {loading ? (
        <div className="center-loader"><div className="spinner" /></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Rental ID</th>
                <th>Hospital</th>
                <th>Supplier</th>
                <th>Equipment</th>
                <th>Serial Number</th>
                <th>Return Date</th>
                <th>Physical Condition</th>
                <th>Damage Assessment</th>
                <th>Status</th>
                <th className="right">Details</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => (
                <tr key={r._id}>
                  <td><strong>{r.rentalCode || r._id.slice(-6).toUpperCase()}</strong></td>
                  <td>
                    <div>{r.renter?.organizationName || r.renter?.name}</div>
                    <div className="text-xs text-muted">{r.renter?.city}</div>
                  </td>
                  <td>
                    <div>{r.owner?.organizationName || r.owner?.name}</div>
                    <div className="text-xs text-muted">{r.owner?.city}</div>
                  </td>
                  <td>{r.equipment?.name}</td>
                  <td><code>{r.equipment?.serialNumber || 'N/A'}</code></td>
                  <td>
                    {r.returnDetails?.returnDate ? (
                      new Date(r.returnDetails.returnDate).toLocaleDateString()
                    ) : r.returnDetails?.requestedDate ? (
                      new Date(r.returnDetails.requestedDate).toLocaleDateString()
                    ) : (
                      new Date(r.endDate).toLocaleDateString()
                    )}
                  </td>
                  <td>
                    <span className={`badge ${
                      r.returnDetails?.condition === 'good' ? 'badge-success' :
                      r.returnDetails?.condition === 'damaged' ? 'badge-danger' : 'badge-warn'
                    }`}>
                      {r.returnDetails?.condition?.toUpperCase() || 'GOOD'}
                    </span>
                  </td>
                  <td>
                    <div className="text-xs" style={{ maxWidth: 220, textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                      {r.returnDetails?.damageNotes || 'No damages noted. Inspection passed.'}
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${r.status === 'completed' ? 'badge-success' : 'badge-warn'}`}>
                      {r.status?.replace(/_/g, ' ')?.toUpperCase()}
                    </span>
                  </td>
                  <td className="right">
                    <button
                      className="btn btn-sm btn-outline"
                      onClick={() => setSelectedReturn(r)}
                    >
                      Audit
                    </button>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan="10" className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>
                    No return or inspection records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Return Inspection Modal */}
      {selectedReturn && (
        <div className="modal-overlay" onClick={() => setSelectedReturn(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Equipment Return & Condition Audit</h3>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedReturn(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="card mb-3" style={{ background: 'var(--slate-50)' }}>
                <div className="between">
                  <div>
                    <h3 style={{ margin: 0 }}>{selectedReturn.equipment?.name}</h3>
                    <div className="text-xs text-muted">Rental Code: {selectedReturn.rentalCode || selectedReturn._id}</div>
                  </div>
                  <span className={`badge ${selectedReturn.returnDetails?.condition === 'damaged' ? 'badge-danger' : 'badge-success'}`}>
                    Condition: {selectedReturn.returnDetails?.condition?.toUpperCase() || 'GOOD'}
                  </span>
                </div>
              </div>

              <div className="grid grid-2 mb-3">
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Hospital Information</div>
                  <div><strong>{selectedReturn.renter?.organizationName || selectedReturn.renter?.name}</strong></div>
                  <div>Phone: {selectedReturn.renter?.phone}</div>
                  <div>Email: {selectedReturn.renter?.email}</div>
                </div>
                <div>
                  <div className="text-xs text-muted font-bold uppercase">Supplier Custodian</div>
                  <div><strong>{selectedReturn.owner?.organizationName || selectedReturn.owner?.name}</strong></div>
                  <div>Phone: {selectedReturn.owner?.phone}</div>
                  <div>Email: {selectedReturn.owner?.email}</div>
                </div>
              </div>

              <div className="card mb-3" style={{ background: selectedReturn.returnDetails?.condition === 'damaged' ? '#fff1f2' : '#f0fdf4' }}>
                <div className="text-xs font-bold" style={{ textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                  Inspection & Damage Notes:
                </div>
                <p className="text-sm" style={{ margin: 0 }}>
                  {selectedReturn.returnDetails?.damageNotes || 'Equipment returned in clean, fully operational status. Passed electrical safety check.'}
                </p>
              </div>

              {selectedReturn.returnDetails?.damageImageUrl && (
                <div>
                  <h4>Inspection Photos</h4>
                  <img
                    src={selectedReturn.returnDetails.damageImageUrl}
                    alt="Damage inspection"
                    style={{ maxWidth: '100%', borderRadius: 8, border: '1px solid var(--border)' }}
                  />
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setSelectedReturn(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
