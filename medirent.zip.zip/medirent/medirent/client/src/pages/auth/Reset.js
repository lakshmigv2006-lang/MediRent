import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function Reset() {
  const [sp] = useSearchParams();
  const [token, setToken] = useState(sp.get('token') || '');
  const [newPassword, setNew] = useState('');
  const nav = useNavigate();
  const toast = useToast();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/auth/reset', { token, newPassword });
      toast.success('Password updated. Please sign in.');
      nav('/login');
    } catch (err) { toast.error(err.response?.data?.message || 'Reset failed'); }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-side"><div style={{ fontWeight: 700, fontSize: '1.4rem' }}>MediRent</div></div>
      <div className="auth-form">
        <div className="box">
          <h1>Reset password</h1>
          <form onSubmit={submit}>
            <div className="form-group"><label>Reset token</label>
              <input className="form-control" value={token} onChange={(e) => setToken(e.target.value)} required /></div>
            <div className="form-group"><label>New password</label>
              <input className="form-control" type="password" value={newPassword} onChange={(e) => setNew(e.target.value)} required minLength={6} /></div>
            <button className="btn btn-primary" style={{ width: '100%' }}>Reset password</button>
          </form>
          <div className="mt-2 text-sm"><Link to="/login">← Back to sign in</Link></div>
        </div>
      </div>
    </div>
  );
}
