import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function Register() {
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: 'hospital',
    organizationName: '', phone: '', city: '',
  });
  const [busy, setBusy] = useState(false);
  const { register } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');
    setBusy(true);
    try {
      const u = await register(form);
      toast.success('Account created');
      nav(`/${u.role === 'admin' ? 'admin' : u.role}`, { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Signup failed');
    } finally { setBusy(false); }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-side">
        <div style={{ fontWeight: 700, fontSize: '1.4rem' }}>MediRent</div>
        <div>
          <h2 style={{ color: '#fff' }}>Join the healthcare rental network.</h2>
          <p style={{ color: 'rgba(255,255,255,.75)' }}>
            Hospitals get equipment when they need it. Suppliers monetize idle inventory.
            Everyone wins — including patients.
          </p>
        </div>
        <div style={{ opacity: .5, fontSize: '.8rem' }}>© {new Date().getFullYear()} MediRent</div>
      </div>
      <div className="auth-form">
        <div className="box">
          <h1>Create account</h1>
          <p className="text-muted mb-2">Choose your role and get started in seconds.</p>
          <form onSubmit={submit}>
            <div className="form-group">
              <label>I am a…</label>
              <select className="form-control" value={form.role} onChange={set('role')}>
                <option value="hospital">Hospital / Clinic</option>
                <option value="supplier">Equipment Supplier</option>
              </select>
            </div>
            <div className="form-row">
              <div className="form-group"><label>Full name</label>
                <input className="form-control" value={form.name} onChange={set('name')} required /></div>
              <div className="form-group"><label>Organization</label>
                <input className="form-control" value={form.organizationName} onChange={set('organizationName')} /></div>
            </div>
            <div className="form-group"><label>Email</label>
              <input className="form-control" type="email" value={form.email} onChange={set('email')} required /></div>
            <div className="form-row">
              <div className="form-group"><label>Phone</label>
                <input className="form-control" value={form.phone} onChange={set('phone')} /></div>
              <div className="form-group"><label>City</label>
                <input className="form-control" value={form.city} onChange={set('city')} /></div>
            </div>
            <div className="form-group"><label>Password</label>
              <input className="form-control" type="password" value={form.password} onChange={set('password')} required minLength={6} /></div>
            <button className="btn btn-primary" style={{ width: '100%' }} disabled={busy}>
              {busy ? <span className="spinner spinner-inline" /> : 'Create account'}
            </button>
          </form>
          <div className="between mt-2 text-sm">
            <span className="text-muted">Already have an account?</span>
            <Link to="/login">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
