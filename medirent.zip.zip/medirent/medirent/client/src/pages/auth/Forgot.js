import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { useToast } from '../../context/ToastContext';

export default function Forgot() {
  const [email, setEmail] = useState('');
  const [devToken, setDevToken] = useState('');
  const toast = useToast();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await api.post('/auth/forgot', { email });
      toast.success('If the email exists, a reset link was generated');
      if (data.devToken) setDevToken(data.devToken);
    } catch (err) { toast.error('Request failed'); }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-side"><div style={{ fontWeight: 700, fontSize: '1.4rem' }}>MediRent</div></div>
      <div className="auth-form">
        <div className="box">
          <h1>Forgot password</h1>
          <p className="text-muted mb-2">Enter your email and we'll issue a reset token.</p>
          <form onSubmit={submit}>
            <div className="form-group"><label>Email</label>
              <input className="form-control" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
            <button className="btn btn-primary" style={{ width: '100%' }}>Send reset token</button>
          </form>
          {devToken && (
            <div className="card mt-2" style={{ background: 'var(--teal-50)', borderColor: 'var(--teal-100)' }}>
              <div className="text-sm">Dev-mode token (email delivery is not configured):</div>
              <code style={{ wordBreak: 'break-all' }}>{devToken}</code>
              <div className="mt-1"><Link to={`/reset?token=${devToken}`}>Open reset page →</Link></div>
            </div>
          )}
          <div className="mt-2 text-sm"><Link to="/login">← Back to sign in</Link></div>
        </div>
      </div>
    </div>
  );
}
