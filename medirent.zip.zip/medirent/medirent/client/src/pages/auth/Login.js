import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const { login } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const loc = useLocation();

  const submit = async (e) => {
    e?.preventDefault?.();
    setBusy(true);
    try {
      const u = await login(email, password);
      toast.success(`Welcome back, ${u.name}`);
      const dest = loc.state?.from?.pathname || `/${u.role === 'admin' ? 'admin' : u.role}`;
      nav(dest, { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
  };

  return (
    <div className="auth-wrap">
      <div className="auth-side">
        <div>
          <div style={{ fontWeight: 700, fontSize: '1.4rem' }}>MediRent</div>
          <div style={{ opacity: .7, fontSize: '.9rem' }}>Verified. Reliable. Accessible.</div>
        </div>
        <div>
          <h2 style={{ color: '#fff' }}>Verified Healthcare Equipment Rental Marketplace</h2>
          <p style={{ color: 'rgba(255,255,255,.85)', lineHeight: 1.6 }}>
            Connect verified hospitals with accredited medical suppliers. Smart AI recommendation, Razorpay test payments, server-side signature verification, platform commission tracking, and hospital pickup coordination.
          </p>
        </div>
        <div style={{ opacity: .5, fontSize: '.8rem' }}>© {new Date().getFullYear()} MediRent Healthcare Platform</div>
      </div>

      <div className="auth-form">
        <div className="box">
          <h1>Sign in</h1>
          <p className="text-muted mb-2">Select a demo role or enter your credentials to proceed.</p>

          {/* 1-Click Quick Demo Login Shortcuts */}
          <div className="card mb-3" style={{ background: 'var(--slate-50)', padding: '0.85rem' }}>
            <div className="text-xs text-muted font-bold uppercase mb-1">⚡ Quick Demo Logins</div>
            <div className="row" style={{ gap: '0.4rem' }}>
              <button
                type="button"
                className="btn btn-sm btn-primary"
                onClick={() => fillDemo('admin@medirent.io', 'Admin@123')}
              >
                👑 Admin
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => fillDemo('hospital@medirent.io', 'Hospital@1')}
              >
                🏥 Hospital
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline"
                onClick={() => fillDemo('supplier@medirent.io', 'Supplier@1')}
              >
                🏭 Supplier
              </button>
            </div>
          </div>

          <form onSubmit={submit}>
            <div className="form-group">
              <label>Email Address</label>
              <input
                className="form-control"
                type="email"
                value={email}
                placeholder="name@organization.com"
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                className="form-control"
                type="password"
                value={password}
                placeholder="••••••••"
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} disabled={busy}>
              {busy ? <span className="spinner spinner-inline" /> : 'Sign in to MediRent'}
            </button>
          </form>

          <div className="between mt-2 text-sm">
            <Link to="/forgot">Forgot password?</Link>
            <Link to="/register">Create new account</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
