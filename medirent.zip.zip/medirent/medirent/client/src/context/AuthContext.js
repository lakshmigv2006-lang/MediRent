import { createContext, useContext, useEffect, useState } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('medirent_user');
    return raw ? JSON.parse(raw) : null;
  });
  const [loading, setLoading] = useState(!!localStorage.getItem('medirent_token'));

  useEffect(() => {
    if (!localStorage.getItem('medirent_token')) { setLoading(false); return; }
    api.get('/auth/me').then((r) => {
      setUser(r.data.user);
      localStorage.setItem('medirent_user', JSON.stringify(r.data.user));
    }).catch(() => {
      localStorage.removeItem('medirent_token');
      localStorage.removeItem('medirent_user');
      setUser(null);
    }).finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('medirent_token', data.token);
    localStorage.setItem('medirent_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const register = async (payload) => {
    const { data } = await api.post('/auth/register', payload);
    localStorage.setItem('medirent_token', data.token);
    localStorage.setItem('medirent_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('medirent_token');
    localStorage.removeItem('medirent_user');
    setUser(null);
  };

  const updateUser = (u) => {
    setUser(u);
    localStorage.setItem('medirent_user', JSON.stringify(u));
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}
