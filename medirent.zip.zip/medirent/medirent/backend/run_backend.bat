@echo off
setlocal enabledelayedexpansion

echo =====================================================================
echo           MediRent — FastAPI Python Backend Server
echo =====================================================================
echo.

cd /d "%~dp0"

:: 1. Detect Python executable
set "PYTHON_EXE="

:: Check py launcher
where py >nul 2>nul
if %errorlevel% equ 0 (
    set "PYTHON_EXE=py"
    goto :FOUND_PYTHON
)

:: Check python in PATH
where python >nul 2>nul
if %errorlevel% equ 0 (
    set "PYTHON_EXE=python"
    goto :FOUND_PYTHON
)

:: Check common Windows Python installation directories
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_EXE=%%D\python.exe"
        goto :FOUND_PYTHON
    )
)

for /d %%D in ("C:\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_EXE=%%D\python.exe"
        goto :FOUND_PYTHON
    )
)

for /d %%D in ("C:\Program Files\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_EXE=%%D\python.exe"
        goto :FOUND_PYTHON
    )
)

:NOT_FOUND
echo [!] Python was not detected in PATH or standard installation folders.
echo.
echo To run the native FastAPI server:
echo 1. Download and install Python 3.10+ from: https://www.python.org/downloads/
echo 2. IMPORTANT: Check the box "Add Python to PATH" during installation.
echo 3. Re-run this run_backend.bat script.
echo.
echo In the meantime, you can use the complete live platform at:
echo http://localhost:3000/ (via run-app.bat)
echo.
pause
exit /b 1

:FOUND_PYTHON
echo [*] Detected Python: %PYTHON_EXE%
%PYTHON_EXE% --version
echo.

echo [*] Installing required packages from requirements.txt...
%PYTHON_EXE% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo [!] Warning: pip install encountered an issue. Attempting to start uvicorn directly...
)

echo.
echo =====================================================================
echo [*] Starting FastAPI Uvicorn Server on http://localhost:8000
echo [*] Interactive Swagger Documentation: http://localhost:8000/docs
echo [*] Redoc API Documentation:         http://localhost:8000/redoc
echo =====================================================================
echo.

%PYTHON_EXE% -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
pause
