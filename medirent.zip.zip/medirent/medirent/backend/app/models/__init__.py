from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, Date,
    Numeric, ForeignKey, Enum as SQLEnum
)
from sqlalchemy.orm import relationship
from backend.app.database.connection import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(SQLEnum('admin', 'hospital', 'supplier', name="user_roles"), nullable=False)
    verification_status = Column(SQLEnum('pending', 'verified', 'rejected', 'resubmission_required', name="user_verif_status"), default='pending')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    hospital = relationship("Hospital", back_populates="user", uselist=False, cascade="all, delete-orphan")
    supplier = relationship("Supplier", back_populates="user", uselist=False, cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")


class Hospital(Base):
    __tablename__ = "hospitals"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    hospital_name = Column(String(255), nullable=False)
    registration_number = Column(String(100), unique=True, nullable=False)
    hospital_type = Column(String(100), default="Multi-Specialty Tertiary Care")
    contact_person = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=False)
    address = Column(Text, nullable=False)
    city = Column(String(100), nullable=False, index=True)
    state = Column(String(100), nullable=False)
    pincode = Column(String(20), nullable=False)
    latitude = Column(Numeric(10, 8), default=13.0418)
    longitude = Column(Numeric(11, 8), default=80.2507)
    google_maps_url = Column(String(500), default="https://maps.google.com/?q=13.0418,80.2507")
    verification_status = Column(SQLEnum('pending', 'verified', 'rejected', 'resubmission_required', name="hosp_verif_status"), default='pending')
    verified_at = Column(DateTime, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="hospital")
    rentals = relationship("Rental", back_populates="hospital")


class Supplier(Base):
    __tablename__ = "suppliers"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    business_name = Column(String(255), nullable=False)
    business_registration_number = Column(String(100), unique=True, nullable=False)
    business_type = Column(String(150), default="Authorized Equipment Dealer & Service Center")
    authorized_person = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=False)
    address = Column(Text, nullable=False)
    city = Column(String(100), nullable=False, index=True)
    state = Column(String(100), nullable=False)
    pincode = Column(String(20), nullable=False)
    latitude = Column(Numeric(10, 8), default=13.0850)
    longitude = Column(Numeric(11, 8), default=80.2101)
    google_maps_url = Column(String(500), default="https://maps.google.com/?q=13.0850,80.2101")
    verification_status = Column(SQLEnum('pending', 'verified', 'rejected', 'resubmission_required', name="supp_verif_status"), default='pending')
    verified_at = Column(DateTime, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="supplier")
    equipment = relationship("Equipment", back_populates="supplier", cascade="all, delete-orphan")
    rentals = relationship("Rental", back_populates="supplier")


class Equipment(Base):
    __tablename__ = "equipment"

    id = Column(Integer, primary_key=True, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False, index=True)
    category = Column(String(100), nullable=False, index=True)
    manufacturer = Column(String(150), nullable=False)
    model = Column(String(150), nullable=False)
    serial_number = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    price_per_day = Column(Numeric(10, 2), nullable=False)
    security_deposit = Column(Numeric(10, 2), default=0.00)
    condition_rating = Column(SQLEnum('new', 'excellent', 'good', 'fair', name="condition_enum"), default='excellent')
    availability_status = Column(SQLEnum('available', 'reserved', 'rented', 'under_maintenance', 'unavailable', name="avail_enum"), default='available')
    maintenance_status = Column(SQLEnum('up_to_date', 'service_due', 'under_maintenance', 'not_available', name="maint_enum"), default='up_to_date')
    last_service_date = Column(Date, nullable=True)
    next_service_date = Column(Date, nullable=True)
    verification_status = Column(SQLEnum('pending', 'verified', 'rejected', name="eq_verif_enum"), default='verified')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    supplier = relationship("Supplier", back_populates="equipment")
    images = relationship("EquipmentImage", back_populates="equipment", cascade="all, delete-orphan")
    rentals = relationship("Rental", back_populates="equipment")


class EquipmentImage(Base):
    __tablename__ = "equipment_images"

    id = Column(Integer, primary_key=True, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id", ondelete="CASCADE"), nullable=False)
    image_url = Column(String(500), nullable=False)
    is_primary = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    equipment = relationship("Equipment", back_populates="images")


class Rental(Base):
    __tablename__ = "rentals"

    id = Column(Integer, primary_key=True, index=True)
    rental_code = Column(String(50), unique=True, nullable=False, index=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    equipment_id = Column(Integer, ForeignKey("equipment.id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    number_of_days = Column(Integer, nullable=False)
    price_per_day = Column(Numeric(10, 2), nullable=False)
    rental_amount = Column(Numeric(10, 2), nullable=False)
    commission_amount = Column(Numeric(10, 2), default=0.00)
    supplier_amount = Column(Numeric(10, 2), default=0.00)
    security_deposit = Column(Numeric(10, 2), default=0.00)
    total_amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String(50), default="requested")
    payment_status = Column(String(50), default="pending")
    pickup_status = Column(String(50), default="waiting_for_payment")
    rejection_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    hospital = relationship("Hospital", back_populates="rentals")
    supplier = relationship("Supplier", back_populates="rentals")
    equipment = relationship("Equipment", back_populates="rentals")
    payment = relationship("Payment", back_populates="rental", uselist=False, cascade="all, delete-orphan")
    pickup_request = relationship("PickupRequest", back_populates="rental", uselist=False, cascade="all, delete-orphan")
    renewal_requests = relationship("RenewalRequest", back_populates="rental", cascade="all, delete-orphan")
    return_record = relationship("ReturnRecord", back_populates="rental", uselist=False, cascade="all, delete-orphan")


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    rental_id = Column(Integer, ForeignKey("rentals.id", ondelete="CASCADE"), unique=True, nullable=False)
    total_amount = Column(Numeric(10, 2), nullable=False)
    platform_commission = Column(Numeric(10, 2), nullable=False)
    supplier_amount = Column(Numeric(10, 2), nullable=False)
    razorpay_order_id = Column(String(100), nullable=False)
    razorpay_payment_id = Column(String(100), nullable=False, index=True)
    razorpay_signature = Column(String(255), nullable=True)
    payment_status = Column(String(50), default="captured")
    settlement_status = Column(String(50), default="pending")
    settled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    rental = relationship("Rental", back_populates="payment")


class PickupRequest(Base):
    __tablename__ = "pickup_requests"

    id = Column(Integer, primary_key=True, index=True)
    rental_id = Column(Integer, ForeignKey("rentals.id", ondelete="CASCADE"), unique=True, nullable=False)
    pickup_date = Column(Date, nullable=False)
    pickup_time = Column(String(50), default="10:00 AM - 12:00 PM")
    driver_name = Column(String(150), nullable=False)
    driver_phone = Column(String(50), nullable=False)
    vehicle_number = Column(String(50), nullable=False)
    vehicle_type = Column(String(100), default="Medical Logistics Van")
    pickup_address = Column(Text, nullable=True)
    status = Column(String(50), default="driver_assigned")
    handed_over_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    rental = relationship("Rental", back_populates="pickup_request")


class RenewalRequest(Base):
    __tablename__ = "renewal_requests"

    id = Column(Integer, primary_key=True, index=True)
    rental_id = Column(Integer, ForeignKey("rentals.id", ondelete="CASCADE"), nullable=False)
    requested_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    current_end_date = Column(Date, nullable=False)
    requested_end_date = Column(Date, nullable=False)
    additional_days = Column(Integer, nullable=False)
    additional_amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String(50), default="pending")
    approved_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    rental = relationship("Rental", back_populates="renewal_requests")


class ReturnRecord(Base):
    __tablename__ = "returns"

    id = Column(Integer, primary_key=True, index=True)
    rental_id = Column(Integer, ForeignKey("rentals.id", ondelete="CASCADE"), unique=True, nullable=False)
    requested_date = Column(Date, nullable=False)
    return_date = Column(Date, nullable=True)
    condition_rating = Column(String(50), default="good")
    damage_notes = Column(Text, nullable=True)
    damage_image_url = Column(String(500), nullable=True)
    status = Column(String(50), default="return_requested")
    created_at = Column(DateTime, default=datetime.utcnow)

    rental = relationship("Rental", back_populates="return_record")


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    owner_type = Column(String(50), nullable=False)
    owner_id = Column(Integer, nullable=False)
    document_type = Column(String(100), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_url = Column(String(500), nullable=False)
    file_type = Column(String(50), default="application/pdf")
    verification_status = Column(String(50), default="verified")
    rejection_reason = Column(Text, nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(50), default="info")
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")


class Setting(Base):
    __tablename__ = "settings"

    id = Column(Integer, primary_key=True, index=True)
    key_name = Column(String(100), unique=True, nullable=False)
    value = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
