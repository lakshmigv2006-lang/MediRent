import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.database.connection import engine, Base, SessionLocal
from backend.app.models import User, Hospital, Supplier, Equipment, EquipmentImage, Rental, Payment, Setting
from backend.app.auth.jwt import get_password_hash
from backend.app.routes import auth, admin, hospital, supplier, payments

# Create all database tables on startup
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="MediRent — Healthcare Equipment Rental Platform API",
    description="Full-stack FastAPI backend with MySQL, Scikit-learn AI Recommendation Engine, and Razorpay Test Mode Split Engine.",
    version="1.0.0"
)

# CORS Configuration
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173,http://127.0.0.1:3000,http://127.0.0.1:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all for local development/hackathon demo
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(auth.router)
app.include_router(admin.router)
app.include_router(hospital.router)
app.include_router(supplier.router)
app.include_router(payments.router)

@app.on_event("startup")
def startup_seed_demo_data():
    """Seeds initial platform settings and verified demo accounts if empty."""
    db = SessionLocal()
    try:
        # 1. Commission Setting
        if not db.query(Setting).filter(Setting.key_name == "commission_rate").first():
            db.add(Setting(key_name="commission_rate", value="5.0", description="MediRent 5% Platform Fee"))
            db.commit()

        # 2. Admin User
        admin_user = db.query(User).filter(User.email == "admin@medirent.io").first()
        if not admin_user:
            admin_user = User(
                name="Platform Administrator",
                email="admin@medirent.io",
                password_hash=get_password_hash("Admin@123"),
                role="admin",
                verification_status="verified"
            )
            db.add(admin_user)
            db.commit()

        # 3. Hospital User & Profile
        hosp_user = db.query(User).filter(User.email == "hospital@medirent.io").first()
        if not hosp_user:
            hosp_user = User(
                name="Dr. Anand Ramanathan",
                email="hospital@medirent.io",
                password_hash=get_password_hash("Hospital@1"),
                role="hospital",
                verification_status="verified"
            )
            db.add(hosp_user)
            db.commit()
            db.refresh(hosp_user)

            hosp_profile = Hospital(
                user_id=hosp_user.id,
                hospital_name="City Care Multi-Speciality Hospital",
                registration_number="HOSP-TN-2024-8891",
                hospital_type="Multi-Specialty Tertiary Care",
                contact_person="Dr. Anand Ramanathan",
                phone="+91 98401 23456",
                address="45, Anna Salai, Teynampet",
                city="Chennai",
                state="Tamil Nadu",
                pincode="600018",
                latitude=13.0418,
                longitude=80.2507,
                google_maps_url="https://maps.google.com/?q=13.0418,80.2507",
                verification_status="verified"
            )
            db.add(hosp_profile)
            db.commit()

        # 4. Supplier User & Profile
        supp_user = db.query(User).filter(User.email == "supplier@medirent.io").first()
        if not supp_user:
            supp_user = User(
                name="Rajesh Sharma",
                email="supplier@medirent.io",
                password_hash=get_password_hash("Supplier@1"),
                role="supplier",
                verification_status="verified"
            )
            db.add(supp_user)
            db.commit()
            db.refresh(supp_user)

            supp_profile = Supplier(
                user_id=supp_user.id,
                business_name="MedEquip Solutions Pvt Ltd",
                business_registration_number="MED-SUP-TN-4519",
                business_type="Authorized Equipment Dealer & Service Center",
                authorized_person="Rajesh Sharma",
                phone="+91 94440 98765",
                address="Plot 18, 2nd Avenue, Anna Nagar East",
                city="Chennai",
                state="Tamil Nadu",
                pincode="600102",
                latitude=13.0850,
                longitude=80.2101,
                google_maps_url="https://maps.google.com/?q=13.0850,80.2101",
                verification_status="verified"
            )
            db.add(supp_profile)
            db.commit()
            db.refresh(supp_profile)

            # Equipment items
            eq1 = Equipment(
                supplier_id=supp_profile.id,
                name="Philips EverFlo Oxygen Concentrator 10L",
                category="Respiratory Support",
                manufacturer="Philips Healthcare",
                model="EverFlo 10L",
                serial_number="PH-OC-2024-9982",
                description="High-purity medical grade 10L continuous flow oxygen concentrator with integrated OPI.",
                price_per_day=500.0,
                condition_rating="excellent",
                availability_status="available",
                maintenance_status="up_to_date",
                verification_status="verified"
            )
            db.add(eq1)
            db.commit()
            db.refresh(eq1)

            db.add(EquipmentImage(
                equipment_id=eq1.id,
                image_url="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600",
                is_primary=True
            ))

            eq2 = Equipment(
                supplier_id=supp_profile.id,
                name="Dräger Evita V300 Critical Care Ventilator",
                category="Respiratory Support",
                manufacturer="Dräger Medical",
                model="Evita V300",
                serial_number="DR-EV-2025-4410",
                description="Advanced intensive care ventilator for adult, pediatric, and neonatal patients.",
                price_per_day=1800.0,
                condition_rating="new",
                availability_status="available",
                maintenance_status="up_to_date",
                verification_status="verified"
            )
            db.add(eq2)
            db.commit()
            db.refresh(eq2)

            db.add(EquipmentImage(
                equipment_id=eq2.id,
                image_url="https://images.unsplash.com/photo-1516549655169-df83a0774514?w=600",
                is_primary=True
            ))
            db.commit()

            # Seed demo rentals
            hosp_p = db.query(Hospital).first()
            if hosp_p:
                from datetime import date
                r1 = Rental(
                    rental_code="MR-1001",
                    hospital_id=hosp_p.id,
                    supplier_id=supp_profile.id,
                    equipment_id=eq1.id,
                    start_date=date(2026, 9, 10),
                    end_date=date(2026, 9, 15),
                    number_of_days=5,
                    price_per_day=500.0,
                    rental_amount=2500.0,
                    commission_amount=125.0,
                    supplier_amount=2375.0,
                    total_amount=2500.0,
                    status="approved",
                    payment_status="pending",
                    pickup_status="waiting_for_payment"
                )
                db.add(r1)
                db.commit()
    finally:
        db.close()

@app.get("/")
def root():
    return {
        "platform": "MediRent Healthcare Equipment Rental Marketplace",
        "status": "online",
        "version": "1.0.0",
        "docs_url": "/docs",
        "redoc_url": "/redoc"
    }

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "database": "connected", "ai_engine": "ready"}
