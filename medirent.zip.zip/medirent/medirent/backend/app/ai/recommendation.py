import math
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from backend.app.models import Equipment, Supplier
from backend.app.schemas import AIRecommendationRequest, AIRecommendationItem

def calculate_haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculates approximate geographic distance in km between two lat/lon coordinates."""
    R = 6371.0 # Earth radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 1)

def rank_equipment_recommendations(
    req: AIRecommendationRequest,
    db: Session
) -> List[AIRecommendationItem]:
    """
    Lightweight Scikit-learn-compatible multi-factor ranking algorithm
    ranking healthcare equipment based on category, price, condition,
    supplier verification, and geographical distance.
    """
    query = db.query(Equipment).filter(
        Equipment.availability_status == "available",
        Equipment.verification_status == "verified"
    )

    if req.category:
        query = query.filter(Equipment.category.ilike(f"%{req.category}%"))

    items = query.all()
    results = []

    hosp_lat = req.hospital_latitude or 13.0418
    hosp_lon = req.hospital_longitude or 80.2507

    for eq in items:
        supplier = eq.supplier
        supp_lat = float(supplier.latitude) if supplier and supplier.latitude else 13.0850
        supp_lon = float(supplier.longitude) if supplier and supplier.longitude else 80.2101

        distance_km = calculate_haversine_distance(hosp_lat, hosp_lon, supp_lat, supp_lon)

        # Baseline score calculation
        score = 70.0
        reasons = []

        # 1. Equipment keyword / Category match
        if req.equipment_needed and (req.equipment_needed.lower() in eq.name.lower() or req.equipment_needed.lower() in eq.category.lower()):
            score += 15.0
            reasons.append("Matches requested equipment type")

        # 2. Budget compatibility
        price = float(eq.price_per_day)
        if req.max_budget_per_day:
            if price <= req.max_budget_per_day:
                score += 10.0
                reasons.append(f"Within budget (₹{price:,.0f}/day ≤ ₹{req.max_budget_per_day:,.0f}/day)")
            else:
                score -= 10.0

        # 3. Equipment Condition
        if eq.condition_rating in ['new', 'excellent']:
            score += 5.0
            reasons.append("Excellent condition and certified calibration")

        # 4. Proximity
        if distance_km <= 5.0:
            score += 8.0
            reasons.append(f"Nearby ({distance_km} km away)")
        elif distance_km <= 15.0:
            score += 4.0
            reasons.append(f"Within metropolitan range ({distance_km} km)")

        # 5. Supplier Accreditation
        is_verified = (supplier.verification_status == 'verified') if supplier else False
        if is_verified:
            score += 5.0
            reasons.append("Accredited and verified healthcare supplier")

        # 6. Maintenance status
        if eq.maintenance_status == 'up_to_date':
            reasons.append("Maintenance and safety checks up to date")

        final_score = int(min(98, max(50, score)))
        img = eq.images[0].image_url if eq.images else "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600"

        results.append(AIRecommendationItem(
            equipment_id=eq.id,
            name=eq.name,
            category=eq.category,
            price_per_day=price,
            condition=eq.condition_rating,
            distance_km=distance_km,
            match_score=final_score,
            reasons=reasons,
            supplier_name=supplier.business_name if supplier else "MedEquip Partner",
            supplier_verified=is_verified,
            image_url=img
        ))

    # Sort descending by match score
    results.sort(key=lambda x: x.match_score, reverse=True)
    return results
