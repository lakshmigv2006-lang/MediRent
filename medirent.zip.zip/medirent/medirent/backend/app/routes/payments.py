from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.models import Rental, Payment, Setting
from backend.app.schemas import PaymentOrderCreate, PaymentVerifyRequest, SplitBreakdown
from backend.app.payments.razorpay_client import (
    create_razorpay_order, verify_razorpay_signature, calculate_marketplace_split
)

router = APIRouter(prefix="/api/payments", tags=["Razorpay Payments"])

@router.post("/create-order")
def create_order(data: PaymentOrderCreate, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == data.rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    amount = float(rental.total_amount)
    order = create_razorpay_order(amount, rental.rental_code)
    return order

@router.post("/verify")
def verify_payment(data: PaymentVerifyRequest, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == data.rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    # 1. Cryptographic Signature Verification
    is_valid = verify_razorpay_signature(
        data.razorpay_order_id,
        data.razorpay_payment_id,
        data.razorpay_signature
    )
    if not is_valid:
        raise HTTPException(status_code=400, detail="Invalid cryptographic payment signature")

    # 2. Dynamic Commission Calculation
    setting = db.query(Setting).filter(Setting.key_name == "commission_rate").first()
    rate = float(setting.value) if setting else 5.0

    gross_total = float(rental.total_amount)
    split = calculate_marketplace_split(gross_total, rate)

    # 3. Update Rental Record
    rental.payment_status = "captured"
    rental.status = "paid"
    rental.pickup_status = "ready_for_pickup"
    rental.commission_amount = split["commission_amount"]
    rental.supplier_amount = split["supplier_payable"]

    # 4. Insert or Update Payment Record in DB
    payment = db.query(Payment).filter(Payment.rental_id == rental.id).first()
    if not payment:
        payment = Payment(
            rental_id=rental.id,
            total_amount=gross_total,
            platform_commission=split["commission_amount"],
            supplier_amount=split["supplier_payable"],
            razorpay_order_id=data.razorpay_order_id,
            razorpay_payment_id=data.razorpay_payment_id,
            razorpay_signature=data.razorpay_signature,
            payment_status="captured",
            settlement_status="pending"
        )
        db.add(payment)
    else:
        payment.payment_status = "captured"
        payment.razorpay_payment_id = data.razorpay_payment_id
        payment.platform_commission = split["commission_amount"]
        payment.supplier_amount = split["supplier_payable"]

    db.commit()

    return {
        "success": True,
        "message": "Payment verified successfully and commission split recorded",
        "split": {
            "gross": gross_total,
            "commissionAmount": split["commission_amount"],
            "supplierPayable": split["supplier_payable"],
            "razorpayPaymentId": data.razorpay_payment_id,
            "rentalCode": rental.rental_code
        }
    }

@router.get("/{rental_id}")
def get_payment_details(rental_id: int, db: Session = Depends(get_db)):
    payment = db.query(Payment).filter(Payment.rental_id == rental_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment record not found")
    return payment
