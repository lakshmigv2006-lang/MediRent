from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.models import User, Hospital, Supplier
from backend.app.schemas import (
    HospitalRegister, SupplierRegister, LoginRequest, TokenResponse
)
from backend.app.auth.jwt import (
    get_password_hash, verify_password, create_access_token, get_current_user
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register/hospital", response_model=TokenResponse)
def register_hospital(data: HospitalRegister, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        name=data.name,
        email=data.email,
        password_hash=get_password_hash(data.password),
        role="hospital",
        verification_status="pending"
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    hospital = Hospital(
        user_id=user.id,
        hospital_name=data.hospital_name,
        registration_number=data.registration_number,
        hospital_type=data.hospital_type or "Multi-Specialty Tertiary Care",
        contact_person=data.contact_person,
        phone=data.phone,
        address=data.address,
        city=data.city,
        state=data.state,
        pincode=data.pincode,
        latitude=data.latitude or 13.0418,
        longitude=data.longitude or 80.2507,
        google_maps_url=data.google_maps_url or f"https://maps.google.com/?q={data.latitude or 13.0418},{data.longitude or 80.2507}",
        verification_status="pending"
    )
    db.add(hospital)
    db.commit()

    token = create_access_token({"sub": user.email, "role": user.role, "id": user.id})
    return TokenResponse(
        access_token=token,
        role=user.role,
        user_id=user.id,
        name=user.name,
        email=user.email
    )

@router.post("/register/supplier", response_model=TokenResponse)
def register_supplier(data: SupplierRegister, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        name=data.name,
        email=data.email,
        password_hash=get_password_hash(data.password),
        role="supplier",
        verification_status="pending"
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    supplier = Supplier(
        user_id=user.id,
        business_name=data.business_name,
        business_registration_number=data.business_registration_number,
        business_type=data.business_type or "Authorized Equipment Dealer",
        authorized_person=data.authorized_person,
        phone=data.phone,
        address=data.address,
        city=data.city,
        state=data.state,
        pincode=data.pincode,
        latitude=data.latitude or 13.0850,
        longitude=data.longitude or 80.2101,
        google_maps_url=data.google_maps_url or f"https://maps.google.com/?q={data.latitude or 13.0850},{data.longitude or 80.2101}",
        verification_status="pending"
    )
    db.add(supplier)
    db.commit()

    token = create_access_token({"sub": user.email, "role": user.role, "id": user.id})
    return TokenResponse(
        access_token=token,
        role=user.role,
        user_id=user.id,
        name=user.name,
        email=user.email
    )

@router.post("/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": user.email, "role": user.role, "id": user.id})
    return TokenResponse(
        access_token=token,
        role=user.role,
        user_id=user.id,
        name=user.name,
        email=user.email
    )

@router.get("/me")
def get_current_user_profile(user: User = Depends(get_current_user)):
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "verification_status": user.verification_status
    }
