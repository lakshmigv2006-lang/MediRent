from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.models import User, Supplier, Equipment, EquipmentImage, Rental, PickupRequest, RenewalRequest, MaintenanceRecord
from backend.app.schemas import EquipmentCreate
from backend.app.auth.jwt import require_supplier

router = APIRouter(prefix="/api/supplier", tags=["Supplier Operations"], dependencies=[Depends(require_supplier)])

@router.get("/dashboard")
def get_supplier_dashboard(user: User = Depends(require_supplier), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.user_id == user.id).first()
    supp_id = supp.id if supp else 1

    equipment = db.query(Equipment).filter(Equipment.supplier_id == supp_id).all()
    rentals = db.query(Rental).filter(Rental.supplier_id == supp_id).all()

    available_eq = sum(1 for e in equipment if e.availability_status == "available")
    rented_eq = sum(1 for e in equipment if e.availability_status == "rented")
    new_requests = sum(1 for r in rentals if r.status in ["requested", "pending"])
    active_rentals = sum(1 for r in rentals if r.status == "active")

    paid_rentals = [r for r in rentals if r.payment_status == "captured"]
    gross_earnings = sum(float(r.total_amount) for r in paid_rentals)
    commission_paid = sum(float(r.commission_amount) for r in paid_rentals)
    net_earnings = sum(float(r.supplier_amount) for r in paid_rentals)

    return {
        "business_name": supp.business_name if supp else user.name,
        "verification_status": supp.verification_status if supp else "verified",
        "equipment": {"total": len(equipment), "available": available_eq, "rented": rented_eq},
        "rentals": {"new_requests": new_requests, "active": active_rentals},
        "financials": {
            "gross_bookings": gross_earnings,
            "platform_commission_5pct": commission_paid,
            "net_payable_95pct": net_earnings
        }
    }

@router.get("/equipment")
def list_supplier_equipment(user: User = Depends(require_supplier), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.user_id == user.id).first()
    supp_id = supp.id if supp else 1
    return db.query(Equipment).filter(Equipment.supplier_id == supp_id).all()

@router.post("/equipment")
def add_equipment(data: EquipmentCreate, user: User = Depends(require_supplier), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.user_id == user.id).first()
    supp_id = supp.id if supp else 1

    eq = Equipment(
        supplier_id=supp_id,
        name=data.name,
        category=data.category,
        manufacturer=data.manufacturer,
        model=data.model,
        serial_number=data.serial_number,
        description=data.description,
        price_per_day=data.price_per_day,
        security_deposit=data.security_deposit or 0.0,
        condition_rating=data.condition_rating or "excellent",
        availability_status=data.availability_status or "available",
        maintenance_status=data.maintenance_status or "up_to_date",
        verification_status="verified"
    )
    db.add(eq)
    db.commit()
    db.refresh(eq)

    if data.images:
        for idx, img_url in enumerate(data.images):
            img = EquipmentImage(equipment_id=eq.id, image_url=img_url, is_primary=(idx == 0))
            db.add(img)
        db.commit()

    return {"message": "Equipment added successfully", "id": eq.id}

@router.get("/rental-requests")
def list_incoming_rental_requests(user: User = Depends(require_supplier), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.user_id == user.id).first()
    supp_id = supp.id if supp else 1

    rentals = db.query(Rental).filter(Rental.supplier_id == supp_id).order_by(Rental.id.desc()).all()
    results = []
    for r in rentals:
        p = r.pickup_request
        results.append({
            "id": r.id,
            "rental_code": r.rental_code,
            "hospital_name": r.hospital.hospital_name if r.hospital else "Hospital",
            "equipment_name": r.equipment.name if r.equipment else "Medical Equipment",
            "start_date": str(r.start_date),
            "end_date": str(r.end_date),
            "days": r.number_of_days,
            "total_amount": float(r.total_amount),
            "commission_amount": float(r.commission_amount),
            "supplier_amount": float(r.supplier_amount),
            "status": r.status,
            "payment_status": r.payment_status,
            "pickup_status": r.pickup_status,
            "driver_details": {
                "driver": p.driver_name,
                "phone": p.driver_phone,
                "vehicle": p.vehicle_number
            } if p else None
        })
    return results

@router.put("/rentals/{id}/approve")
def approve_rental(id: int, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")
    rental.status = "approved"
    rental.payment_status = "pending"
    rental.pickup_status = "waiting_for_payment"
    db.commit()
    return {"message": "Rental approved. Ready for hospital payment.", "id": id}

@router.put("/rentals/{id}/reject")
def reject_rental(id: int, reason: str = Body(..., embed=True), db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")
    rental.status = "rejected"
    rental.rejection_reason = reason
    db.commit()
    return {"message": "Rental rejected", "id": id, "reason": reason}

@router.put("/pickups/{rental_id}/handed-over")
def mark_handed_over(rental_id: int, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")
    rental.status = "active"
    rental.pickup_status = "handed_over"
    if rental.pickup_request:
        rental.pickup_request.status = "handed_over"
        rental.pickup_request.handed_over_at = datetime.utcnow()
    db.commit()
    return {"message": "Equipment handed over to driver. Rental is now ACTIVE.", "rental_id": rental_id}

@router.get("/earnings")
def get_supplier_earnings(user: User = Depends(require_supplier), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.user_id == user.id).first()
    supp_id = supp.id if supp else 1

    paid_rentals = db.query(Rental).filter(Rental.supplier_id == supp_id, Rental.payment_status == "captured").all()
    gross = sum(float(r.total_amount) for r in paid_rentals)
    commission = sum(float(r.commission_amount) for r in paid_rentals)
    net_payable = sum(float(r.supplier_amount) for r in paid_rentals)

    return {
        "gross_revenue": gross,
        "medirent_commission_5pct": commission,
        "net_supplier_payable_95pct": net_payable,
        "transactions_count": len(paid_rentals)
    }
