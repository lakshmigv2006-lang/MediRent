from typing import Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.models import User, Hospital, Supplier, Equipment, Rental, Payment, Setting
from backend.app.auth.jwt import require_admin

router = APIRouter(prefix="/api/admin", tags=["Admin Operations"], dependencies=[Depends(require_admin)])

@router.get("/dashboard")
def get_admin_dashboard(db: Session = Depends(get_db)):
    hospitals_total = db.query(Hospital).count()
    hospitals_verified = db.query(Hospital).filter(Hospital.verification_status == "verified").count()
    suppliers_total = db.query(Supplier).count()
    suppliers_verified = db.query(Supplier).filter(Supplier.verification_status == "verified").count()
    equipment_total = db.query(Equipment).count()
    equipment_verified = db.query(Equipment).filter(Equipment.verification_status == "verified").count()
    rentals_total = db.query(Rental).count()
    rentals_active = db.query(Rental).filter(Rental.status == "active").count()

    payments = db.query(Payment).filter(Payment.payment_status == "captured").all()
    gross_volume = sum(float(p.total_amount) for p in payments)
    platform_commission = sum(float(p.platform_commission) for p in payments)
    supplier_payable = sum(float(p.supplier_amount) for p in payments)

    return {
        "hospitals": {"total": hospitals_total, "verified": hospitals_verified, "pending": hospitals_total - hospitals_verified},
        "suppliers": {"total": suppliers_total, "verified": suppliers_verified, "pending": suppliers_total - suppliers_verified},
        "equipment": {"total": equipment_total, "verified": equipment_verified, "pending": equipment_total - equipment_verified},
        "rentals": {"total": rentals_total, "active": rentals_active},
        "financials": {
            "gross_volume": gross_volume,
            "platform_commission": platform_commission,
            "supplier_payable": supplier_payable,
            "currency": "INR"
        }
    }

@router.get("/hospitals")
def list_hospitals(db: Session = Depends(get_db)):
    return db.query(Hospital).all()

@router.put("/hospitals/{id}/approve")
def approve_hospital(id: int, db: Session = Depends(get_db)):
    hosp = db.query(Hospital).filter(Hospital.id == id).first()
    if not hosp:
        raise HTTPException(status_code=404, detail="Hospital not found")
    hosp.verification_status = "verified"
    hosp.verified_at = datetime.utcnow()
    hosp.rejection_reason = None
    if hosp.user:
        hosp.user.verification_status = "verified"
    db.commit()
    return {"message": "Hospital verified successfully", "id": id}

@router.put("/hospitals/{id}/reject")
def reject_hospital(id: int, reason: str = Body(..., embed=True), db: Session = Depends(get_db)):
    hosp = db.query(Hospital).filter(Hospital.id == id).first()
    if not hosp:
        raise HTTPException(status_code=404, detail="Hospital not found")
    hosp.verification_status = "rejected"
    hosp.rejection_reason = reason
    if hosp.user:
        hosp.user.verification_status = "rejected"
    db.commit()
    return {"message": "Hospital rejected", "id": id, "reason": reason}

@router.get("/suppliers")
def list_suppliers(db: Session = Depends(get_db)):
    return db.query(Supplier).all()

@router.put("/suppliers/{id}/approve")
def approve_supplier(id: int, db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.id == id).first()
    if not supp:
        raise HTTPException(status_code=404, detail="Supplier not found")
    supp.verification_status = "verified"
    supp.verified_at = datetime.utcnow()
    supp.rejection_reason = None
    if supp.user:
        supp.user.verification_status = "verified"
    db.commit()
    return {"message": "Supplier verified successfully", "id": id}

@router.put("/suppliers/{id}/reject")
def reject_supplier(id: int, reason: str = Body(..., embed=True), db: Session = Depends(get_db)):
    supp = db.query(Supplier).filter(Supplier.id == id).first()
    if not supp:
        raise HTTPException(status_code=404, detail="Supplier not found")
    supp.verification_status = "rejected"
    supp.rejection_reason = reason
    if supp.user:
        supp.user.verification_status = "rejected"
    db.commit()
    return {"message": "Supplier rejected", "id": id, "reason": reason}

@router.get("/equipment")
def list_equipment_for_admin(db: Session = Depends(get_db)):
    return db.query(Equipment).all()

@router.put("/equipment/{id}/approve")
def approve_equipment(id: int, db: Session = Depends(get_db)):
    eq = db.query(Equipment).filter(Equipment.id == id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    eq.verification_status = "verified"
    db.commit()
    return {"message": "Equipment listing approved and active", "id": id}

@router.put("/equipment/{id}/reject")
def reject_equipment(id: int, db: Session = Depends(get_db)):
    eq = db.query(Equipment).filter(Equipment.id == id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    eq.verification_status = "rejected"
    db.commit()
    return {"message": "Equipment rejected", "id": id}

@router.get("/rentals")
def list_all_rentals(db: Session = Depends(get_db)):
    rentals = db.query(Rental).order_by(Rental.id.desc()).all()
    results = []
    for r in rentals:
        results.append({
            "id": r.id,
            "rental_code": r.rental_code,
            "hospital_name": r.hospital.hospital_name if r.hospital else "Unknown Hospital",
            "supplier_name": r.supplier.business_name if r.supplier else "Unknown Supplier",
            "equipment_name": r.equipment.name if r.equipment else "Unknown Equipment",
            "start_date": str(r.start_date),
            "end_date": str(r.end_date),
            "number_of_days": r.number_of_days,
            "total_amount": float(r.total_amount),
            "commission_amount": float(r.commission_amount),
            "supplier_amount": float(r.supplier_amount),
            "status": r.status,
            "payment_status": r.payment_status,
            "pickup_status": r.pickup_status,
        })
    return results

@router.get("/payments")
def list_all_payments(db: Session = Depends(get_db)):
    payments = db.query(Payment).order_by(Payment.id.desc()).all()
    results = []
    for p in payments:
        r = p.rental
        results.append({
            "id": p.id,
            "rental_code": r.rental_code if r else f"MR-{p.rental_id}",
            "hospital_name": r.hospital.hospital_name if r and r.hospital else "Hospital",
            "supplier_name": r.supplier.business_name if r and r.supplier else "Supplier",
            "total_amount": float(p.total_amount),
            "platform_commission": float(p.platform_commission),
            "supplier_amount": float(p.supplier_amount),
            "razorpay_order_id": p.razorpay_order_id,
            "razorpay_payment_id": p.razorpay_payment_id,
            "payment_status": p.payment_status,
            "settlement_status": p.settlement_status,
            "created_at": p.created_at.isoformat()
        })
    return results

@router.put("/payouts/{rental_id}/settle")
def toggle_payout_settlement(rental_id: int, db: Session = Depends(get_db)):
    payment = db.query(Payment).filter(Payment.rental_id == rental_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment record not found")
    payment.settlement_status = "settled" if payment.settlement_status != "settled" else "pending"
    payment.settled_at = datetime.utcnow() if payment.settlement_status == "settled" else None
    db.commit()
    return {"message": "Settlement status updated", "rental_id": rental_id, "status": payment.settlement_status}

@router.get("/commission")
def get_commission_settings(db: Session = Depends(get_db)):
    setting = db.query(Setting).filter(Setting.key_name == "commission_rate").first()
    rate = float(setting.value) if setting else 5.0
    return {"commission_rate": rate}

@router.put("/commission")
def update_commission_settings(rate: float = Body(..., embed=True), db: Session = Depends(get_db)):
    setting = db.query(Setting).filter(Setting.key_name == "commission_rate").first()
    if not setting:
        setting = Setting(key_name="commission_rate", value=str(rate))
        db.add(setting)
    else:
        setting.value = str(rate)
    db.commit()
    return {"message": "Commission rate updated", "commission_rate": rate}
