import math
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from backend.app.database.connection import get_db
from backend.app.models import User, Hospital, Supplier, Equipment, Rental, PickupRequest, RenewalRequest, ReturnRecord, Setting
from backend.app.schemas import (
    RentalRequestCreate, PickupDetailsCreate, RenewalRequestCreate, ReturnRequestCreate, AIRecommendationRequest
)
from backend.app.auth.jwt import require_hospital
from backend.app.ai.recommendation import rank_equipment_recommendations, calculate_haversine_distance

router = APIRouter(prefix="/api/hospital", tags=["Hospital Operations"], dependencies=[Depends(require_hospital)])

@router.get("/dashboard")
def get_hospital_dashboard(user: User = Depends(require_hospital), db: Session = Depends(get_db)):
    hosp = db.query(Hospital).filter(Hospital.user_id == user.id).first()
    hosp_id = hosp.id if hosp else 1

    rentals = db.query(Rental).filter(Rental.hospital_id == hosp_id).all()
    active_count = sum(1 for r in rentals if r.status == "active")
    pending_payments = sum(1 for r in rentals if r.payment_status != "captured")
    total_spent = sum(float(r.total_amount) for r in rentals if r.payment_status == "captured")

    return {
        "hospital_name": hosp.hospital_name if hosp else user.name,
        "verification_status": hosp.verification_status if hosp else "verified",
        "active_rentals": active_count,
        "pending_payments": pending_payments,
        "total_spent": total_spent,
        "total_bookings": len(rentals)
    }

@router.get("/equipment")
def browse_equipment(
    category: str = None,
    condition: str = None,
    q: str = None,
    user: User = Depends(require_hospital),
    db: Session = Depends(get_db)
):
    hosp = db.query(Hospital).filter(Hospital.user_id == user.id).first()
    hosp_lat = float(hosp.latitude) if hosp and hosp.latitude else 13.0418
    hosp_lon = float(hosp.longitude) if hosp and hosp.longitude else 80.2507

    query = db.query(Equipment).filter(
        Equipment.availability_status == "available",
        Equipment.verification_status == "verified"
    )

    if category:
        query = query.filter(Equipment.category == category)
    if condition:
        query = query.filter(Equipment.condition_rating == condition)
    if q:
        query = query.filter(Equipment.name.ilike(f"%{q}%"))

    items = query.all()
    results = []
    for eq in items:
        supp = eq.supplier
        supp_lat = float(supp.latitude) if supp and supp.latitude else 13.0850
        supp_lon = float(supp.longitude) if supp and supp.longitude else 80.2101
        dist = calculate_haversine_distance(hosp_lat, hosp_lon, supp_lat, supp_lon)

        results.append({
            "id": eq.id,
            "name": eq.name,
            "category": eq.category,
            "manufacturer": eq.manufacturer,
            "model": eq.model,
            "serial_number": eq.serial_number,
            "price_per_day": float(eq.price_per_day),
            "condition": eq.condition_rating,
            "maintenance_status": eq.maintenance_status,
            "supplier_id": supp.id if supp else 1,
            "supplier_name": supp.business_name if supp else "MedEquip Partner",
            "supplier_verified": supp.verification_status == "verified" if supp else False,
            "location": f"{supp.city if supp else 'Chennai'} ({dist} km away)",
            "distance_km": dist,
            "google_maps_url": supp.google_maps_url if supp else None,
            "images": [img.image_url for img in eq.images] if eq.images else ["https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600"]
        })
    return results

@router.post("/recommendations")
def get_ai_recommendations(req: AIRecommendationRequest, db: Session = Depends(get_db)):
    return rank_equipment_recommendations(req, db)

@router.post("/rentals")
def create_rental_request(data: RentalRequestCreate, user: User = Depends(require_hospital), db: Session = Depends(get_db)):
    hosp = db.query(Hospital).filter(Hospital.user_id == user.id).first()
    if not hosp:
        raise HTTPException(status_code=400, detail="Hospital profile not found")

    eq = db.query(Equipment).filter(Equipment.id == data.equipment_id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")

    days = max(1, (data.end_date - data.start_date).days)
    price_per_day = float(eq.price_per_day)
    total_amount = days * price_per_day

    # Fetch commission setting
    setting = db.query(Setting).filter(Setting.key_name == "commission_rate").first()
    rate = float(setting.value) if setting else 5.0
    commission = round(total_amount * (rate / 100.0), 2)
    supplier_share = round(total_amount - commission, 2)

    import random
    rental_code = f"MR-{random.randint(1000, 9999)}"

    rental = Rental(
        rental_code=rental_code,
        hospital_id=hosp.id,
        supplier_id=eq.supplier_id,
        equipment_id=eq.id,
        start_date=data.start_date,
        end_date=data.end_date,
        number_of_days=days,
        price_per_day=price_per_day,
        rental_amount=total_amount,
        commission_amount=commission,
        supplier_amount=supplier_share,
        total_amount=total_amount,
        status="requested",
        payment_status="pending",
        pickup_status="waiting_for_payment"
    )
    db.add(rental)
    db.commit()
    db.refresh(rental)

    return {"message": "Rental request sent to supplier", "rental_code": rental.rental_code, "id": rental.id}

@router.get("/rentals")
def list_hospital_rentals(user: User = Depends(require_hospital), db: Session = Depends(get_db)):
    hosp = db.query(Hospital).filter(Hospital.user_id == user.id).first()
    hosp_id = hosp.id if hosp else 1

    rentals = db.query(Rental).filter(Rental.hospital_id == hosp_id).order_by(Rental.id.desc()).all()
    results = []
    for r in rentals:
        p = r.pickup_request
        results.append({
            "id": r.id,
            "rental_code": r.rental_code,
            "equipment_name": r.equipment.name if r.equipment else "Medical Device",
            "supplier_name": r.supplier.business_name if r.supplier else "Supplier",
            "start_date": str(r.start_date),
            "end_date": str(r.end_date),
            "days": r.number_of_days,
            "price_per_day": float(r.price_per_day),
            "total_amount": float(r.total_amount),
            "commission_amount": float(r.commission_amount),
            "supplier_amount": float(r.supplier_amount),
            "status": r.status,
            "payment_status": r.payment_status,
            "pickup_status": r.pickup_status,
            "driver_name": p.driver_name if p else None,
            "vehicle_number": p.vehicle_number if p else None,
        })
    return results

@router.post("/pickups/{rental_id}")
def assign_pickup_details(rental_id: int, data: PickupDetailsCreate, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    pickup = db.query(PickupRequest).filter(PickupRequest.rental_id == rental_id).first()
    if not pickup:
        pickup = PickupRequest(
            rental_id=rental_id,
            pickup_date=data.pickup_date,
            pickup_time=data.pickup_time or "10:00 AM - 12:00 PM",
            driver_name=data.driver_name,
            driver_phone=data.driver_phone,
            vehicle_number=data.vehicle_number,
            vehicle_type=data.vehicle_type or "Medical Logistics Van",
            pickup_address=data.pickup_address,
            status="driver_assigned"
        )
        db.add(pickup)
    else:
        pickup.driver_name = data.driver_name
        pickup.driver_phone = data.driver_phone
        pickup.vehicle_number = data.vehicle_number
        pickup.status = "driver_assigned"

    rental.pickup_status = "driver_assigned"
    db.commit()
    return {"message": "Pickup driver assigned successfully", "rental_id": rental_id}

@router.post("/renewals/{rental_id}")
def request_renewal(rental_id: int, data: RenewalRequestCreate, user: User = Depends(require_hospital), db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    addl_amount = data.additional_days * float(rental.price_per_day)
    renewal = RenewalRequest(
        rental_id=rental_id,
        requested_by=user.id,
        current_end_date=rental.end_date,
        requested_end_date=data.requested_end_date,
        additional_days=data.additional_days,
        additional_amount=addl_amount,
        status="pending"
    )
    db.add(renewal)
    rental.status = "renewal_requested"
    db.commit()
    return {"message": "Renewal extension requested", "additional_amount": addl_amount}

@router.post("/returns/{rental_id}")
def request_return(rental_id: int, data: ReturnRequestCreate, db: Session = Depends(get_db)):
    rental = db.query(Rental).filter(Rental.id == rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    ret = ReturnRecord(
        rental_id=rental_id,
        requested_date=datetime.utcnow().date(),
        condition_rating=data.condition_rating or "good",
        damage_notes=data.damage_notes,
        damage_image_url=data.damage_image_url,
        status="return_requested"
    )
    db.add(ret)
    rental.status = "return_requested"
    db.commit()
    return {"message": "Return requested successfully", "rental_id": rental_id}
