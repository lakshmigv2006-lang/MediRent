from typing import Optional, List
from datetime import datetime, date
from pydantic import BaseModel, EmailStr, Field

# ================= AUTH SCHEMAS =================
class UserBase(BaseModel):
    name: str
    email: EmailStr
    role: str

class UserCreate(UserBase):
    password: str

class HospitalRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    hospital_name: str
    registration_number: str
    hospital_type: Optional[str] = "Multi-Specialty Tertiary Care"
    contact_person: str
    phone: str
    address: str
    city: str
    state: str
    pincode: str
    latitude: Optional[float] = 13.0418
    longitude: Optional[float] = 80.2507
    google_maps_url: Optional[str] = None

class SupplierRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    business_name: str
    business_registration_number: str
    business_type: Optional[str] = "Authorized Equipment Dealer & Service Center"
    authorized_person: str
    phone: str
    address: str
    city: str
    state: str
    pincode: str
    latitude: Optional[float] = 13.0850
    longitude: Optional[float] = 80.2101
    google_maps_url: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: int
    name: str
    email: str

# ================= EQUIPMENT SCHEMAS =================
class EquipmentCreate(BaseModel):
    name: str
    category: str
    manufacturer: str
    model: str
    serial_number: str
    description: Optional[str] = None
    price_per_day: float
    security_deposit: Optional[float] = 0.0
    condition_rating: Optional[str] = "excellent"
    availability_status: Optional[str] = "available"
    maintenance_status: Optional[str] = "up_to_date"
    images: Optional[List[str]] = []

class EquipmentOut(BaseModel):
    id: int
    supplier_id: int
    name: str
    category: str
    manufacturer: str
    model: str
    serial_number: str
    description: Optional[str]
    price_per_day: float
    security_deposit: float
    condition_rating: str
    availability_status: str
    maintenance_status: str
    verification_status: str
    created_at: datetime
    images: Optional[List[str]] = []
    supplier_name: Optional[str] = None
    supplier_city: Optional[str] = None
    distance: Optional[str] = None

    class Config:
        from_attributes = True

# ================= RENTAL & PAYMENT SCHEMAS =================
class RentalRequestCreate(BaseModel):
    equipment_id: int
    start_date: date
    end_date: date
    notes: Optional[str] = None

class PickupDetailsCreate(BaseModel):
    pickup_date: date
    pickup_time: Optional[str] = "10:00 AM - 12:00 PM"
    driver_name: str
    driver_phone: str
    vehicle_number: str
    vehicle_type: Optional[str] = "Medical Logistics Van"
    pickup_address: Optional[str] = None

class RenewalRequestCreate(BaseModel):
    requested_end_date: date
    additional_days: int

class ReturnRequestCreate(BaseModel):
    condition_rating: Optional[str] = "good"
    damage_notes: Optional[str] = None
    damage_image_url: Optional[str] = None

class PaymentOrderCreate(BaseModel):
    rental_id: int

class PaymentVerifyRequest(BaseModel):
    rental_id: int
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str

class SplitBreakdown(BaseModel):
    gross_total: float
    commission_rate: float
    commission_amount: float
    supplier_payable: float
    razorpay_payment_id: str
    settlement_status: str

# ================= AI RECOMMENDATION SCHEMAS =================
class AIRecommendationRequest(BaseModel):
    equipment_needed: Optional[str] = None
    category: Optional[str] = None
    max_budget_per_day: Optional[float] = None
    rental_duration_days: Optional[int] = 5
    preferred_condition: Optional[str] = None
    hospital_latitude: Optional[float] = 13.0418
    hospital_longitude: Optional[float] = 80.2507

class AIRecommendationItem(BaseModel):
    equipment_id: int
    name: str
    category: str
    price_per_day: float
    condition: str
    distance_km: float
    match_score: int
    reasons: List[str]
    supplier_name: str
    supplier_verified: bool
    image_url: Optional[str] = None
