@echo off
title MediRent — Healthcare Equipment Rental Platform
echo ========================================================
echo        MediRent — Healthcare Equipment Rental Platform
echo               Verified. Reliable. Accessible.
echo ========================================================
echo.
echo Opening standalone live preview in your default browser...
start "" "%~dp0medirent-preview.html"
echo.
echo Standalone web application opened successfully!
echo.
echo To run via Node.js development server:
echo 1. Frontend: cd client ^&^& npm install ^&^& npm start
echo 2. Backend:  cd server ^&^& npm install ^&^& npm start
echo.
pause
